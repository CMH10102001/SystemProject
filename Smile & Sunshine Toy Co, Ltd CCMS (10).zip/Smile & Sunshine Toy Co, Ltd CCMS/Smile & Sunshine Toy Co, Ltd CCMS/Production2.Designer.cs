﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Production2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.txtDetail = new System.Windows.Forms.TextBox();
            this.Detail = new System.Windows.Forms.Label();
            this.txtStart_Date = new System.Windows.Forms.TextBox();
            this.Start_Date = new System.Windows.Forms.Label();
            this.txtProduction_Compound = new System.Windows.Forms.TextBox();
            this.Production_Compound = new System.Windows.Forms.Label();
            this.txtEnd_Date = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTeam_Leader = new System.Windows.Forms.TextBox();
            this.Team_Leader = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.Amount = new System.Windows.Forms.Label();
            this.txtWorker = new System.Windows.Forms.TextBox();
            this.Worker = new System.Windows.Forms.Label();
            this.txtDimension = new System.Windows.Forms.TextBox();
            this.Dimension = new System.Windows.Forms.Label();
            this.txtOrder_Id = new System.Windows.Forms.TextBox();
            this.Order_Id = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(1108, 888);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(262, 58);
            this.Add.TabIndex = 235;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1316, 24);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 205;
            this.label12.Text = "Admin";
            // 
            // txtDetail
            // 
            this.txtDetail.Location = new System.Drawing.Point(562, 870);
            this.txtDetail.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDetail.Name = "txtDetail";
            this.txtDetail.Size = new System.Drawing.Size(240, 29);
            this.txtDetail.TabIndex = 259;
            // 
            // Detail
            // 
            this.Detail.AutoSize = true;
            this.Detail.Location = new System.Drawing.Point(372, 870);
            this.Detail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Detail.Name = "Detail";
            this.Detail.Size = new System.Drawing.Size(51, 18);
            this.Detail.TabIndex = 258;
            this.Detail.Text = "Detail";
            // 
            // txtStart_Date
            // 
            this.txtStart_Date.Location = new System.Drawing.Point(562, 716);
            this.txtStart_Date.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtStart_Date.Name = "txtStart_Date";
            this.txtStart_Date.Size = new System.Drawing.Size(240, 29);
            this.txtStart_Date.TabIndex = 257;
            // 
            // Start_Date
            // 
            this.Start_Date.AutoSize = true;
            this.Start_Date.Location = new System.Drawing.Point(372, 716);
            this.Start_Date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Start_Date.Name = "Start_Date";
            this.Start_Date.Size = new System.Drawing.Size(82, 18);
            this.Start_Date.TabIndex = 256;
            this.Start_Date.Text = "Start_Date";
            // 
            // txtProduction_Compound
            // 
            this.txtProduction_Compound.Location = new System.Drawing.Point(562, 639);
            this.txtProduction_Compound.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProduction_Compound.Name = "txtProduction_Compound";
            this.txtProduction_Compound.Size = new System.Drawing.Size(240, 29);
            this.txtProduction_Compound.TabIndex = 255;
            // 
            // Production_Compound
            // 
            this.Production_Compound.AutoSize = true;
            this.Production_Compound.Location = new System.Drawing.Point(372, 639);
            this.Production_Compound.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Production_Compound.Name = "Production_Compound";
            this.Production_Compound.Size = new System.Drawing.Size(161, 18);
            this.Production_Compound.TabIndex = 254;
            this.Production_Compound.Text = "Production_Compound";
            // 
            // txtEnd_Date
            // 
            this.txtEnd_Date.Location = new System.Drawing.Point(562, 794);
            this.txtEnd_Date.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEnd_Date.Name = "txtEnd_Date";
            this.txtEnd_Date.Size = new System.Drawing.Size(240, 29);
            this.txtEnd_Date.TabIndex = 253;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(372, 794);
            this.label13.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(75, 18);
            this.label13.TabIndex = 252;
            this.label13.Text = "End_Date";
            // 
            // txtTeam_Leader
            // 
            this.txtTeam_Leader.Location = new System.Drawing.Point(562, 502);
            this.txtTeam_Leader.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTeam_Leader.Name = "txtTeam_Leader";
            this.txtTeam_Leader.Size = new System.Drawing.Size(240, 29);
            this.txtTeam_Leader.TabIndex = 251;
            // 
            // Team_Leader
            // 
            this.Team_Leader.AutoSize = true;
            this.Team_Leader.Location = new System.Drawing.Point(372, 502);
            this.Team_Leader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Team_Leader.Name = "Team_Leader";
            this.Team_Leader.Size = new System.Drawing.Size(103, 18);
            this.Team_Leader.TabIndex = 250;
            this.Team_Leader.Text = "Team_Leader";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(562, 352);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(240, 29);
            this.txtAmount.TabIndex = 249;
            // 
            // Amount
            // 
            this.Amount.AutoSize = true;
            this.Amount.Location = new System.Drawing.Point(372, 352);
            this.Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(62, 18);
            this.Amount.TabIndex = 248;
            this.Amount.Text = "Amount";
            // 
            // txtWorker
            // 
            this.txtWorker.Location = new System.Drawing.Point(562, 570);
            this.txtWorker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtWorker.Name = "txtWorker";
            this.txtWorker.Size = new System.Drawing.Size(240, 29);
            this.txtWorker.TabIndex = 245;
            // 
            // Worker
            // 
            this.Worker.AutoSize = true;
            this.Worker.Location = new System.Drawing.Point(372, 570);
            this.Worker.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Worker.Name = "Worker";
            this.Worker.Size = new System.Drawing.Size(60, 18);
            this.Worker.TabIndex = 244;
            this.Worker.Text = "Worker";
            // 
            // txtDimension
            // 
            this.txtDimension.Location = new System.Drawing.Point(562, 430);
            this.txtDimension.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtDimension.Name = "txtDimension";
            this.txtDimension.Size = new System.Drawing.Size(240, 29);
            this.txtDimension.TabIndex = 243;
            // 
            // Dimension
            // 
            this.Dimension.AutoSize = true;
            this.Dimension.Location = new System.Drawing.Point(372, 430);
            this.Dimension.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Dimension.Name = "Dimension";
            this.Dimension.Size = new System.Drawing.Size(82, 18);
            this.Dimension.TabIndex = 242;
            this.Dimension.Text = "Dimension";
            // 
            // txtOrder_Id
            // 
            this.txtOrder_Id.Location = new System.Drawing.Point(562, 214);
            this.txtOrder_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOrder_Id.Name = "txtOrder_Id";
            this.txtOrder_Id.Size = new System.Drawing.Size(240, 29);
            this.txtOrder_Id.TabIndex = 239;
            // 
            // Order_Id
            // 
            this.Order_Id.AutoSize = true;
            this.Order_Id.Location = new System.Drawing.Point(372, 214);
            this.Order_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Order_Id.Name = "Order_Id";
            this.Order_Id.Size = new System.Drawing.Size(70, 18);
            this.Order_Id.TabIndex = 238;
            this.Order_Id.Text = "Order_Id";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(562, 146);
            this.txtProduct_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(240, 29);
            this.txtProduct_Id.TabIndex = 237;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(372, 146);
            this.Product_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(82, 18);
            this.Product_Id.TabIndex = 236;
            this.Product_Id.Text = "Product_Id";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(562, 284);
            this.txtMaterial_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(240, 29);
            this.txtMaterial_Id.TabIndex = 261;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(372, 284);
            this.Material_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(90, 18);
            this.Material_Id.TabIndex = 260;
            this.Material_Id.Text = "Material_Id";
            // 
            // Production2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1544, 1002);
            this.Controls.Add(this.txtMaterial_Id);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtDetail);
            this.Controls.Add(this.Detail);
            this.Controls.Add(this.txtStart_Date);
            this.Controls.Add(this.Start_Date);
            this.Controls.Add(this.txtProduction_Compound);
            this.Controls.Add(this.Production_Compound);
            this.Controls.Add(this.txtEnd_Date);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtTeam_Leader);
            this.Controls.Add(this.Team_Leader);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.Amount);
            this.Controls.Add(this.txtWorker);
            this.Controls.Add(this.Worker);
            this.Controls.Add(this.txtDimension);
            this.Controls.Add(this.Dimension);
            this.Controls.Add(this.txtOrder_Id);
            this.Controls.Add(this.Order_Id);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Product_Id);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label12);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Production2";
            this.Text = "Production2";
            this.Load += new System.EventHandler(this.Production2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDetail;
        private System.Windows.Forms.Label Detail;
        private System.Windows.Forms.TextBox txtStart_Date;
        private System.Windows.Forms.Label Start_Date;
        private System.Windows.Forms.TextBox txtProduction_Compound;
        private System.Windows.Forms.Label Production_Compound;
        private System.Windows.Forms.TextBox txtEnd_Date;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTeam_Leader;
        private System.Windows.Forms.Label Team_Leader;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label Amount;
        private System.Windows.Forms.TextBox txtWorker;
        private System.Windows.Forms.Label Worker;
        private System.Windows.Forms.TextBox txtDimension;
        private System.Windows.Forms.Label Dimension;
        private System.Windows.Forms.TextBox txtOrder_Id;
        private System.Windows.Forms.Label Order_Id;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Label Material_Id;
    }
}