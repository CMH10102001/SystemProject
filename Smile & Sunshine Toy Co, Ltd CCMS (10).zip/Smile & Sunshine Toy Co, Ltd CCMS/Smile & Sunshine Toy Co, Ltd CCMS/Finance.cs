﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Finance : Form
    {
        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb";


        public Finance()
        {
            InitializeComponent();
        }

        private void Finance_Load(object sender, EventArgs e)
        {
            dataGridView1.ReadOnly = true;
            UpdateGrid("Select * from Finance");
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D006")
            {

            }
            else
            {
                MessageBox.Show("Only D006 and D007 has access");
                Close();
            }

            dataGridView1.CellClick += dataGridView1_CellClick;

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }


        }

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string payId = selectedRow.Cells["Pay_Id"].Value?.ToString() ?? string.Empty;
                string orderId = selectedRow.Cells["Order_Id"].Value?.ToString() ?? string.Empty;
                string staffId = selectedRow.Cells["Staff_Id"].Value?.ToString() ?? string.Empty;
                string customerId = selectedRow.Cells["Customer_Id"].Value?.ToString() ?? string.Empty;

                Finance1 finance1Form = new Finance1
                {
                    PayId = payId,
                    OrderId = orderId,
                    StaffId = staffId,
                    CustomerId = customerId
                };

                finance1Form.ShowDialog();
            }
        }

        private void search_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (search.Text.Length >= 1)
                {
                    UpdateGrid("Select * from Finance where Pay_Id = " + int.Parse(search.Text) + ";");
                }
                else
                {
                    UpdateGrid("Select * from Finance");
                }
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error search");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Finance");
            search.Text = "Search here!";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {
            Finance frm = new Finance();
            frm.ShowDialog();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Finance2 frm = new Finance2();
            frm.ShowDialog();
        }
    }
}
