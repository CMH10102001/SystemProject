﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Finance1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtOrder_Id = new System.Windows.Forms.TextBox();
            this.Order_Id = new System.Windows.Forms.Label();
            this.Customer_Id = new System.Windows.Forms.Label();
            this.txtCustomer_Id = new System.Windows.Forms.TextBox();
            this.Payment_method = new System.Windows.Forms.Label();
            this.txtPayment_method = new System.Windows.Forms.TextBox();
            this.Pay_Time = new System.Windows.Forms.Label();
            this.txtPay_Time = new System.Windows.Forms.TextBox();
            this.Pay_Date = new System.Windows.Forms.Label();
            this.txtPay_Date = new System.Windows.Forms.TextBox();
            this.Total_Pay_Amount = new System.Windows.Forms.Label();
            this.txtTotal_Pay_Amount = new System.Windows.Forms.TextBox();
            this.Pay_Amount = new System.Windows.Forms.Label();
            this.txtPay_Amount = new System.Windows.Forms.TextBox();
            this.Staff_Id = new System.Windows.Forms.Label();
            this.txtStaff_Id = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.Pay_Id = new System.Windows.Forms.Label();
            this.txtPay_Id = new System.Windows.Forms.TextBox();
            this.Modify = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtOrder_Id
            // 
            this.txtOrder_Id.Location = new System.Drawing.Point(564, 228);
            this.txtOrder_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtOrder_Id.Name = "txtOrder_Id";
            this.txtOrder_Id.Size = new System.Drawing.Size(259, 29);
            this.txtOrder_Id.TabIndex = 152;
            // 
            // Order_Id
            // 
            this.Order_Id.AutoSize = true;
            this.Order_Id.Location = new System.Drawing.Point(408, 232);
            this.Order_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Order_Id.Name = "Order_Id";
            this.Order_Id.Size = new System.Drawing.Size(70, 18);
            this.Order_Id.TabIndex = 153;
            this.Order_Id.Text = "Order_Id";
            // 
            // Customer_Id
            // 
            this.Customer_Id.AutoSize = true;
            this.Customer_Id.Location = new System.Drawing.Point(408, 286);
            this.Customer_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Id.Name = "Customer_Id";
            this.Customer_Id.Size = new System.Drawing.Size(96, 18);
            this.Customer_Id.TabIndex = 155;
            this.Customer_Id.Text = "Customer_Id";
            // 
            // txtCustomer_Id
            // 
            this.txtCustomer_Id.Location = new System.Drawing.Point(564, 282);
            this.txtCustomer_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCustomer_Id.Name = "txtCustomer_Id";
            this.txtCustomer_Id.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Id.TabIndex = 154;
            // 
            // Payment_method
            // 
            this.Payment_method.AutoSize = true;
            this.Payment_method.Location = new System.Drawing.Point(408, 405);
            this.Payment_method.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Payment_method.Name = "Payment_method";
            this.Payment_method.Size = new System.Drawing.Size(125, 18);
            this.Payment_method.TabIndex = 157;
            this.Payment_method.Text = "Payment_method";
            // 
            // txtPayment_method
            // 
            this.txtPayment_method.Location = new System.Drawing.Point(564, 400);
            this.txtPayment_method.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPayment_method.Name = "txtPayment_method";
            this.txtPayment_method.Size = new System.Drawing.Size(259, 29);
            this.txtPayment_method.TabIndex = 156;
            // 
            // Pay_Time
            // 
            this.Pay_Time.AutoSize = true;
            this.Pay_Time.Location = new System.Drawing.Point(408, 460);
            this.Pay_Time.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pay_Time.Name = "Pay_Time";
            this.Pay_Time.Size = new System.Drawing.Size(77, 18);
            this.Pay_Time.TabIndex = 159;
            this.Pay_Time.Text = "Pay_Time";
            // 
            // txtPay_Time
            // 
            this.txtPay_Time.Location = new System.Drawing.Point(564, 456);
            this.txtPay_Time.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPay_Time.Name = "txtPay_Time";
            this.txtPay_Time.Size = new System.Drawing.Size(259, 29);
            this.txtPay_Time.TabIndex = 158;
            // 
            // Pay_Date
            // 
            this.Pay_Date.AutoSize = true;
            this.Pay_Date.Location = new System.Drawing.Point(408, 514);
            this.Pay_Date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pay_Date.Name = "Pay_Date";
            this.Pay_Date.Size = new System.Drawing.Size(74, 18);
            this.Pay_Date.TabIndex = 161;
            this.Pay_Date.Text = "Pay_Date";
            // 
            // txtPay_Date
            // 
            this.txtPay_Date.Location = new System.Drawing.Point(564, 510);
            this.txtPay_Date.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPay_Date.Name = "txtPay_Date";
            this.txtPay_Date.Size = new System.Drawing.Size(259, 29);
            this.txtPay_Date.TabIndex = 160;
            // 
            // Total_Pay_Amount
            // 
            this.Total_Pay_Amount.AutoSize = true;
            this.Total_Pay_Amount.Location = new System.Drawing.Point(408, 633);
            this.Total_Pay_Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Total_Pay_Amount.Name = "Total_Pay_Amount";
            this.Total_Pay_Amount.Size = new System.Drawing.Size(139, 18);
            this.Total_Pay_Amount.TabIndex = 171;
            this.Total_Pay_Amount.Text = "Total_Pay_Amount";
            // 
            // txtTotal_Pay_Amount
            // 
            this.txtTotal_Pay_Amount.Location = new System.Drawing.Point(564, 628);
            this.txtTotal_Pay_Amount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtTotal_Pay_Amount.Name = "txtTotal_Pay_Amount";
            this.txtTotal_Pay_Amount.Size = new System.Drawing.Size(259, 29);
            this.txtTotal_Pay_Amount.TabIndex = 170;
            // 
            // Pay_Amount
            // 
            this.Pay_Amount.AutoSize = true;
            this.Pay_Amount.Location = new System.Drawing.Point(408, 579);
            this.Pay_Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pay_Amount.Name = "Pay_Amount";
            this.Pay_Amount.Size = new System.Drawing.Size(95, 18);
            this.Pay_Amount.TabIndex = 169;
            this.Pay_Amount.Text = "Pay_Amount";
            // 
            // txtPay_Amount
            // 
            this.txtPay_Amount.Location = new System.Drawing.Point(564, 574);
            this.txtPay_Amount.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPay_Amount.Name = "txtPay_Amount";
            this.txtPay_Amount.Size = new System.Drawing.Size(259, 29);
            this.txtPay_Amount.TabIndex = 168;
            // 
            // Staff_Id
            // 
            this.Staff_Id.AutoSize = true;
            this.Staff_Id.Location = new System.Drawing.Point(408, 342);
            this.Staff_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Staff_Id.Name = "Staff_Id";
            this.Staff_Id.Size = new System.Drawing.Size(64, 18);
            this.Staff_Id.TabIndex = 167;
            this.Staff_Id.Text = "Staff_Id";
            // 
            // txtStaff_Id
            // 
            this.txtStaff_Id.Location = new System.Drawing.Point(564, 338);
            this.txtStaff_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtStaff_Id.Name = "txtStaff_Id";
            this.txtStaff_Id.Size = new System.Drawing.Size(259, 29);
            this.txtStaff_Id.TabIndex = 166;
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(408, 692);
            this.State.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(43, 18);
            this.State.TabIndex = 165;
            this.State.Text = "State";
            this.State.Click += new System.EventHandler(this.State_Click);
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(564, 692);
            this.txtState.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(259, 29);
            this.txtState.TabIndex = 164;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            // 
            // Pay_Id
            // 
            this.Pay_Id.AutoSize = true;
            this.Pay_Id.Location = new System.Drawing.Point(408, 166);
            this.Pay_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Pay_Id.Name = "Pay_Id";
            this.Pay_Id.Size = new System.Drawing.Size(55, 18);
            this.Pay_Id.TabIndex = 163;
            this.Pay_Id.Text = "Pay_Id";
            // 
            // txtPay_Id
            // 
            this.txtPay_Id.Location = new System.Drawing.Point(564, 162);
            this.txtPay_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtPay_Id.Name = "txtPay_Id";
            this.txtPay_Id.Size = new System.Drawing.Size(259, 29);
            this.txtPay_Id.TabIndex = 162;
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(1070, 854);
            this.Modify.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(204, 64);
            this.Modify.TabIndex = 172;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Add_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1198, 32);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 173;
            this.label12.Text = "Admin";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(410, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 18);
            this.label13.TabIndex = 174;
            this.label13.Text = "Admin";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(810, 854);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(204, 64);
            this.Delete.TabIndex = 175;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Finance1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1368, 978);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Total_Pay_Amount);
            this.Controls.Add(this.txtTotal_Pay_Amount);
            this.Controls.Add(this.Pay_Amount);
            this.Controls.Add(this.txtPay_Amount);
            this.Controls.Add(this.Staff_Id);
            this.Controls.Add(this.txtStaff_Id);
            this.Controls.Add(this.State);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.Pay_Id);
            this.Controls.Add(this.txtPay_Id);
            this.Controls.Add(this.Pay_Date);
            this.Controls.Add(this.txtPay_Date);
            this.Controls.Add(this.Pay_Time);
            this.Controls.Add(this.txtPay_Time);
            this.Controls.Add(this.Payment_method);
            this.Controls.Add(this.txtPayment_method);
            this.Controls.Add(this.Customer_Id);
            this.Controls.Add(this.txtCustomer_Id);
            this.Controls.Add(this.Order_Id);
            this.Controls.Add(this.txtOrder_Id);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Finance1";
            this.Text = "Finance1";
            this.Load += new System.EventHandler(this.Finance1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtOrder_Id;
        private System.Windows.Forms.Label Order_Id;
        private System.Windows.Forms.Label Customer_Id;
        private System.Windows.Forms.TextBox txtCustomer_Id;
        private System.Windows.Forms.Label Payment_method;
        private System.Windows.Forms.TextBox txtPayment_method;
        private System.Windows.Forms.Label Pay_Time;
        private System.Windows.Forms.TextBox txtPay_Time;
        private System.Windows.Forms.Label Pay_Date;
        private System.Windows.Forms.TextBox txtPay_Date;
        private System.Windows.Forms.Label Total_Pay_Amount;
        private System.Windows.Forms.TextBox txtTotal_Pay_Amount;
        private System.Windows.Forms.Label Pay_Amount;
        private System.Windows.Forms.TextBox txtPay_Amount;
        private System.Windows.Forms.Label Staff_Id;
        private System.Windows.Forms.TextBox txtStaff_Id;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label Pay_Id;
        private System.Windows.Forms.TextBox txtPay_Id;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Delete;
    }
}