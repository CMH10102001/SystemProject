﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Inventory2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.Content = new System.Windows.Forms.Label();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.EachCost = new System.Windows.Forms.Label();
            this.txtEachCost = new System.Windows.Forms.TextBox();
            this.Material_Name = new System.Windows.Forms.Label();
            this.txtMaterialName = new System.Windows.Forms.TextBox();
            this.Expected_Qty = new System.Windows.Forms.Label();
            this.txtExpected_Qty = new System.Windows.Forms.TextBox();
            this.Current_Qty = new System.Windows.Forms.Label();
            this.txtCurrent_Qty = new System.Windows.Forms.TextBox();
            this.Material_Type = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.Supplier_Id = new System.Windows.Forms.Label();
            this.txtSupplier_Id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1194, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 243;
            this.label12.Text = "Admin";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(1046, 873);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(204, 64);
            this.Add.TabIndex = 242;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Content
            // 
            this.Content.AutoSize = true;
            this.Content.Location = new System.Drawing.Point(406, 742);
            this.Content.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Content.Name = "Content";
            this.Content.Size = new System.Drawing.Size(61, 18);
            this.Content.TabIndex = 241;
            this.Content.Text = "Content";
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(562, 738);
            this.txtContent.Margin = new System.Windows.Forms.Padding(4);
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(259, 29);
            this.txtContent.TabIndex = 240;
            // 
            // EachCost
            // 
            this.EachCost.AutoSize = true;
            this.EachCost.Location = new System.Drawing.Point(406, 688);
            this.EachCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EachCost.Name = "EachCost";
            this.EachCost.Size = new System.Drawing.Size(73, 18);
            this.EachCost.TabIndex = 239;
            this.EachCost.Text = "EachCost";
            // 
            // txtEachCost
            // 
            this.txtEachCost.Location = new System.Drawing.Point(562, 684);
            this.txtEachCost.Margin = new System.Windows.Forms.Padding(4);
            this.txtEachCost.Name = "txtEachCost";
            this.txtEachCost.Size = new System.Drawing.Size(259, 29);
            this.txtEachCost.TabIndex = 238;
            // 
            // Material_Name
            // 
            this.Material_Name.AutoSize = true;
            this.Material_Name.Location = new System.Drawing.Point(406, 392);
            this.Material_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Name.Name = "Material_Name";
            this.Material_Name.Size = new System.Drawing.Size(117, 18);
            this.Material_Name.TabIndex = 237;
            this.Material_Name.Text = "Material_Name";
            // 
            // txtMaterialName
            // 
            this.txtMaterialName.Location = new System.Drawing.Point(562, 388);
            this.txtMaterialName.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterialName.Name = "txtMaterialName";
            this.txtMaterialName.Size = new System.Drawing.Size(259, 29);
            this.txtMaterialName.TabIndex = 236;
            // 
            // Expected_Qty
            // 
            this.Expected_Qty.AutoSize = true;
            this.Expected_Qty.Location = new System.Drawing.Point(406, 624);
            this.Expected_Qty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Expected_Qty.Name = "Expected_Qty";
            this.Expected_Qty.Size = new System.Drawing.Size(104, 18);
            this.Expected_Qty.TabIndex = 233;
            this.Expected_Qty.Text = "Expected_Qty";
            // 
            // txtExpected_Qty
            // 
            this.txtExpected_Qty.Location = new System.Drawing.Point(562, 620);
            this.txtExpected_Qty.Margin = new System.Windows.Forms.Padding(4);
            this.txtExpected_Qty.Name = "txtExpected_Qty";
            this.txtExpected_Qty.Size = new System.Drawing.Size(259, 29);
            this.txtExpected_Qty.TabIndex = 232;
            // 
            // Current_Qty
            // 
            this.Current_Qty.AutoSize = true;
            this.Current_Qty.Location = new System.Drawing.Point(406, 570);
            this.Current_Qty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Current_Qty.Name = "Current_Qty";
            this.Current_Qty.Size = new System.Drawing.Size(93, 18);
            this.Current_Qty.TabIndex = 231;
            this.Current_Qty.Text = "Current_Qty";
            // 
            // txtCurrent_Qty
            // 
            this.txtCurrent_Qty.Location = new System.Drawing.Point(562, 566);
            this.txtCurrent_Qty.Margin = new System.Windows.Forms.Padding(4);
            this.txtCurrent_Qty.Name = "txtCurrent_Qty";
            this.txtCurrent_Qty.Size = new System.Drawing.Size(259, 29);
            this.txtCurrent_Qty.TabIndex = 230;
            // 
            // Material_Type
            // 
            this.Material_Type.AutoSize = true;
            this.Material_Type.Location = new System.Drawing.Point(406, 514);
            this.Material_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Type.Name = "Material_Type";
            this.Material_Type.Size = new System.Drawing.Size(110, 18);
            this.Material_Type.TabIndex = 229;
            this.Material_Type.Text = "Material_Type";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(562, 510);
            this.txtType.Margin = new System.Windows.Forms.Padding(4);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(259, 29);
            this.txtType.TabIndex = 228;
            // 
            // Supplier_Id
            // 
            this.Supplier_Id.AutoSize = true;
            this.Supplier_Id.Location = new System.Drawing.Point(406, 450);
            this.Supplier_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Supplier_Id.Name = "Supplier_Id";
            this.Supplier_Id.Size = new System.Drawing.Size(87, 18);
            this.Supplier_Id.TabIndex = 227;
            this.Supplier_Id.Text = "Supplier_Id";
            // 
            // txtSupplier_Id
            // 
            this.txtSupplier_Id.Location = new System.Drawing.Point(562, 447);
            this.txtSupplier_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtSupplier_Id.Name = "txtSupplier_Id";
            this.txtSupplier_Id.Size = new System.Drawing.Size(259, 29);
            this.txtSupplier_Id.TabIndex = 226;
            // 
            // Inventory2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1448, 1071);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Content);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.EachCost);
            this.Controls.Add(this.txtEachCost);
            this.Controls.Add(this.Material_Name);
            this.Controls.Add(this.txtMaterialName);
            this.Controls.Add(this.Expected_Qty);
            this.Controls.Add(this.txtExpected_Qty);
            this.Controls.Add(this.Current_Qty);
            this.Controls.Add(this.txtCurrent_Qty);
            this.Controls.Add(this.Material_Type);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.Supplier_Id);
            this.Controls.Add(this.txtSupplier_Id);
            this.Name = "Inventory2";
            this.Text = "Inventory2";
            this.Load += new System.EventHandler(this.Inventory2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label Content;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label EachCost;
        private System.Windows.Forms.TextBox txtEachCost;
        private System.Windows.Forms.Label Material_Name;
        private System.Windows.Forms.TextBox txtMaterialName;
        private System.Windows.Forms.Label Expected_Qty;
        private System.Windows.Forms.TextBox txtExpected_Qty;
        private System.Windows.Forms.Label Current_Qty;
        private System.Windows.Forms.TextBox txtCurrent_Qty;
        private System.Windows.Forms.Label Material_Type;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label Supplier_Id;
        private System.Windows.Forms.TextBox txtSupplier_Id;
    }
}