﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Employee2 : Form
    {

        public Employee2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Employee2_Load(object sender, EventArgs e)
        {


        }

        private void bookIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void authorTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void publisherTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }




        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }





        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
           Product frm = new Product();
            frm.ShowDialog();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            Home frm = new Home();
            frm.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            frm.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Leads frm = new Leads();
            frm.ShowDialog();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataFromDatabase("INSERT INTO [Staff] " +
                    "([Staff_Id], [Password], [Department_Id], [Position_Id], [Work], [Salary], [Email], [PhoneNo], [Contact], [Leader], [Company], [JobTitle], [StaffName], [State])" +
                    "VALUES (" +
                    "'" + txtStaff_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtPassword.Text.Replace("'", "''") + "', " +
                    "'" + txtDepartment_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtPosition_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtWork.Text.Replace("'", "''") + "', " +
                    "" + int.Parse(txtSalary.Text) + ", " +
                    "'" + txtEmail.Text.Replace("'", "''") + "', " +
                    "'" + txtPhoneNo.Text.Replace("'", "''") + "', " +
                    "'" + txtContact.Text.Replace("'", "''") + "', " +
                    "'" + txtLeader.Text.Replace("'", "''") + "', " +
                    "'" + txtCompany.Text.Replace("'", "''") + "', " +
                    "'" + txtJobTitle.Text.Replace("'", "''") + "', " +
                    "'" + txtStaffName.Text.Replace("'", "''") + "', " +
                    "'" + txtState.Text.Replace("'", "''") + "');");

                String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
                String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
                String Exchange = "Staff_Id: " + txtStaff_Id.Text + ", Password: '" + txtPassword.Text + ", Department_Id: " + txtDepartment_Id.Text + ", Position_Id: " + Position_Id.Text + ", Work: " + txtWork.Text + ", Salary: " + txtSalary.Text + ", Email :" + txtEmail.Text + ", PhoneNo: " + txtPhoneNo.Text + ", Content: " + txtContact.Text + ", Leader: " + txtLeader.Text + ", Company: " + txtCompany.Text + ", JobTitle: " + txtJobTitle.Text + ", StaffName: " + txtStaffName.Text + ", State: " + txtState.Text;
                string sanitizedId = Id.Replace("'", "''");
                string sanitizedDepartment = Department.Replace("'", "''");
                string sanitizedExchange = Exchange.Replace("'", "''");
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                                    "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "',' ADD ', '" + sanitizedExchange + "');");

                MessageBox.Show("Adding success");

                Close();
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter: " + ea.Message);
            }
        }
    }
}
