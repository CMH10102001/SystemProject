﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Order1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label12 = new System.Windows.Forms.Label();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.productTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.ProductTableAdapter();
            this.label13 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.lblProductId = new System.Windows.Forms.TextBox();
            this.lblProductDescription = new System.Windows.Forms.TextBox();
            this.txtProduct_Cost = new System.Windows.Forms.TextBox();
            this.txtDepartment_Id = new System.Windows.Forms.TextBox();
            this.txtColumn = new System.Windows.Forms.TextBox();
            this.Order_Cost = new System.Windows.Forms.Label();
            this.Department_Id = new System.Windows.Forms.Label();
            this.Column = new System.Windows.Forms.Label();
            this.txtShippingOption = new System.Windows.Forms.TextBox();
            this.txtFinishDate = new System.Windows.Forms.TextBox();
            this.txtStartDate = new System.Windows.Forms.TextBox();
            this.ShippingOption = new System.Windows.Forms.Label();
            this.FinishDate = new System.Windows.Forms.Label();
            this.StartDate = new System.Windows.Forms.Label();
            this.txtResponseStaff = new System.Windows.Forms.TextBox();
            this.ResponseStaff = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.Next = new System.Windows.Forms.Button();
            this.Modify = new System.Windows.Forms.Button();
            this.label16 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.Version = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.Link1 = new System.Windows.Forms.Button();
            this.Link2 = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            this.lblProductName = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1518, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 31;
            this.label12.Text = "Admin";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(404, 184);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(92, 18);
            this.label13.TabIndex = 129;
            this.label13.Text = "Product_Id: ";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(404, 440);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 18);
            this.label15.TabIndex = 131;
            this.label15.Text = "Product Description";
            // 
            // lblProductId
            // 
            this.lblProductId.Location = new System.Drawing.Point(604, 172);
            this.lblProductId.Name = "lblProductId";
            this.lblProductId.Size = new System.Drawing.Size(198, 29);
            this.lblProductId.TabIndex = 132;
            this.lblProductId.TextChanged += new System.EventHandler(this.lblProductId_TextChanged);
            // 
            // lblProductDescription
            // 
            this.lblProductDescription.Location = new System.Drawing.Point(604, 429);
            this.lblProductDescription.Name = "lblProductDescription";
            this.lblProductDescription.Size = new System.Drawing.Size(198, 29);
            this.lblProductDescription.TabIndex = 134;
            // 
            // txtProduct_Cost
            // 
            this.txtProduct_Cost.Location = new System.Drawing.Point(604, 116);
            this.txtProduct_Cost.Name = "txtProduct_Cost";
            this.txtProduct_Cost.Size = new System.Drawing.Size(198, 29);
            this.txtProduct_Cost.TabIndex = 140;
            // 
            // txtDepartment_Id
            // 
            this.txtDepartment_Id.Location = new System.Drawing.Point(604, 358);
            this.txtDepartment_Id.Name = "txtDepartment_Id";
            this.txtDepartment_Id.Size = new System.Drawing.Size(198, 29);
            this.txtDepartment_Id.TabIndex = 139;
            // 
            // txtColumn
            // 
            this.txtColumn.Location = new System.Drawing.Point(604, 292);
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(198, 29);
            this.txtColumn.TabIndex = 138;
            this.txtColumn.TextChanged += new System.EventHandler(this.textBox3_TextChanged_1);
            // 
            // Order_Cost
            // 
            this.Order_Cost.AutoSize = true;
            this.Order_Cost.Location = new System.Drawing.Point(404, 128);
            this.Order_Cost.Name = "Order_Cost";
            this.Order_Cost.Size = new System.Drawing.Size(92, 18);
            this.Order_Cost.TabIndex = 137;
            this.Order_Cost.Text = "Order_Cost:";
            // 
            // Department_Id
            // 
            this.Department_Id.AutoSize = true;
            this.Department_Id.Location = new System.Drawing.Point(404, 369);
            this.Department_Id.Name = "Department_Id";
            this.Department_Id.Size = new System.Drawing.Size(181, 18);
            this.Department_Id.TabIndex = 136;
            this.Department_Id.Text = "Response Department_Id";
            this.Department_Id.Click += new System.EventHandler(this.Department_Id_Click);
            // 
            // Column
            // 
            this.Column.AutoSize = true;
            this.Column.Location = new System.Drawing.Point(404, 304);
            this.Column.Name = "Column";
            this.Column.Size = new System.Drawing.Size(72, 24);
            this.Column.TabIndex = 135;
            this.Column.Text = "Column: ";
            this.Column.UseCompatibleTextRendering = true;
            this.Column.Click += new System.EventHandler(this.label19_Click_1);
            // 
            // txtShippingOption
            // 
            this.txtShippingOption.Location = new System.Drawing.Point(604, 752);
            this.txtShippingOption.Name = "txtShippingOption";
            this.txtShippingOption.Size = new System.Drawing.Size(198, 29);
            this.txtShippingOption.TabIndex = 146;
            // 
            // txtFinishDate
            // 
            this.txtFinishDate.Location = new System.Drawing.Point(604, 686);
            this.txtFinishDate.Name = "txtFinishDate";
            this.txtFinishDate.Size = new System.Drawing.Size(198, 29);
            this.txtFinishDate.TabIndex = 145;
            // 
            // txtStartDate
            // 
            this.txtStartDate.Location = new System.Drawing.Point(604, 626);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(198, 29);
            this.txtStartDate.TabIndex = 144;
            // 
            // ShippingOption
            // 
            this.ShippingOption.AutoSize = true;
            this.ShippingOption.Location = new System.Drawing.Point(404, 762);
            this.ShippingOption.Name = "ShippingOption";
            this.ShippingOption.Size = new System.Drawing.Size(118, 18);
            this.ShippingOption.TabIndex = 143;
            this.ShippingOption.Text = "ShippingOption:";
            // 
            // FinishDate
            // 
            this.FinishDate.AutoSize = true;
            this.FinishDate.Location = new System.Drawing.Point(404, 698);
            this.FinishDate.Name = "FinishDate";
            this.FinishDate.Size = new System.Drawing.Size(88, 18);
            this.FinishDate.TabIndex = 142;
            this.FinishDate.Text = "FinishDate:";
            // 
            // StartDate
            // 
            this.StartDate.AutoSize = true;
            this.StartDate.Location = new System.Drawing.Point(404, 636);
            this.StartDate.Name = "StartDate";
            this.StartDate.Size = new System.Drawing.Size(79, 18);
            this.StartDate.TabIndex = 141;
            this.StartDate.Text = "StartDate:";
            // 
            // txtResponseStaff
            // 
            this.txtResponseStaff.Location = new System.Drawing.Point(604, 490);
            this.txtResponseStaff.Name = "txtResponseStaff";
            this.txtResponseStaff.Size = new System.Drawing.Size(198, 29);
            this.txtResponseStaff.TabIndex = 148;
            // 
            // ResponseStaff
            // 
            this.ResponseStaff.AutoSize = true;
            this.ResponseStaff.Location = new System.Drawing.Point(404, 502);
            this.ResponseStaff.Name = "ResponseStaff";
            this.ResponseStaff.Size = new System.Drawing.Size(112, 18);
            this.ResponseStaff.TabIndex = 147;
            this.ResponseStaff.Text = "Response Staff";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(608, 873);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(198, 29);
            this.txtState.TabIndex = 150;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(406, 879);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(43, 18);
            this.State.TabIndex = 149;
            this.State.Text = "State";
            // 
            // Next
            // 
            this.Next.Location = new System.Drawing.Point(830, 874);
            this.Next.Name = "Next";
            this.Next.Size = new System.Drawing.Size(75, 28);
            this.Next.TabIndex = 151;
            this.Next.Text = "Next";
            this.Next.UseVisualStyleBackColor = true;
            this.Next.Click += new System.EventHandler(this.bt1_Click);
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(1474, 860);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(262, 58);
            this.Modify.TabIndex = 152;
            this.Modify.Text = "Modify";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(384, 16);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(92, 18);
            this.label16.TabIndex = 153;
            this.label16.Text = "Product_Id: ";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(604, 554);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 29);
            this.textBox1.TabIndex = 155;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(404, 564);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 18);
            this.label17.TabIndex = 154;
            this.label17.Text = "Comment";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(604, 226);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(198, 29);
            this.textBox2.TabIndex = 157;
            // 
            // Version
            // 
            this.Version.AutoSize = true;
            this.Version.Location = new System.Drawing.Point(404, 237);
            this.Version.Name = "Version";
            this.Version.Size = new System.Drawing.Size(115, 18);
            this.Version.TabIndex = 156;
            this.Version.Text = "Product version";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(604, 820);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(198, 29);
            this.textBox3.TabIndex = 159;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(404, 831);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(96, 18);
            this.label19.TabIndex = 158;
            this.label19.Text = "Customer_Id";
            // 
            // Link1
            // 
            this.Link1.Location = new System.Drawing.Point(1324, 58);
            this.Link1.Name = "Link1";
            this.Link1.Size = new System.Drawing.Size(264, 42);
            this.Link1.TabIndex = 160;
            this.Link1.Text = "Link";
            this.Link1.UseVisualStyleBackColor = true;
            this.Link1.Click += new System.EventHandler(this.Link1_Click);
            // 
            // Link2
            // 
            this.Link2.Location = new System.Drawing.Point(1324, 160);
            this.Link2.Name = "Link2";
            this.Link2.Size = new System.Drawing.Size(264, 42);
            this.Link2.TabIndex = 161;
            this.Link2.Text = "Link";
            this.Link2.UseVisualStyleBackColor = true;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(1166, 860);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(254, 57);
            this.Delete.TabIndex = 162;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // lblProductName
            // 
            this.lblProductName.Location = new System.Drawing.Point(604, 58);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(198, 29);
            this.lblProductName.TabIndex = 133;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(404, 69);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(70, 18);
            this.label14.TabIndex = 130;
            this.label14.Text = "Order_Id";
            this.label14.Click += new System.EventHandler(this.label14_Click_1);
            // 
            // Order1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1768, 938);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Link2);
            this.Controls.Add(this.Link1);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.Version);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Next);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.State);
            this.Controls.Add(this.txtResponseStaff);
            this.Controls.Add(this.ResponseStaff);
            this.Controls.Add(this.txtShippingOption);
            this.Controls.Add(this.txtFinishDate);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.ShippingOption);
            this.Controls.Add(this.FinishDate);
            this.Controls.Add(this.StartDate);
            this.Controls.Add(this.txtProduct_Cost);
            this.Controls.Add(this.txtDepartment_Id);
            this.Controls.Add(this.txtColumn);
            this.Controls.Add(this.Order_Cost);
            this.Controls.Add(this.Department_Id);
            this.Controls.Add(this.Column);
            this.Controls.Add(this.lblProductDescription);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.lblProductId);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Name = "Order1";
            this.Text = "Product2";
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource productBindingSource;
        private Database1DataSet1TableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmnetIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox lblProductId;
        private System.Windows.Forms.TextBox lblProductDescription;
        private System.Windows.Forms.TextBox txtProduct_Cost;
        private System.Windows.Forms.TextBox txtDepartment_Id;
        private System.Windows.Forms.TextBox txtColumn;
        private System.Windows.Forms.Label Order_Cost;
        private System.Windows.Forms.Label Department_Id;
        private System.Windows.Forms.Label Column;
        private System.Windows.Forms.TextBox txtShippingOption;
        private System.Windows.Forms.TextBox txtFinishDate;
        private System.Windows.Forms.TextBox txtStartDate;
        private System.Windows.Forms.Label ShippingOption;
        private System.Windows.Forms.Label FinishDate;
        private System.Windows.Forms.Label StartDate;
        private System.Windows.Forms.TextBox txtResponseStaff;
        private System.Windows.Forms.Label ResponseStaff;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.Button Next;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label Version;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button Link1;
        private System.Windows.Forms.Button Link2;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.TextBox lblProductName;
        private System.Windows.Forms.Label label14;
    }
}