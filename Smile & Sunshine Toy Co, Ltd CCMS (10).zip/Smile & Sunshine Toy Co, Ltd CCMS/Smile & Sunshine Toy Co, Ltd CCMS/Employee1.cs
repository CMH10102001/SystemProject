﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Employee1 : Form
    {
        public string staff_Id { get; set; }
        public string department_Id { get; set; }

        public Employee1()
        {
            InitializeComponent();
        }
        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void label4_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Product frm = new Product();
            frm.ShowDialog();
        }

        private void Employee1_Load(object sender, EventArgs e)
        {
            label13.Visible = false;
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }

            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007")
            {

            }
            else
            {
                MessageBox.Show("Only D007 has access");
                Close();
            }

            txtStaff_Id.Text = staff_Id;
            txtDepartment_Id.Text = department_Id;
            txtPassword.Text = GetDataFromDatabase("Select Password from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtPosition_Id.Text = GetDataFromDatabase("Select Position_Id from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtWork.Text = GetDataFromDatabase("Select Work from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtSalary.Text = GetDataFromDatabase("Select Salary from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtEmail.Text = GetDataFromDatabase("Select Email from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtPhoneNo.Text = GetDataFromDatabase("Select PhoneNo from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtContact.Text = GetDataFromDatabase("Select Contact from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtLeader.Text = GetDataFromDatabase("Select Leader from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtCompany.Text = GetDataFromDatabase("Select Company from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtJobTitle.Text = GetDataFromDatabase("Select JobTitle from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtStaffName.Text = GetDataFromDatabase("Select StaffName from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            txtState.Text = GetDataFromDatabase("Select [State] from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");

            if (txtState.Text == "")
            {
                GetDataFromDatabase("Update [Staff] set [State] = 'On job' where [Staff_Id] = '" + txtStaff_Id.Text + "';");
                txtState.Text = GetDataFromDatabase("Select [State] from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
            }


            label13.Text = "Staff_Id: " + txtStaff_Id.Text + ", Password: '" + txtPassword.Text + ", Department_Id: " + txtDepartment_Id.Text + ", Position_Id: " + Position_Id.Text + ", Work: " + txtWork.Text + ", Salary: " + txtSalary.Text + ", Email :" + txtEmail.Text + ", PhoneNo: " + txtPhoneNo.Text + ", Content: " + txtContact.Text + ", Leader: " + txtLeader.Text + ", Company: " + txtCompany.Text + ", JobTitle: " + txtJobTitle.Text + ", StaffName: " + txtStaffName.Text + ", State: " + txtState.Text;
        }



        private void label1_Click(object sender, EventArgs e)
        {
            Home frm = new Home();
            frm.ShowDialog();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            frm.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Leads frm = new Leads();
            frm.ShowDialog();
        }

        private void Modify_Click(object sender, EventArgs e)
        {

            try
            {
                GetDataFromDatabase("UPDATE [Staff] SET " +
                                    "[Staff_Id] = '" + txtStaff_Id.Text.Replace("'", "''") + "', " +
                                    "[Password] = '" + txtPassword.Text.Replace("'", "''") + "', " +
                                    "[Department_Id] = '" + txtDepartment_Id.Text.Replace("'", "''") + "', " +
                                    "[Position_Id] = '" + txtPosition_Id.Text.Replace("'", "''") + "', " +
                                    "[Work] = '" + txtWork.Text.Replace("'", "''") + "', " +
                                    "[Salary] = " + (int.TryParse(txtSalary.Text, out int salary) ? salary : 0) + ", " +
                                    "[Email] = '" + txtEmail.Text.Replace("'", "''") + "', " +
                                    "[PhoneNo] = '" + txtPhoneNo.Text.Replace("'", "''") + "', " +
                                    "[Contact] = '" + txtContact.Text.Replace("'", "''") + "', " +
                                    "[Leader] = '" + txtLeader.Text.Replace("'", "''") + "', " +
                                    "[Company] = '" + txtCompany.Text.Replace("'", "''") + "', " +
                                    "[JobTitle] = '" + txtJobTitle.Text.Replace("'", "''") + "', " +
                                    "[StaffName] = '" + txtStaffName.Text.Replace("'", "''") + "', " +
                                    "[State] = '" + txtState.Text.Replace("'", "''") + "' " +
                                    "WHERE [Staff_Id] = '" + txtStaff_Id.Text.Replace("'", "''") + "';");


                String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
                String Department = GetDataFromDatabase("Select Department_Id from [Data]");
                String exchange = "Staff_Id: " + txtStaff_Id.Text + ", Password: '" + txtPassword.Text + ", Department_Id: " + txtDepartment_Id.Text + ", Position_Id: " + Position_Id.Text + ", Work: " + txtWork.Text + ", Salary: " + txtSalary.Text + ", Email :" + txtEmail.Text + ", PhoneNo: " + txtPhoneNo.Text + ", Content: " + txtContact.Text + ", Leader: " + txtLeader.Text + ", Company: " + txtCompany.Text + ", JobTitle: " + txtJobTitle.Text + ", StaffName: " + txtStaffName.Text + ", State: " + txtState.Text;


                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                  "VALUES ('" +
                  Id.Replace("'", "''") + "', '" +
                  Department.Replace("'", "''") + "', '" +
                  label13.Text.Replace("'", "''") + "', '" +
                  exchange.Replace("'", "''") + "');");

                MessageBox.Show("Update Successful");
                Close();
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter: " + ea.Message);
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Staff where Staff_Id = '" + txtStaff_Id.Text + "';");
                Close();
                MessageBox.Show("Delete successful");
            }

            string sanitizedLabel16 = label13.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
