﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Inventory : Form
    {
        public Inventory()
        {
            InitializeComponent();
        }

        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb";

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Inventory_Load(object sender, EventArgs e)
        {
            dataGridView1.ReadOnly = true;
            UpdateGrid("Select * from Inventroy");
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D004")
            {

            }
            else
            {
                MessageBox.Show("Only D004 and D007 has access");
                Close();
            }

            dataGridView1.CellClick += dataGridView1_CellClick;

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }


        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string Supplier_Id = selectedRow.Cells["Supplier_Id"].Value?.ToString() ?? string.Empty;
                string Material_Id = selectedRow.Cells["MaterialID"].Value?.ToString() ?? string.Empty;

                Inventory1 InventoryForm = new Inventory1
                {
                    supplier_Id = Supplier_Id,
                    material_Id = Material_Id
                };

                InventoryForm.ShowDialog();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (search.Text.Length >= 1)
                {
                    UpdateGrid("Select * from Inventroy where Material_Id = " + int.Parse(search.Text) + ";");
                }
                else
                {
                    UpdateGrid("Select * from Inventroy ");
                }
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error search");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Inventroy ");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Inventory2 InventoryForm = new Inventory2();
            InventoryForm.ShowDialog();
        }
    }
}
