﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Customer2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhone_Number = new System.Windows.Forms.TextBox();
            this.Customer_Name = new System.Windows.Forms.Label();
            this.txtCustomer_Name = new System.Windows.Forms.TextBox();
            this.Customer_Address = new System.Windows.Forms.Label();
            this.txtCustomer_Address = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Customer_Id = new System.Windows.Forms.Label();
            this.txtCustomer_Id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(710, 763);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(204, 64);
            this.Add.TabIndex = 277;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(860, 57);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 248;
            this.label12.Text = "Admin";
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(37, 427);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(112, 18);
            this.Phone_Number.TabIndex = 287;
            this.Phone_Number.Text = "Phone_Number";
            // 
            // txtPhone_Number
            // 
            this.txtPhone_Number.Location = new System.Drawing.Point(193, 423);
            this.txtPhone_Number.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone_Number.Name = "txtPhone_Number";
            this.txtPhone_Number.Size = new System.Drawing.Size(259, 29);
            this.txtPhone_Number.TabIndex = 286;
            // 
            // Customer_Name
            // 
            this.Customer_Name.AutoSize = true;
            this.Customer_Name.Location = new System.Drawing.Point(38, 255);
            this.Customer_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Name.Name = "Customer_Name";
            this.Customer_Name.Size = new System.Drawing.Size(123, 18);
            this.Customer_Name.TabIndex = 285;
            this.Customer_Name.Text = "Customer_Name";
            // 
            // txtCustomer_Name
            // 
            this.txtCustomer_Name.Location = new System.Drawing.Point(193, 251);
            this.txtCustomer_Name.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Name.Name = "txtCustomer_Name";
            this.txtCustomer_Name.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Name.TabIndex = 284;
            // 
            // Customer_Address
            // 
            this.Customer_Address.AutoSize = true;
            this.Customer_Address.Location = new System.Drawing.Point(37, 309);
            this.Customer_Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Address.Name = "Customer_Address";
            this.Customer_Address.Size = new System.Drawing.Size(138, 18);
            this.Customer_Address.TabIndex = 283;
            this.Customer_Address.Text = "Customer_Address";
            // 
            // txtCustomer_Address
            // 
            this.txtCustomer_Address.Location = new System.Drawing.Point(193, 307);
            this.txtCustomer_Address.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Address.Name = "txtCustomer_Address";
            this.txtCustomer_Address.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Address.TabIndex = 282;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(37, 371);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 281;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(193, 367);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 280;
            // 
            // Customer_Id
            // 
            this.Customer_Id.AutoSize = true;
            this.Customer_Id.Location = new System.Drawing.Point(38, 199);
            this.Customer_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Id.Name = "Customer_Id";
            this.Customer_Id.Size = new System.Drawing.Size(96, 18);
            this.Customer_Id.TabIndex = 279;
            this.Customer_Id.Text = "Customer_Id";
            // 
            // txtCustomer_Id
            // 
            this.txtCustomer_Id.Location = new System.Drawing.Point(193, 195);
            this.txtCustomer_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Id.Name = "txtCustomer_Id";
            this.txtCustomer_Id.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Id.TabIndex = 278;
            // 
            // Customer2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1043, 860);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhone_Number);
            this.Controls.Add(this.Customer_Name);
            this.Controls.Add(this.txtCustomer_Name);
            this.Controls.Add(this.Customer_Address);
            this.Controls.Add(this.txtCustomer_Address);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Customer_Id);
            this.Controls.Add(this.txtCustomer_Id);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label12);
            this.Name = "Customer2";
            this.Text = "Customer2";
            this.Load += new System.EventHandler(this.Customer2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhone_Number;
        private System.Windows.Forms.Label Customer_Name;
        private System.Windows.Forms.TextBox txtCustomer_Name;
        private System.Windows.Forms.Label Customer_Address;
        private System.Windows.Forms.TextBox txtCustomer_Address;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Customer_Id;
        private System.Windows.Forms.TextBox txtCustomer_Id;
    }
}