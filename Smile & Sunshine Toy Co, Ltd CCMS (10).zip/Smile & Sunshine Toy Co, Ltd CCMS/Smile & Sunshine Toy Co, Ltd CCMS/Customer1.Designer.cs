﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Customer1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label13 = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.Modify = new System.Windows.Forms.Button();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhone_Number = new System.Windows.Forms.TextBox();
            this.Customer_Name = new System.Windows.Forms.Label();
            this.txtCustomer_Name = new System.Windows.Forms.TextBox();
            this.Customer_Address = new System.Windows.Forms.Label();
            this.txtCustomer_Address = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Customer_Id = new System.Windows.Forms.Label();
            this.txtCustomer_Id = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(17, 41);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 18);
            this.label13.TabIndex = 253;
            this.label13.Text = "Admin";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(667, 1050);
            this.Delete.Margin = new System.Windows.Forms.Padding(4);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(204, 64);
            this.Delete.TabIndex = 252;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(907, 1050);
            this.Modify.Margin = new System.Windows.Forms.Padding(4);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(204, 64);
            this.Modify.TabIndex = 251;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(17, 328);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(112, 18);
            this.Phone_Number.TabIndex = 236;
            this.Phone_Number.Text = "Phone_Number";
            // 
            // txtPhone_Number
            // 
            this.txtPhone_Number.Location = new System.Drawing.Point(173, 324);
            this.txtPhone_Number.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone_Number.Name = "txtPhone_Number";
            this.txtPhone_Number.Size = new System.Drawing.Size(259, 29);
            this.txtPhone_Number.TabIndex = 235;
            // 
            // Customer_Name
            // 
            this.Customer_Name.AutoSize = true;
            this.Customer_Name.Location = new System.Drawing.Point(18, 156);
            this.Customer_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Name.Name = "Customer_Name";
            this.Customer_Name.Size = new System.Drawing.Size(123, 18);
            this.Customer_Name.TabIndex = 234;
            this.Customer_Name.Text = "Customer_Name";
            // 
            // txtCustomer_Name
            // 
            this.txtCustomer_Name.Location = new System.Drawing.Point(173, 152);
            this.txtCustomer_Name.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Name.Name = "txtCustomer_Name";
            this.txtCustomer_Name.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Name.TabIndex = 233;
            // 
            // Customer_Address
            // 
            this.Customer_Address.AutoSize = true;
            this.Customer_Address.Location = new System.Drawing.Point(17, 210);
            this.Customer_Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Address.Name = "Customer_Address";
            this.Customer_Address.Size = new System.Drawing.Size(138, 18);
            this.Customer_Address.TabIndex = 232;
            this.Customer_Address.Text = "Customer_Address";
            // 
            // txtCustomer_Address
            // 
            this.txtCustomer_Address.Location = new System.Drawing.Point(173, 208);
            this.txtCustomer_Address.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Address.Name = "txtCustomer_Address";
            this.txtCustomer_Address.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Address.TabIndex = 231;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(17, 272);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 226;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(173, 268);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 225;
            // 
            // Customer_Id
            // 
            this.Customer_Id.AutoSize = true;
            this.Customer_Id.Location = new System.Drawing.Point(18, 100);
            this.Customer_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Customer_Id.Name = "Customer_Id";
            this.Customer_Id.Size = new System.Drawing.Size(96, 18);
            this.Customer_Id.TabIndex = 224;
            this.Customer_Id.Text = "Customer_Id";
            // 
            // txtCustomer_Id
            // 
            this.txtCustomer_Id.Location = new System.Drawing.Point(173, 96);
            this.txtCustomer_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtCustomer_Id.Name = "txtCustomer_Id";
            this.txtCustomer_Id.Size = new System.Drawing.Size(259, 29);
            this.txtCustomer_Id.TabIndex = 223;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1057, 41);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 222;
            this.label12.Text = "Admin";
            // 
            // Customer1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1196, 1152);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhone_Number);
            this.Controls.Add(this.Customer_Name);
            this.Controls.Add(this.txtCustomer_Name);
            this.Controls.Add(this.Customer_Address);
            this.Controls.Add(this.txtCustomer_Address);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Customer_Id);
            this.Controls.Add(this.txtCustomer_Id);
            this.Controls.Add(this.label12);
            this.Name = "Customer1";
            this.Text = "Customer1";
            this.Load += new System.EventHandler(this.Customer1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhone_Number;
        private System.Windows.Forms.Label Customer_Name;
        private System.Windows.Forms.TextBox txtCustomer_Name;
        private System.Windows.Forms.Label Customer_Address;
        private System.Windows.Forms.TextBox txtCustomer_Address;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Customer_Id;
        private System.Windows.Forms.TextBox txtCustomer_Id;
        private System.Windows.Forms.Label label12;
    }
}