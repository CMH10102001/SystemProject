﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Companies2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label label22;
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Address = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.Supplier_Name = new System.Windows.Forms.Label();
            this.txtSupplier_Name = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhone_Number = new System.Windows.Forms.TextBox();
            this.Tax = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            label22 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new System.Drawing.Point(1932, 836);
            label22.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(107, 18);
            label22.TabIndex = 190;
            label22.Text = "Form_Number";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(2055, 831);
            this.textBox9.Margin = new System.Windows.Forms.Padding(6);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(220, 29);
            this.textBox9.TabIndex = 191;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2288, 818);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 56);
            this.button1.TabIndex = 192;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(356, 490);
            this.Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(64, 18);
            this.Address.TabIndex = 212;
            this.Address.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(512, 488);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(259, 29);
            this.txtAddress.TabIndex = 211;
            // 
            // Supplier_Name
            // 
            this.Supplier_Name.AutoSize = true;
            this.Supplier_Name.Location = new System.Drawing.Point(357, 320);
            this.Supplier_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Supplier_Name.Name = "Supplier_Name";
            this.Supplier_Name.Size = new System.Drawing.Size(114, 18);
            this.Supplier_Name.TabIndex = 210;
            this.Supplier_Name.Text = "Supplier_Name";
            // 
            // txtSupplier_Name
            // 
            this.txtSupplier_Name.Location = new System.Drawing.Point(512, 315);
            this.txtSupplier_Name.Margin = new System.Windows.Forms.Padding(4);
            this.txtSupplier_Name.Name = "txtSupplier_Name";
            this.txtSupplier_Name.Size = new System.Drawing.Size(259, 29);
            this.txtSupplier_Name.TabIndex = 209;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(356, 374);
            this.Material_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(90, 18);
            this.Material_Id.TabIndex = 208;
            this.Material_Id.Text = "Material_Id";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(512, 370);
            this.txtMaterial_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Id.TabIndex = 207;
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(356, 609);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(112, 18);
            this.Phone_Number.TabIndex = 206;
            this.Phone_Number.Text = "Phone_Number";
            // 
            // txtPhone_Number
            // 
            this.txtPhone_Number.Location = new System.Drawing.Point(512, 604);
            this.txtPhone_Number.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone_Number.Name = "txtPhone_Number";
            this.txtPhone_Number.Size = new System.Drawing.Size(259, 29);
            this.txtPhone_Number.TabIndex = 205;
            // 
            // Tax
            // 
            this.Tax.AutoSize = true;
            this.Tax.Location = new System.Drawing.Point(356, 554);
            this.Tax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tax.Name = "Tax";
            this.Tax.Size = new System.Drawing.Size(34, 18);
            this.Tax.TabIndex = 204;
            this.Tax.Text = "Tax";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(512, 549);
            this.txtTax.Margin = new System.Windows.Forms.Padding(4);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(259, 29);
            this.txtTax.TabIndex = 203;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(356, 435);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 202;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(512, 430);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 201;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1174, 48);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 198;
            this.label12.Text = "Admin";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(848, 902);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(204, 64);
            this.Add.TabIndex = 214;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Companies2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1322, 1068);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.Supplier_Name);
            this.Controls.Add(this.txtSupplier_Name);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtMaterial_Id);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhone_Number);
            this.Controls.Add(this.Tax);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.button1);
            this.Controls.Add(label22);
            this.Controls.Add(this.textBox9);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Companies2";
            this.Text = "Companies2";
            this.Load += new System.EventHandler(this.Companies2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridViewTextBoxColumn formNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryDataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label Supplier_Name;
        private System.Windows.Forms.TextBox txtSupplier_Name;
        private System.Windows.Forms.Label Material_Id;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhone_Number;
        private System.Windows.Forms.Label Tax;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Add;
    }
}