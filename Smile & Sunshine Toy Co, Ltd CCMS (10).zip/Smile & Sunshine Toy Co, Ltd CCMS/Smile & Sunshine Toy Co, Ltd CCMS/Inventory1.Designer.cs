﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Inventory1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Modify = new System.Windows.Forms.Button();
            this.Content = new System.Windows.Forms.Label();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.EachCost = new System.Windows.Forms.Label();
            this.txtEachCost = new System.Windows.Forms.TextBox();
            this.Material_Name = new System.Windows.Forms.Label();
            this.txtMaterialName = new System.Windows.Forms.TextBox();
            this.Expected_Qty = new System.Windows.Forms.Label();
            this.txtExpected_Qty = new System.Windows.Forms.TextBox();
            this.Current_Qty = new System.Windows.Forms.Label();
            this.txtCurrent_Qty = new System.Windows.Forms.TextBox();
            this.Material_Type = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.Supplier_Id = new System.Windows.Forms.Label();
            this.txtSupplier_Id = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(406, 28);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 18);
            this.label13.TabIndex = 210;
            this.label13.Text = "Admin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1194, 28);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 209;
            this.label12.Text = "Admin";
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(1066, 850);
            this.Modify.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(204, 64);
            this.Modify.TabIndex = 208;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // Content
            // 
            this.Content.AutoSize = true;
            this.Content.Location = new System.Drawing.Point(404, 638);
            this.Content.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Content.Name = "Content";
            this.Content.Size = new System.Drawing.Size(61, 18);
            this.Content.TabIndex = 207;
            this.Content.Text = "Content";
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(560, 632);
            this.txtContent.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(259, 29);
            this.txtContent.TabIndex = 206;
            // 
            // EachCost
            // 
            this.EachCost.AutoSize = true;
            this.EachCost.Location = new System.Drawing.Point(404, 584);
            this.EachCost.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.EachCost.Name = "EachCost";
            this.EachCost.Size = new System.Drawing.Size(73, 18);
            this.EachCost.TabIndex = 205;
            this.EachCost.Text = "EachCost";
            // 
            // txtEachCost
            // 
            this.txtEachCost.Location = new System.Drawing.Point(560, 578);
            this.txtEachCost.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtEachCost.Name = "txtEachCost";
            this.txtEachCost.Size = new System.Drawing.Size(259, 29);
            this.txtEachCost.TabIndex = 204;
            // 
            // Material_Name
            // 
            this.Material_Name.AutoSize = true;
            this.Material_Name.Location = new System.Drawing.Point(404, 286);
            this.Material_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Name.Name = "Material_Name";
            this.Material_Name.Size = new System.Drawing.Size(117, 18);
            this.Material_Name.TabIndex = 203;
            this.Material_Name.Text = "Material_Name";
            // 
            // txtMaterialName
            // 
            this.txtMaterialName.Location = new System.Drawing.Point(560, 284);
            this.txtMaterialName.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaterialName.Name = "txtMaterialName";
            this.txtMaterialName.Size = new System.Drawing.Size(259, 29);
            this.txtMaterialName.TabIndex = 202;
            // 
            // Expected_Qty
            // 
            this.Expected_Qty.AutoSize = true;
            this.Expected_Qty.Location = new System.Drawing.Point(404, 518);
            this.Expected_Qty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Expected_Qty.Name = "Expected_Qty";
            this.Expected_Qty.Size = new System.Drawing.Size(104, 18);
            this.Expected_Qty.TabIndex = 197;
            this.Expected_Qty.Text = "Expected_Qty";
            // 
            // txtExpected_Qty
            // 
            this.txtExpected_Qty.Location = new System.Drawing.Point(560, 514);
            this.txtExpected_Qty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtExpected_Qty.Name = "txtExpected_Qty";
            this.txtExpected_Qty.Size = new System.Drawing.Size(259, 29);
            this.txtExpected_Qty.TabIndex = 196;
            // 
            // Current_Qty
            // 
            this.Current_Qty.AutoSize = true;
            this.Current_Qty.Location = new System.Drawing.Point(404, 464);
            this.Current_Qty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Current_Qty.Name = "Current_Qty";
            this.Current_Qty.Size = new System.Drawing.Size(93, 18);
            this.Current_Qty.TabIndex = 195;
            this.Current_Qty.Text = "Current_Qty";
            // 
            // txtCurrent_Qty
            // 
            this.txtCurrent_Qty.Location = new System.Drawing.Point(560, 460);
            this.txtCurrent_Qty.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtCurrent_Qty.Name = "txtCurrent_Qty";
            this.txtCurrent_Qty.Size = new System.Drawing.Size(259, 29);
            this.txtCurrent_Qty.TabIndex = 194;
            // 
            // Material_Type
            // 
            this.Material_Type.AutoSize = true;
            this.Material_Type.Location = new System.Drawing.Point(404, 410);
            this.Material_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Type.Name = "Material_Type";
            this.Material_Type.Size = new System.Drawing.Size(110, 18);
            this.Material_Type.TabIndex = 193;
            this.Material_Type.Text = "Material_Type";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(560, 404);
            this.txtType.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(259, 29);
            this.txtType.TabIndex = 192;
            // 
            // Supplier_Id
            // 
            this.Supplier_Id.AutoSize = true;
            this.Supplier_Id.Location = new System.Drawing.Point(404, 344);
            this.Supplier_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Supplier_Id.Name = "Supplier_Id";
            this.Supplier_Id.Size = new System.Drawing.Size(87, 18);
            this.Supplier_Id.TabIndex = 191;
            this.Supplier_Id.Text = "Supplier_Id";
            // 
            // txtSupplier_Id
            // 
            this.txtSupplier_Id.Location = new System.Drawing.Point(560, 340);
            this.txtSupplier_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtSupplier_Id.Name = "txtSupplier_Id";
            this.txtSupplier_Id.Size = new System.Drawing.Size(259, 29);
            this.txtSupplier_Id.TabIndex = 190;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(404, 226);
            this.Material_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(90, 18);
            this.Material_Id.TabIndex = 189;
            this.Material_Id.Text = "Material_Id";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(560, 224);
            this.txtMaterial_Id.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Id.TabIndex = 188;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(828, 850);
            this.Delete.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(204, 64);
            this.Delete.TabIndex = 211;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Inventory1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1395, 1084);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Content);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.EachCost);
            this.Controls.Add(this.txtEachCost);
            this.Controls.Add(this.Material_Name);
            this.Controls.Add(this.txtMaterialName);
            this.Controls.Add(this.Expected_Qty);
            this.Controls.Add(this.txtExpected_Qty);
            this.Controls.Add(this.Current_Qty);
            this.Controls.Add(this.txtCurrent_Qty);
            this.Controls.Add(this.Material_Type);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.Supplier_Id);
            this.Controls.Add(this.txtSupplier_Id);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtMaterial_Id);
            this.Name = "Inventory1";
            this.Text = "Inventory1";
            this.Load += new System.EventHandler(this.Inventory1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label Content;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label EachCost;
        private System.Windows.Forms.TextBox txtEachCost;
        private System.Windows.Forms.Label Material_Name;
        private System.Windows.Forms.TextBox txtMaterialName;
        private System.Windows.Forms.Label Expected_Qty;
        private System.Windows.Forms.TextBox txtExpected_Qty;
        private System.Windows.Forms.Label Current_Qty;
        private System.Windows.Forms.TextBox txtCurrent_Qty;
        private System.Windows.Forms.Label Material_Type;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label Supplier_Id;
        private System.Windows.Forms.TextBox txtSupplier_Id;
        private System.Windows.Forms.Label Material_Id;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Button Delete;
    }
}