﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Order2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.txtResponseStaff = new System.Windows.Forms.TextBox();
            this.ResponseStaff = new System.Windows.Forms.Label();
            this.txtShippingOption = new System.Windows.Forms.TextBox();
            this.txtFinishDate = new System.Windows.Forms.TextBox();
            this.txtStartDate = new System.Windows.Forms.TextBox();
            this.ShippingOption = new System.Windows.Forms.Label();
            this.FinishDate = new System.Windows.Forms.Label();
            this.StartDate = new System.Windows.Forms.Label();
            this.txtProduct_Cost = new System.Windows.Forms.TextBox();
            this.txtColumn = new System.Windows.Forms.TextBox();
            this.Order_Cost = new System.Windows.Forms.Label();
            this.Column = new System.Windows.Forms.Label();
            this.lblProductDescription = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.txtVersion = new System.Windows.Forms.TextBox();
            this.Version = new System.Windows.Forms.Label();
            this.Company = new System.Windows.Forms.CheckBox();
            this.SuspendLayout();
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(589, 605);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(198, 29);
            this.textBox3.TabIndex = 204;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(388, 616);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(96, 18);
            this.label19.TabIndex = 203;
            this.label19.Text = "Customer_Id";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(589, 338);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(198, 29);
            this.textBox1.TabIndex = 200;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(388, 349);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(74, 18);
            this.label17.TabIndex = 199;
            this.label17.Text = "Comment";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(1103, 876);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(262, 59);
            this.Add.TabIndex = 197;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // txtResponseStaff
            // 
            this.txtResponseStaff.Location = new System.Drawing.Point(589, 276);
            this.txtResponseStaff.Name = "txtResponseStaff";
            this.txtResponseStaff.Size = new System.Drawing.Size(198, 29);
            this.txtResponseStaff.TabIndex = 193;
            this.txtResponseStaff.TextChanged += new System.EventHandler(this.txtResponseStaff_TextChanged);
            // 
            // ResponseStaff
            // 
            this.ResponseStaff.AutoSize = true;
            this.ResponseStaff.Location = new System.Drawing.Point(388, 287);
            this.ResponseStaff.Name = "ResponseStaff";
            this.ResponseStaff.Size = new System.Drawing.Size(112, 18);
            this.ResponseStaff.TabIndex = 192;
            this.ResponseStaff.Text = "Response Staff";
            // 
            // txtShippingOption
            // 
            this.txtShippingOption.Location = new System.Drawing.Point(589, 536);
            this.txtShippingOption.Name = "txtShippingOption";
            this.txtShippingOption.Size = new System.Drawing.Size(198, 29);
            this.txtShippingOption.TabIndex = 191;
            this.txtShippingOption.TextChanged += new System.EventHandler(this.txtShippingOption_TextChanged);
            // 
            // txtFinishDate
            // 
            this.txtFinishDate.Location = new System.Drawing.Point(589, 471);
            this.txtFinishDate.Name = "txtFinishDate";
            this.txtFinishDate.Size = new System.Drawing.Size(198, 29);
            this.txtFinishDate.TabIndex = 190;
            this.txtFinishDate.TextChanged += new System.EventHandler(this.txtFinishDate_TextChanged);
            // 
            // txtStartDate
            // 
            this.txtStartDate.Location = new System.Drawing.Point(589, 410);
            this.txtStartDate.Name = "txtStartDate";
            this.txtStartDate.Size = new System.Drawing.Size(198, 29);
            this.txtStartDate.TabIndex = 189;
            this.txtStartDate.TextChanged += new System.EventHandler(this.txtStartDate_TextChanged);
            // 
            // ShippingOption
            // 
            this.ShippingOption.AutoSize = true;
            this.ShippingOption.Location = new System.Drawing.Point(388, 547);
            this.ShippingOption.Name = "ShippingOption";
            this.ShippingOption.Size = new System.Drawing.Size(118, 18);
            this.ShippingOption.TabIndex = 188;
            this.ShippingOption.Text = "ShippingOption:";
            // 
            // FinishDate
            // 
            this.FinishDate.AutoSize = true;
            this.FinishDate.Location = new System.Drawing.Point(388, 482);
            this.FinishDate.Name = "FinishDate";
            this.FinishDate.Size = new System.Drawing.Size(88, 18);
            this.FinishDate.TabIndex = 187;
            this.FinishDate.Text = "FinishDate:";
            // 
            // StartDate
            // 
            this.StartDate.AutoSize = true;
            this.StartDate.Location = new System.Drawing.Point(388, 421);
            this.StartDate.Name = "StartDate";
            this.StartDate.Size = new System.Drawing.Size(79, 18);
            this.StartDate.TabIndex = 186;
            this.StartDate.Text = "StartDate:";
            // 
            // txtProduct_Cost
            // 
            this.txtProduct_Cost.Location = new System.Drawing.Point(589, 78);
            this.txtProduct_Cost.Name = "txtProduct_Cost";
            this.txtProduct_Cost.Size = new System.Drawing.Size(198, 29);
            this.txtProduct_Cost.TabIndex = 185;
            this.txtProduct_Cost.TextChanged += new System.EventHandler(this.txtProduct_Cost_TextChanged);
            // 
            // txtColumn
            // 
            this.txtColumn.Location = new System.Drawing.Point(589, 145);
            this.txtColumn.Name = "txtColumn";
            this.txtColumn.Size = new System.Drawing.Size(198, 29);
            this.txtColumn.TabIndex = 183;
            this.txtColumn.TextChanged += new System.EventHandler(this.txtColumn_TextChanged);
            // 
            // Order_Cost
            // 
            this.Order_Cost.AutoSize = true;
            this.Order_Cost.Location = new System.Drawing.Point(388, 89);
            this.Order_Cost.Name = "Order_Cost";
            this.Order_Cost.Size = new System.Drawing.Size(92, 18);
            this.Order_Cost.TabIndex = 182;
            this.Order_Cost.Text = "Order_Cost:";
            // 
            // Column
            // 
            this.Column.AutoSize = true;
            this.Column.Location = new System.Drawing.Point(388, 156);
            this.Column.Name = "Column";
            this.Column.Size = new System.Drawing.Size(72, 24);
            this.Column.TabIndex = 180;
            this.Column.Text = "Column: ";
            this.Column.UseCompatibleTextRendering = true;
            // 
            // lblProductDescription
            // 
            this.lblProductDescription.Location = new System.Drawing.Point(589, 214);
            this.lblProductDescription.Name = "lblProductDescription";
            this.lblProductDescription.Size = new System.Drawing.Size(198, 29);
            this.lblProductDescription.TabIndex = 179;
            this.lblProductDescription.TextChanged += new System.EventHandler(this.lblProductDescription_TextChanged);
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(388, 225);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(145, 18);
            this.label15.TabIndex = 176;
            this.label15.Text = "Product Description";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1311, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 160;
            this.label12.Text = "Admin";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(1167, 224);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(198, 29);
            this.txtProduct_Id.TabIndex = 206;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(966, 235);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(87, 18);
            this.Product_Id.TabIndex = 205;
            this.Product_Id.Text = "Product_Id:";
            // 
            // txtVersion
            // 
            this.txtVersion.Location = new System.Drawing.Point(1167, 281);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.Size = new System.Drawing.Size(198, 29);
            this.txtVersion.TabIndex = 209;
            // 
            // Version
            // 
            this.Version.AutoSize = true;
            this.Version.Location = new System.Drawing.Point(966, 292);
            this.Version.Name = "Version";
            this.Version.Size = new System.Drawing.Size(62, 18);
            this.Version.TabIndex = 208;
            this.Version.Text = "Version";
            // 
            // Company
            // 
            this.Company.AutoSize = true;
            this.Company.Location = new System.Drawing.Point(969, 178);
            this.Company.Name = "Company";
            this.Company.Size = new System.Drawing.Size(238, 22);
            this.Company.TabIndex = 210;
            this.Company.Text = "Fill in ,if is Company product";
            this.Company.UseVisualStyleBackColor = true;
            this.Company.CheckedChanged += new System.EventHandler(this.Company_CheckedChanged_1);
            // 
            // Order2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1579, 983);
            this.Controls.Add(this.Company);
            this.Controls.Add(this.txtVersion);
            this.Controls.Add(this.Version);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Product_Id);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.txtResponseStaff);
            this.Controls.Add(this.ResponseStaff);
            this.Controls.Add(this.txtShippingOption);
            this.Controls.Add(this.txtFinishDate);
            this.Controls.Add(this.txtStartDate);
            this.Controls.Add(this.ShippingOption);
            this.Controls.Add(this.FinishDate);
            this.Controls.Add(this.StartDate);
            this.Controls.Add(this.txtProduct_Cost);
            this.Controls.Add(this.txtColumn);
            this.Controls.Add(this.Order_Cost);
            this.Controls.Add(this.Column);
            this.Controls.Add(this.lblProductDescription);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label12);
            this.Name = "Order2";
            this.Text = "Order2";
            this.Load += new System.EventHandler(this.Order2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.TextBox txtResponseStaff;
        private System.Windows.Forms.Label ResponseStaff;
        private System.Windows.Forms.TextBox txtShippingOption;
        private System.Windows.Forms.TextBox txtFinishDate;
        private System.Windows.Forms.TextBox txtStartDate;
        private System.Windows.Forms.Label ShippingOption;
        private System.Windows.Forms.Label FinishDate;
        private System.Windows.Forms.Label StartDate;
        private System.Windows.Forms.TextBox txtProduct_Cost;
        private System.Windows.Forms.TextBox txtColumn;
        private System.Windows.Forms.Label Order_Cost;
        private System.Windows.Forms.Label Column;
        private System.Windows.Forms.TextBox lblProductDescription;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.TextBox txtVersion;
        private System.Windows.Forms.Label Version;
        private System.Windows.Forms.CheckBox Company;
    }
}