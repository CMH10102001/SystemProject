﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Reflection.Emit;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Companies : Form
    {

        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb";

        public Companies()
        {
            InitializeComponent();
        }

        private void Companies_Load(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Supplier");
            dataGridView1.ReadOnly = true;
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D004")
            {

            }
            else
            {
                MessageBox.Show("Only D004 and D007 has access");
                Close();
            }

            dataGridView1.CellClick += dataGridView1_CellClick;

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }
        }

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string Supplier_Id = selectedRow.Cells["Supplier_Id"].Value?.ToString() ?? string.Empty;
                string Supplier_Name = selectedRow.Cells["Supplier_Name"].Value?.ToString() ?? string.Empty;
                string Email = selectedRow.Cells["Email"].Value?.ToString() ?? string.Empty;
                string Address = selectedRow.Cells["Address"].Value?.ToString() ?? string.Empty;
                string Tax = selectedRow.Cells["Tax"].Value?.ToString() ?? string.Empty;
                string Phone_Number  = selectedRow.Cells["Phone_ Number"].Value?.ToString() ?? string.Empty;
                string Material_Id = selectedRow.Cells["Material_Id"].Value?.ToString() ?? string.Empty;

                Companies1 CompaniesForm = new Companies1
                {
                    supplier_Id = Supplier_Id,
                    supplier_Name = Supplier_Name,
                    email = Email,
                    address = Address,
                    tax = Tax,
                    phone_Number = Phone_Number,
                    material_Id = Material_Id
                };

                CompaniesForm.ShowDialog();
            }
        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (search.Text.Length >= 1)
                {
                    UpdateGrid("Select * from Supplier where Supplier_Id = " + int.Parse(search.Text) + ";");
                }
                else
                {
                    UpdateGrid("Select * from Supplier");
                }
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error search");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Supplier");
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Companies2 frm = new Companies2();
            frm.ShowDialog();
        }
    }
}
