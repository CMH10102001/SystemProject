﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Security.Cryptography;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Order1 : Form
    {
        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;"+ "Data Source=Database1.accdb";

        private string _productId;
        private string _productName;
        private string _productDescription;
        private int a = 0;

        public Order1(string product_Id, string Order_Id, string productDescription)
        {
            InitializeComponent();
            _productId = product_Id;
            _productName = Order_Id;
            _productDescription = productDescription;
        }

        public Order1()
        {
            InitializeComponent();
        }

        private void label15_AutoSizeChanged(object sender, EventArgs e)
        {

        }
        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {

            Link1.Visible = false;
            Link2.Visible = false;

            lblProductId.Text = _productId;
            lblProductName.Text = _productName;
            lblProductDescription.Text = _productDescription;

            textBox3.Text = GetDataFromDatabase("SELECT [Customer_Id] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            textBox2.Text = GetDataFromDatabase("SELECT [Version] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtColumn.Text = GetDataFromDatabase("SELECT [Column] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtDepartment_Id.Text = GetDataFromDatabase("SELECT [Department_Id] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtResponseStaff.Text = GetDataFromDatabase("SELECT [ResponedStaff] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            textBox1.Text = GetDataFromDatabase("SELECT [Comment] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtProduct_Cost.Text = GetDataFromDatabase("SELECT [Order_Cost] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtStartDate.Text = GetDataFromDatabase("SELECT [StartDate] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtFinishDate.Text = GetDataFromDatabase("SELECT [FinishDate] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            txtShippingOption.Text = GetDataFromDatabase("SELECT [ShippingOption] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");

            txtState.Text = GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            if (txtState.Text == "")
            {
                GetDataFromDatabase("UPDATE [Order] SET State = 'order' WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
                txtState.Text = GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");
            }

            if (txtState.Text == "order")
            {
                txtDepartment_Id.Text = "D008";
            }

            String a = GetDataFromDatabase("Select Department_Id from Data");
            if (a != "D007")
            {
                lblProductId.ReadOnly = true;
                txtDepartment_Id.ReadOnly = true;
                txtState.ReadOnly = true;
                textBox3.ReadOnly = true;
                Delete.Visible = false;
            }
            label16.Visible = false;

            label16.Text = "Product_Id: " + lblProductId.Text + ", Product_Version" + textBox2.Text +", Order_Id: " + lblProductName.Text + ", Comment: " + textBox1.Text + ", Column: " + txtColumn.Text + ", Respon's Department: " + txtDepartment_Id.Text + ", Respon's Staff: " + txtResponseStaff.Text + ", Cost: " + txtProduct_Cost.Text + "Product Description: " + lblProductDescription + ", Start Date: " + txtStartDate.Text + ", Finish Date: " + FinishDate.Text + ", Shipping Option: " + txtShippingOption.Text + ", Customer_Id :" + textBox3.Text  + "State: " + txtState.Text;


            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "order")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" ||  GetDataFromDatabase("Select [Department_Id] from [Data]") == "D008")
                {
                }
                else
                {
                    MessageBox.Show("Only D007, D008 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "pay")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D006")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D006 have access");
                    Close();
                }
            }

            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "pay1")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D006")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D006 have access");
                    Close();
                }
            }
            
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "design")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D001")
                {
                    Link1.Text = "Product Page";
                    Link1.Visible = true;
                }
                else
                {
                    MessageBox.Show("Only D007, D001 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan production" )
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D003")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D003 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material" )
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D003")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D003 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 1")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D004")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D004 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 2")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D004")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D004 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D003")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D003 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production report")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D003")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D003 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan to transport")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D004")
                {

                }
                else
                {
                    MessageBox.Show("Only D007, D004 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "transport")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D004")
                {

                }
                else
                {
                    MessageBox.Show("Only D007,D004 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "final pay")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D006")
                {

                }
                else
                {
                    MessageBox.Show("Only D007,D006 have access");
                    Close();
                }
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "after sale")
            {
                if (GetDataFromDatabase("Select [Department_Id] from [Data]") == "D007" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D005" || GetDataFromDatabase("Select [Department_Id] from [Data]") == "D009")
                {

                }
                else
                {
                    MessageBox.Show("Only D007,D005,D009 have access");
                    Close();
                }
            }

        }

        private void label19_Click(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {

        }

        private void bookIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void authorTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void publisherTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void label18_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label19_Click_1(object sender, EventArgs e)
        {

        }

        private void Department_Id_Click(object sender, EventArgs e)
        {

        }

        private void lblText_Click(object sender, EventArgs e)
        {

        }

        private void bt1_Click(object sender, EventArgs e)
        {
            //The state of Product
            //order                 確認訂單需求，包括產品規格、數量、特殊要求、提供報價（包括價格、交貨時間和運輸選項）。 sales department
            //pay                   核對訂金付款情況 Finance Department
            //plan production       生產經理 (Production Manager) 根據訂單需求制定生產計劃。
            //plan material         生產專員/生產官員 (Production Officer)** 根據訂單制定生產排程。填寫原材料需求表，提交到倉庫部門。
            //plan material 1       倉庫專員 (Inventory Officer)**-檢查庫存，回覆是否充足。-若庫存不足，通知供應鏈管理部門進行採購。
            //production            生產線工人 (Worker Team)** -負責執行具體生產工序，例如模具製作、零件生產、裝飾、組裝和包裝。
            //                      質量控制員(Quality Control Worker) * *-檢查每道工序的產品質量，確保符合標準。
            //production report     生產經理**檢查最終生產報告
            //plan to transport     物流專員 (Logistics Officer) transport the product
            //transport             物流專員**監控配送狀態，確保準時交付。
            //final pay             (Product Arrival)財務部門 (Finance Department)**-在產品交付後，生成最終發票並發送給客戶。
            //After sale            **客服部門 (Customer Service Department)** &&  **技術支持團隊 (Technical Support Team)** &&  **財務部門 (Finance Department)**


            //Cancel                The customer cancel the order

            //                      銷售部門：
            //                      負責接收客戶的取消請求，核查訂單狀況。
            //                      如果取消訂單涉及已經發貨的產品，需與物流部門協調。

            //                      物流部門：
            //                      如果訂單已發貨，負責攔截運輸中的商品（如果可能）。
            //                      如果攔截失敗，協助處理退貨流程。

            //                      財務部門：
            //                      處理退款或支付更改。
            //                      如果是定制產品，需考慮顧問費或其他費用。

            //                      客戶服務部門：
            //                      負責與客戶溝通，記錄取消請求，並跟進處理結果。
            //                      確保客戶滿意並提供後續支持。

            if (a == 1)
            {
                MessageBox.Show("You can not jump two state");
            }

            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "order")
            {
                txtState.Text = "pay";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "pay" && a != 1)
            {
                txtState.Text = "design";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "pay1" && a != 1)
            {
                txtState.Text = "plan production";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "design" && a != 1)
            {
                txtState.Text = "plan production";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan production" && a != 1)
            {
                txtState.Text = "plan material";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material" && a != 1)
            {
                txtState.Text = "plan material 1";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 1" && a != 1)
            {
                txtState.Text = "plan material 2";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 2" && a != 1)
            {
                txtState.Text = "production";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production" && a != 1)
            {
                txtState.Text = "production report";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production report" && a != 1)
            {
                txtState.Text = "plan to transport";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan to transport" && a != 1)
            {
                txtState.Text = "transport";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "transport" && a != 1)
            {
                txtState.Text = "final pay";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "final pay" && a != 1)
            {
                txtState.Text = "after sale";
                a++;
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "after sale")
            {
                MessageBox.Show("This is the end of the order");
            }
        }

        private void lblProductId_TextChanged(object sender, EventArgs e)
        {

        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void label14_Click_1(object sender, EventArgs e)
        {

        }

        private void Modify_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox2.Text != "" && textBox3.Text != "" && textBox1.Text != "" && lblProductId.Text != "" && lblProductName.Text != "" && lblProductDescription.Text != "" && int.Parse(txtColumn.Text) != 0 && txtDepartment_Id.Text != "" && txtResponseStaff.Text != "" && txtProduct_Cost.Text != "" && txtStartDate.Text != "" && txtFinishDate.Text != "" && txtShippingOption.Text != "" && txtState.Text != "")
                {
                    String Id = GetDataFromDatabase("Select Staff_Id from Data");
                    String Department = GetDataFromDatabase("Select Department_Id from Data");

                    GetDataFromDatabase("UPDATE [Order] SET " +
                        "Product_Id = '" + lblProductId.Text.Replace("'", "''") + "', " +
                        "Version = '" + textBox2.Text.Replace("'", "''") + "', " +
                        "Comment = '" + textBox1.Text.Replace("'", "''") + "', " +
                        "[Column] = " + (int.TryParse(txtColumn.Text, out int columnValue) ? columnValue : 0) + ", " +
                        "Department_Id = '" + txtDepartment_Id.Text.Replace("'", "''") + "', " +
                        "ResponedStaff = '" + txtResponseStaff.Text.Replace("'", "''") + "', " +
                        "Order_Cost = '" + txtProduct_Cost.Text.Replace("'", "''") + "', " +
                        "Product_Description = '" + lblProductDescription.Text.Replace("'", "''") + "', " +
                        "StartDate = #" + DateTime.Parse(txtStartDate.Text).ToString("yyyy-MM-dd") + "#, " +
                        "FinishDate = #" + DateTime.Parse(txtFinishDate.Text).ToString("yyyy-MM-dd") + "#, " +
                        "ShippingOption = '" + txtShippingOption.Text.Replace("'", "''") + "', " +
                        "Customer_Id = '" + textBox3.Text.Replace("'", "''") + "', " +
                        "State = '" + txtState.Text.Replace("'", "''") + "' " +
                        "WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";");

                    String Exchange = "Product_Id: " + lblProductId.Text + ", Product_Version" + textBox2.Text + ", Order_Id: " + lblProductName.Text + ", Comment: " + textBox1.Text + ", Column: " + txtColumn.Text + ", Respon's Department: " + txtDepartment_Id.Text + ", Respon's Staff: " + txtResponseStaff.Text + ", Cost: " + txtProduct_Cost.Text + "Product Description: " + lblProductDescription + ", Start Date: " + txtStartDate.Text + ", Finish Date: " + FinishDate.Text + ", Shipping Option: " + txtShippingOption.Text + ", Customer_Id :" + textBox3.Text + "State: " + txtState.Text;
                    string sanitizedLabel16 = label16.Text.Replace("'", "''");
                    string sanitizedExchange = Exchange.Replace("'", "''");
                    GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', '" + sanitizedExchange + "');");
                    MessageBox.Show("Setting successful");

                    Close();
                }
                else
                {
                    MessageBox.Show("Please finish all enter");
                }
            }
            catch (Exception ea)
            {
                MessageBox.Show("Enter error: " + ea.Message);
            }
        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void txtState_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void Link1_Click(object sender, EventArgs e)
        {
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "pay")
            {
                Report1 frm = new Report1();
                frm.ShowDialog();
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "design")
            {
                Product frm = new Product();
                frm.ShowDialog();
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan production")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 1")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan material 2")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "production report")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "plan to transport")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "transport")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "final pay")
            {
            }
            if (GetDataFromDatabase("SELECT [State] FROM [Order] WHERE Order_Id = " + int.Parse(lblProductName.Text) + ";") == "after sale")
            {
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from [Order] where [Order_Id] = " + int.Parse(lblProductName.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }

            string sanitizedLabel16 = label16.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
