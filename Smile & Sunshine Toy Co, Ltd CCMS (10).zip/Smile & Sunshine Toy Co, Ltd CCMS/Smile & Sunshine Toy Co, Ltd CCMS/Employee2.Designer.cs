﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Employee2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.staffBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.label12 = new System.Windows.Forms.Label();
            this.staffTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.StaffTableAdapter();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.DepartmentTableAdapter();
            this.staffBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.JobTitle = new System.Windows.Forms.Label();
            this.txtJobTitle = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.Leader = new System.Windows.Forms.Label();
            this.txtLeader = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.StaffName = new System.Windows.Forms.Label();
            this.txtStaffName = new System.Windows.Forms.TextBox();
            this.Company = new System.Windows.Forms.Label();
            this.txtCompany = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.Work = new System.Windows.Forms.Label();
            this.txtWork = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.Department_Id = new System.Windows.Forms.Label();
            this.txtDepartment_Id = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Salary = new System.Windows.Forms.Label();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.Position_Id = new System.Windows.Forms.Label();
            this.txtPosition_Id = new System.Windows.Forms.TextBox();
            this.Staff_Id = new System.Windows.Forms.Label();
            this.txtStaff_Id = new System.Windows.Forms.TextBox();
            this.Add = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // staffBindingSource
            // 
            this.staffBindingSource.DataMember = "Staff";
            this.staffBindingSource.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1105, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 127;
            this.label12.Text = "Admin";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // staffTableAdapter
            // 
            this.staffTableAdapter.ClearBeforeFill = true;
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.database1DataSet1;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // staffBindingSource1
            // 
            this.staffBindingSource1.DataMember = "Staff";
            this.staffBindingSource1.DataSource = this.database1DataSet1;
            // 
            // JobTitle
            // 
            this.JobTitle.AutoSize = true;
            this.JobTitle.Location = new System.Drawing.Point(405, 771);
            this.JobTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.JobTitle.Name = "JobTitle";
            this.JobTitle.Size = new System.Drawing.Size(64, 18);
            this.JobTitle.TabIndex = 246;
            this.JobTitle.Text = "JobTitle";
            // 
            // txtJobTitle
            // 
            this.txtJobTitle.Location = new System.Drawing.Point(561, 769);
            this.txtJobTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtJobTitle.Name = "txtJobTitle";
            this.txtJobTitle.Size = new System.Drawing.Size(259, 29);
            this.txtJobTitle.TabIndex = 245;
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Location = new System.Drawing.Point(406, 601);
            this.Contact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(61, 18);
            this.Contact.TabIndex = 244;
            this.Contact.Text = "Contact";
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(561, 596);
            this.txtContact.Margin = new System.Windows.Forms.Padding(4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(259, 29);
            this.txtContact.TabIndex = 243;
            // 
            // Leader
            // 
            this.Leader.AutoSize = true;
            this.Leader.Location = new System.Drawing.Point(405, 655);
            this.Leader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Leader.Name = "Leader";
            this.Leader.Size = new System.Drawing.Size(56, 18);
            this.Leader.TabIndex = 242;
            this.Leader.Text = "Leader";
            // 
            // txtLeader
            // 
            this.txtLeader.Location = new System.Drawing.Point(561, 651);
            this.txtLeader.Margin = new System.Windows.Forms.Padding(4);
            this.txtLeader.Name = "txtLeader";
            this.txtLeader.Size = new System.Drawing.Size(259, 29);
            this.txtLeader.TabIndex = 241;
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(405, 890);
            this.State.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(43, 18);
            this.State.TabIndex = 240;
            this.State.Text = "State";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(561, 885);
            this.txtState.Margin = new System.Windows.Forms.Padding(4);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(259, 29);
            this.txtState.TabIndex = 239;
            // 
            // StaffName
            // 
            this.StaffName.AutoSize = true;
            this.StaffName.Location = new System.Drawing.Point(405, 835);
            this.StaffName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StaffName.Name = "StaffName";
            this.StaffName.Size = new System.Drawing.Size(83, 18);
            this.StaffName.TabIndex = 238;
            this.StaffName.Text = "StaffName";
            // 
            // txtStaffName
            // 
            this.txtStaffName.Location = new System.Drawing.Point(561, 830);
            this.txtStaffName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStaffName.Name = "txtStaffName";
            this.txtStaffName.Size = new System.Drawing.Size(259, 29);
            this.txtStaffName.TabIndex = 237;
            // 
            // Company
            // 
            this.Company.AutoSize = true;
            this.Company.Location = new System.Drawing.Point(405, 716);
            this.Company.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Company.Name = "Company";
            this.Company.Size = new System.Drawing.Size(72, 18);
            this.Company.TabIndex = 236;
            this.Company.Text = "Company";
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(561, 711);
            this.txtCompany.Margin = new System.Windows.Forms.Padding(4);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Size = new System.Drawing.Size(259, 29);
            this.txtCompany.TabIndex = 235;
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(406, 543);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(69, 18);
            this.Phone_Number.TabIndex = 234;
            this.Phone_Number.Text = "PhoneNo";
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Location = new System.Drawing.Point(561, 541);
            this.txtPhoneNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(259, 29);
            this.txtPhoneNo.TabIndex = 233;
            // 
            // Work
            // 
            this.Work.AutoSize = true;
            this.Work.Location = new System.Drawing.Point(405, 361);
            this.Work.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Work.Name = "Work";
            this.Work.Size = new System.Drawing.Size(46, 18);
            this.Work.TabIndex = 232;
            this.Work.Text = "Work";
            // 
            // txtWork
            // 
            this.txtWork.Location = new System.Drawing.Point(561, 357);
            this.txtWork.Margin = new System.Windows.Forms.Padding(4);
            this.txtWork.Name = "txtWork";
            this.txtWork.Size = new System.Drawing.Size(259, 29);
            this.txtWork.TabIndex = 231;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(406, 189);
            this.Password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(73, 18);
            this.Password.TabIndex = 230;
            this.Password.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(561, 185);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(259, 29);
            this.txtPassword.TabIndex = 229;
            // 
            // Department_Id
            // 
            this.Department_Id.AutoSize = true;
            this.Department_Id.Location = new System.Drawing.Point(405, 243);
            this.Department_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Department_Id.Name = "Department_Id";
            this.Department_Id.Size = new System.Drawing.Size(111, 18);
            this.Department_Id.TabIndex = 228;
            this.Department_Id.Text = "Department_Id";
            // 
            // txtDepartment_Id
            // 
            this.txtDepartment_Id.Location = new System.Drawing.Point(561, 241);
            this.txtDepartment_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtDepartment_Id.Name = "txtDepartment_Id";
            this.txtDepartment_Id.Size = new System.Drawing.Size(259, 29);
            this.txtDepartment_Id.TabIndex = 227;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(405, 479);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 226;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(561, 475);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 225;
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Location = new System.Drawing.Point(405, 423);
            this.Salary.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(52, 18);
            this.Salary.TabIndex = 224;
            this.Salary.Text = "Salary";
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(561, 419);
            this.txtSalary.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(259, 29);
            this.txtSalary.TabIndex = 223;
            // 
            // Position_Id
            // 
            this.Position_Id.AutoSize = true;
            this.Position_Id.Location = new System.Drawing.Point(405, 305);
            this.Position_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Position_Id.Name = "Position_Id";
            this.Position_Id.Size = new System.Drawing.Size(85, 18);
            this.Position_Id.TabIndex = 222;
            this.Position_Id.Text = "Position_Id";
            // 
            // txtPosition_Id
            // 
            this.txtPosition_Id.Location = new System.Drawing.Point(561, 301);
            this.txtPosition_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition_Id.Name = "txtPosition_Id";
            this.txtPosition_Id.Size = new System.Drawing.Size(259, 29);
            this.txtPosition_Id.TabIndex = 221;
            // 
            // Staff_Id
            // 
            this.Staff_Id.AutoSize = true;
            this.Staff_Id.Location = new System.Drawing.Point(406, 133);
            this.Staff_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Staff_Id.Name = "Staff_Id";
            this.Staff_Id.Size = new System.Drawing.Size(64, 18);
            this.Staff_Id.TabIndex = 220;
            this.Staff_Id.Text = "Staff_Id";
            // 
            // txtStaff_Id
            // 
            this.txtStaff_Id.Location = new System.Drawing.Point(561, 129);
            this.txtStaff_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtStaff_Id.Name = "txtStaff_Id";
            this.txtStaff_Id.Size = new System.Drawing.Size(259, 29);
            this.txtStaff_Id.TabIndex = 219;
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(1008, 965);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(204, 64);
            this.Add.TabIndex = 247;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Employee2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1225, 1042);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.JobTitle);
            this.Controls.Add(this.txtJobTitle);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.Leader);
            this.Controls.Add(this.txtLeader);
            this.Controls.Add(this.State);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.StaffName);
            this.Controls.Add(this.txtStaffName);
            this.Controls.Add(this.Company);
            this.Controls.Add(this.txtCompany);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhoneNo);
            this.Controls.Add(this.Work);
            this.Controls.Add(this.txtWork);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.Department_Id);
            this.Controls.Add(this.txtDepartment_Id);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.Position_Id);
            this.Controls.Add(this.txtPosition_Id);
            this.Controls.Add(this.Staff_Id);
            this.Controls.Add(this.txtStaff_Id);
            this.Controls.Add(this.label12);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Employee2";
            this.Text = "Employee2";
            this.Load += new System.EventHandler(this.Employee2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource staffBindingSource;
        private Database1DataSet1TableAdapters.StaffTableAdapter staffTableAdapter;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private Database1DataSet1TableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private System.Windows.Forms.BindingSource staffBindingSource1;
        private System.Windows.Forms.Label JobTitle;
        private System.Windows.Forms.TextBox txtJobTitle;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label Leader;
        private System.Windows.Forms.TextBox txtLeader;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label StaffName;
        private System.Windows.Forms.TextBox txtStaffName;
        private System.Windows.Forms.Label Company;
        private System.Windows.Forms.TextBox txtCompany;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.Label Work;
        private System.Windows.Forms.TextBox txtWork;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label Department_Id;
        private System.Windows.Forms.TextBox txtDepartment_Id;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.Label Position_Id;
        private System.Windows.Forms.TextBox txtPosition_Id;
        private System.Windows.Forms.Label Staff_Id;
        private System.Windows.Forms.TextBox txtStaff_Id;
        private System.Windows.Forms.Button Add;
    }
}