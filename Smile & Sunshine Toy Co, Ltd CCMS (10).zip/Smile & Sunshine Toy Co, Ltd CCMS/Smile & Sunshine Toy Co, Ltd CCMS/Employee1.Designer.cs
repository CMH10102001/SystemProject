﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Employee1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.label12 = new System.Windows.Forms.Label();
            this.staffBindingSource3 = new System.Windows.Forms.BindingSource(this.components);
            this.staffBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.staffBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.staffBindingSource4 = new System.Windows.Forms.BindingSource(this.components);
            this.Work = new System.Windows.Forms.Label();
            this.txtWork = new System.Windows.Forms.TextBox();
            this.Password = new System.Windows.Forms.Label();
            this.txtPassword = new System.Windows.Forms.TextBox();
            this.Department_Id = new System.Windows.Forms.Label();
            this.txtDepartment_Id = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Salary = new System.Windows.Forms.Label();
            this.txtSalary = new System.Windows.Forms.TextBox();
            this.Position_Id = new System.Windows.Forms.Label();
            this.txtPosition_Id = new System.Windows.Forms.TextBox();
            this.Staff_Id = new System.Windows.Forms.Label();
            this.txtStaff_Id = new System.Windows.Forms.TextBox();
            this.JobTitle = new System.Windows.Forms.Label();
            this.txtJobTitle = new System.Windows.Forms.TextBox();
            this.Contact = new System.Windows.Forms.Label();
            this.txtContact = new System.Windows.Forms.TextBox();
            this.Leader = new System.Windows.Forms.Label();
            this.txtLeader = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.StaffName = new System.Windows.Forms.Label();
            this.txtStaffName = new System.Windows.Forms.TextBox();
            this.Company = new System.Windows.Forms.Label();
            this.txtCompany = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhoneNo = new System.Windows.Forms.TextBox();
            this.Delete = new System.Windows.Forms.Button();
            this.Modify = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource4)).BeginInit();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1408, 33);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 98;
            this.label12.Text = "Admin";
            // 
            // Work
            // 
            this.Work.AutoSize = true;
            this.Work.Location = new System.Drawing.Point(368, 320);
            this.Work.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Work.Name = "Work";
            this.Work.Size = new System.Drawing.Size(46, 18);
            this.Work.TabIndex = 204;
            this.Work.Text = "Work";
            // 
            // txtWork
            // 
            this.txtWork.Location = new System.Drawing.Point(524, 316);
            this.txtWork.Margin = new System.Windows.Forms.Padding(4);
            this.txtWork.Name = "txtWork";
            this.txtWork.Size = new System.Drawing.Size(259, 29);
            this.txtWork.TabIndex = 203;
            // 
            // Password
            // 
            this.Password.AutoSize = true;
            this.Password.Location = new System.Drawing.Point(369, 148);
            this.Password.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Password.Name = "Password";
            this.Password.Size = new System.Drawing.Size(73, 18);
            this.Password.TabIndex = 202;
            this.Password.Text = "Password";
            // 
            // txtPassword
            // 
            this.txtPassword.Location = new System.Drawing.Point(524, 144);
            this.txtPassword.Margin = new System.Windows.Forms.Padding(4);
            this.txtPassword.Name = "txtPassword";
            this.txtPassword.Size = new System.Drawing.Size(259, 29);
            this.txtPassword.TabIndex = 201;
            // 
            // Department_Id
            // 
            this.Department_Id.AutoSize = true;
            this.Department_Id.Location = new System.Drawing.Point(368, 202);
            this.Department_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Department_Id.Name = "Department_Id";
            this.Department_Id.Size = new System.Drawing.Size(111, 18);
            this.Department_Id.TabIndex = 200;
            this.Department_Id.Text = "Department_Id";
            // 
            // txtDepartment_Id
            // 
            this.txtDepartment_Id.Location = new System.Drawing.Point(524, 200);
            this.txtDepartment_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtDepartment_Id.Name = "txtDepartment_Id";
            this.txtDepartment_Id.Size = new System.Drawing.Size(259, 29);
            this.txtDepartment_Id.TabIndex = 199;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(368, 438);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 198;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(524, 434);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 197;
            // 
            // Salary
            // 
            this.Salary.AutoSize = true;
            this.Salary.Location = new System.Drawing.Point(368, 382);
            this.Salary.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Salary.Name = "Salary";
            this.Salary.Size = new System.Drawing.Size(52, 18);
            this.Salary.TabIndex = 196;
            this.Salary.Text = "Salary";
            // 
            // txtSalary
            // 
            this.txtSalary.Location = new System.Drawing.Point(524, 378);
            this.txtSalary.Margin = new System.Windows.Forms.Padding(4);
            this.txtSalary.Name = "txtSalary";
            this.txtSalary.Size = new System.Drawing.Size(259, 29);
            this.txtSalary.TabIndex = 195;
            // 
            // Position_Id
            // 
            this.Position_Id.AutoSize = true;
            this.Position_Id.Location = new System.Drawing.Point(368, 264);
            this.Position_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Position_Id.Name = "Position_Id";
            this.Position_Id.Size = new System.Drawing.Size(85, 18);
            this.Position_Id.TabIndex = 194;
            this.Position_Id.Text = "Position_Id";
            // 
            // txtPosition_Id
            // 
            this.txtPosition_Id.Location = new System.Drawing.Point(524, 260);
            this.txtPosition_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtPosition_Id.Name = "txtPosition_Id";
            this.txtPosition_Id.Size = new System.Drawing.Size(259, 29);
            this.txtPosition_Id.TabIndex = 193;
            // 
            // Staff_Id
            // 
            this.Staff_Id.AutoSize = true;
            this.Staff_Id.Location = new System.Drawing.Point(369, 92);
            this.Staff_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Staff_Id.Name = "Staff_Id";
            this.Staff_Id.Size = new System.Drawing.Size(64, 18);
            this.Staff_Id.TabIndex = 192;
            this.Staff_Id.Text = "Staff_Id";
            // 
            // txtStaff_Id
            // 
            this.txtStaff_Id.Location = new System.Drawing.Point(524, 88);
            this.txtStaff_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtStaff_Id.Name = "txtStaff_Id";
            this.txtStaff_Id.Size = new System.Drawing.Size(259, 29);
            this.txtStaff_Id.TabIndex = 191;
            // 
            // JobTitle
            // 
            this.JobTitle.AutoSize = true;
            this.JobTitle.Location = new System.Drawing.Point(368, 730);
            this.JobTitle.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.JobTitle.Name = "JobTitle";
            this.JobTitle.Size = new System.Drawing.Size(64, 18);
            this.JobTitle.TabIndex = 218;
            this.JobTitle.Text = "JobTitle";
            // 
            // txtJobTitle
            // 
            this.txtJobTitle.Location = new System.Drawing.Point(524, 728);
            this.txtJobTitle.Margin = new System.Windows.Forms.Padding(4);
            this.txtJobTitle.Name = "txtJobTitle";
            this.txtJobTitle.Size = new System.Drawing.Size(259, 29);
            this.txtJobTitle.TabIndex = 217;
            // 
            // Contact
            // 
            this.Contact.AutoSize = true;
            this.Contact.Location = new System.Drawing.Point(369, 560);
            this.Contact.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Contact.Name = "Contact";
            this.Contact.Size = new System.Drawing.Size(61, 18);
            this.Contact.TabIndex = 216;
            this.Contact.Text = "Contact";
            // 
            // txtContact
            // 
            this.txtContact.Location = new System.Drawing.Point(524, 555);
            this.txtContact.Margin = new System.Windows.Forms.Padding(4);
            this.txtContact.Name = "txtContact";
            this.txtContact.Size = new System.Drawing.Size(259, 29);
            this.txtContact.TabIndex = 215;
            // 
            // Leader
            // 
            this.Leader.AutoSize = true;
            this.Leader.Location = new System.Drawing.Point(368, 614);
            this.Leader.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Leader.Name = "Leader";
            this.Leader.Size = new System.Drawing.Size(56, 18);
            this.Leader.TabIndex = 214;
            this.Leader.Text = "Leader";
            // 
            // txtLeader
            // 
            this.txtLeader.Location = new System.Drawing.Point(524, 610);
            this.txtLeader.Margin = new System.Windows.Forms.Padding(4);
            this.txtLeader.Name = "txtLeader";
            this.txtLeader.Size = new System.Drawing.Size(259, 29);
            this.txtLeader.TabIndex = 213;
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(368, 849);
            this.State.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(43, 18);
            this.State.TabIndex = 212;
            this.State.Text = "State";
            // 
            // StaffName
            // 
            this.StaffName.AutoSize = true;
            this.StaffName.Location = new System.Drawing.Point(368, 794);
            this.StaffName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.StaffName.Name = "StaffName";
            this.StaffName.Size = new System.Drawing.Size(83, 18);
            this.StaffName.TabIndex = 210;
            this.StaffName.Text = "StaffName";
            // 
            // txtStaffName
            // 
            this.txtStaffName.Location = new System.Drawing.Point(524, 789);
            this.txtStaffName.Margin = new System.Windows.Forms.Padding(4);
            this.txtStaffName.Name = "txtStaffName";
            this.txtStaffName.Size = new System.Drawing.Size(259, 29);
            this.txtStaffName.TabIndex = 209;
            // 
            // Company
            // 
            this.Company.AutoSize = true;
            this.Company.Location = new System.Drawing.Point(368, 675);
            this.Company.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Company.Name = "Company";
            this.Company.Size = new System.Drawing.Size(72, 18);
            this.Company.TabIndex = 208;
            this.Company.Text = "Company";
            // 
            // txtCompany
            // 
            this.txtCompany.Location = new System.Drawing.Point(524, 670);
            this.txtCompany.Margin = new System.Windows.Forms.Padding(4);
            this.txtCompany.Name = "txtCompany";
            this.txtCompany.Size = new System.Drawing.Size(259, 29);
            this.txtCompany.TabIndex = 207;
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(369, 502);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(69, 18);
            this.Phone_Number.TabIndex = 206;
            this.Phone_Number.Text = "PhoneNo";
            // 
            // txtPhoneNo
            // 
            this.txtPhoneNo.Location = new System.Drawing.Point(524, 500);
            this.txtPhoneNo.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhoneNo.Name = "txtPhoneNo";
            this.txtPhoneNo.Size = new System.Drawing.Size(259, 29);
            this.txtPhoneNo.TabIndex = 205;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(1018, 1042);
            this.Delete.Margin = new System.Windows.Forms.Padding(4);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(204, 64);
            this.Delete.TabIndex = 220;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(1258, 1042);
            this.Modify.Margin = new System.Windows.Forms.Padding(4);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(204, 64);
            this.Modify.TabIndex = 219;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(368, 33);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 18);
            this.label13.TabIndex = 221;
            this.label13.Text = "Admin";
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(524, 844);
            this.txtState.Margin = new System.Windows.Forms.Padding(4);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(259, 29);
            this.txtState.TabIndex = 211;
            // 
            // Employee1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1506, 1125);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.JobTitle);
            this.Controls.Add(this.txtJobTitle);
            this.Controls.Add(this.Contact);
            this.Controls.Add(this.txtContact);
            this.Controls.Add(this.Leader);
            this.Controls.Add(this.txtLeader);
            this.Controls.Add(this.State);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.StaffName);
            this.Controls.Add(this.txtStaffName);
            this.Controls.Add(this.Company);
            this.Controls.Add(this.txtCompany);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhoneNo);
            this.Controls.Add(this.Work);
            this.Controls.Add(this.txtWork);
            this.Controls.Add(this.Password);
            this.Controls.Add(this.txtPassword);
            this.Controls.Add(this.Department_Id);
            this.Controls.Add(this.txtDepartment_Id);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Salary);
            this.Controls.Add(this.txtSalary);
            this.Controls.Add(this.Position_Id);
            this.Controls.Add(this.txtPosition_Id);
            this.Controls.Add(this.Staff_Id);
            this.Controls.Add(this.txtStaff_Id);
            this.Controls.Add(this.label12);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Employee1";
            this.Text = "Employee1";
            this.Load += new System.EventHandler(this.Employee1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource4)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.BindingSource staffBindingSource1;
        private System.Windows.Forms.BindingSource staffBindingSource3;
        private System.Windows.Forms.BindingSource staffBindingSource2;
        private System.Windows.Forms.BindingSource staffBindingSource4;
        private System.Windows.Forms.Label Work;
        private System.Windows.Forms.TextBox txtWork;
        private System.Windows.Forms.Label Password;
        private System.Windows.Forms.TextBox txtPassword;
        private System.Windows.Forms.Label Department_Id;
        private System.Windows.Forms.TextBox txtDepartment_Id;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Salary;
        private System.Windows.Forms.TextBox txtSalary;
        private System.Windows.Forms.Label Position_Id;
        private System.Windows.Forms.TextBox txtPosition_Id;
        private System.Windows.Forms.Label Staff_Id;
        private System.Windows.Forms.TextBox txtStaff_Id;
        private System.Windows.Forms.Label JobTitle;
        private System.Windows.Forms.TextBox txtJobTitle;
        private System.Windows.Forms.Label Contact;
        private System.Windows.Forms.TextBox txtContact;
        private System.Windows.Forms.Label Leader;
        private System.Windows.Forms.TextBox txtLeader;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.Label StaffName;
        private System.Windows.Forms.TextBox txtStaffName;
        private System.Windows.Forms.Label Company;
        private System.Windows.Forms.TextBox txtCompany;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhoneNo;
        private System.Windows.Forms.Button Delete;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtState;
    }
}