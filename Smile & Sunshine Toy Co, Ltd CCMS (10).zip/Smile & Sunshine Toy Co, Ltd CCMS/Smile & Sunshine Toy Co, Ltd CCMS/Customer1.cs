﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Customer1 : Form
    {

        public string customer_Id { get; set; }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        public Customer1()
        {
            InitializeComponent();
        }

        private void Customer1_Load(object sender, EventArgs e)
        {
            label13.Visible = false;
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }

            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D002")
            {

            }
            else
            {
                MessageBox.Show("Only D007 and D002 has access");
                Close();
            }

            txtCustomer_Id.Text =  customer_Id;
            txtCustomer_Name.Text = GetDataFromDatabase("Select Customer_Name from Staff where Staff_Id = " + int.Parse(txtCustomer_Id.Text) + ";");
            txtCustomer_Address.Text = GetDataFromDatabase("Select Customer_Address from Staff where Staff_Id = " + int.Parse(txtCustomer_Id.Text) + ";");
            txtEmail.Text = GetDataFromDatabase("Select Email from Staff where Staff_Id = " + int.Parse(txtCustomer_Id.Text) + ";");
            txtPhone_Number.Text = GetDataFromDatabase("Select Phone_Number from Staff where Staff_Id = " + int.Parse(txtCustomer_Id.Text) + ";");
            label13.Text = "Customer_Id: " + txtCustomer_Id.Text + ", Customer_Name: '" + txtCustomer_Name.Text + ", Customer_Address: " + txtCustomer_Address.Text + ", Email: " + Email.Text + ", Phone_Number: " + txtPhone_Number.Text;
        }

        private void Modify_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataFromDatabase("UPDATE [Customer] SET " +
                                    "[Customer_Name] = '" + txtCustomer_Name.Text.Replace("'", "''") + "', " +
                                    "[Customer_Address] = '" + txtCustomer_Address.Text.Replace("'", "''") + "', " +
                                    "[Email] = '" + txtEmail.Text.Replace("'", "''") + "', " +
                                    "[Phone_Number] = '" + txtPhone_Number.Text.Replace("'", "''") + "', " +
                                    "WHERE [Customer_Id] = " + int.Parse(txtCustomer_Id.Text) + ";");


                String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
                String Department = GetDataFromDatabase("Select Department_Id from [Data]");
                String exchange = "Customer_Id: " + txtCustomer_Id.Text + ", Customer_Name: '" + txtCustomer_Name.Text + ", Customer_Address: " + txtCustomer_Address.Text + ", Email: " + Email.Text + ", Phone_Number: " + txtPhone_Number.Text;
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                "VALUES ('" +
                Id.Replace("'", "''") + "', '" +
                Department.Replace("'", "''") + "', '" +
                label13.Text.Replace("'", "''") + "', '" +
                exchange.Replace("'", "''") + "');");

                MessageBox.Show("Update Successful");
                Close();
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter: " + ea.Message);
            }
        }
    }
}
