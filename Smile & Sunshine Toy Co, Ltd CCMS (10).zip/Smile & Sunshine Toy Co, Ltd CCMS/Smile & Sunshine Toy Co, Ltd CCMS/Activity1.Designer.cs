﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Activity1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.StaffID = new System.Windows.Forms.Label();
            this.txtStaffID = new System.Windows.Forms.Label();
            this.DepartmentID = new System.Windows.Forms.Label();
            this.Origin = new System.Windows.Forms.Label();
            this.Update = new System.Windows.Forms.Label();
            this.txtDepartmentID = new System.Windows.Forms.Label();
            this.txtOrigin = new System.Windows.Forms.Label();
            this.txtUpdate = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // StaffID
            // 
            this.StaffID.AutoSize = true;
            this.StaffID.Location = new System.Drawing.Point(43, 57);
            this.StaffID.Name = "StaffID";
            this.StaffID.Size = new System.Drawing.Size(60, 18);
            this.StaffID.TabIndex = 0;
            this.StaffID.Text = "StaffID";
            // 
            // txtStaffID
            // 
            this.txtStaffID.AutoSize = true;
            this.txtStaffID.Location = new System.Drawing.Point(254, 57);
            this.txtStaffID.Name = "txtStaffID";
            this.txtStaffID.Size = new System.Drawing.Size(50, 18);
            this.txtStaffID.TabIndex = 1;
            this.txtStaffID.Text = "label2";
            // 
            // DepartmentID
            // 
            this.DepartmentID.AutoSize = true;
            this.DepartmentID.Location = new System.Drawing.Point(43, 144);
            this.DepartmentID.Name = "DepartmentID";
            this.DepartmentID.Size = new System.Drawing.Size(107, 18);
            this.DepartmentID.TabIndex = 2;
            this.DepartmentID.Text = "DepartmentID";
            // 
            // Origin
            // 
            this.Origin.AutoSize = true;
            this.Origin.Location = new System.Drawing.Point(43, 275);
            this.Origin.Name = "Origin";
            this.Origin.Size = new System.Drawing.Size(52, 18);
            this.Origin.TabIndex = 3;
            this.Origin.Text = "Origin";
            // 
            // Update
            // 
            this.Update.AutoSize = true;
            this.Update.Location = new System.Drawing.Point(43, 437);
            this.Update.Name = "Update";
            this.Update.Size = new System.Drawing.Size(57, 18);
            this.Update.TabIndex = 4;
            this.Update.Text = "Update";
            // 
            // txtDepartmentID
            // 
            this.txtDepartmentID.AutoSize = true;
            this.txtDepartmentID.Location = new System.Drawing.Point(254, 144);
            this.txtDepartmentID.Name = "txtDepartmentID";
            this.txtDepartmentID.Size = new System.Drawing.Size(50, 18);
            this.txtDepartmentID.TabIndex = 5;
            this.txtDepartmentID.Text = "label6";
            // 
            // txtOrigin
            // 
            this.txtOrigin.AutoSize = true;
            this.txtOrigin.Location = new System.Drawing.Point(254, 275);
            this.txtOrigin.Name = "txtOrigin";
            this.txtOrigin.Size = new System.Drawing.Size(50, 18);
            this.txtOrigin.TabIndex = 6;
            this.txtOrigin.Text = "label7";
            // 
            // txtUpdate
            // 
            this.txtUpdate.AutoSize = true;
            this.txtUpdate.Location = new System.Drawing.Point(254, 437);
            this.txtUpdate.Name = "txtUpdate";
            this.txtUpdate.Size = new System.Drawing.Size(50, 18);
            this.txtUpdate.TabIndex = 7;
            this.txtUpdate.Text = "label8";
            // 
            // Activity1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1376, 866);
            this.Controls.Add(this.txtUpdate);
            this.Controls.Add(this.txtOrigin);
            this.Controls.Add(this.txtDepartmentID);
            this.Controls.Add(this.Update);
            this.Controls.Add(this.Origin);
            this.Controls.Add(this.DepartmentID);
            this.Controls.Add(this.txtStaffID);
            this.Controls.Add(this.StaffID);
            this.Name = "Activity1";
            this.Text = "Activity1";
            this.Load += new System.EventHandler(this.Activity1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label StaffID;
        private System.Windows.Forms.Label txtStaffID;
        private System.Windows.Forms.Label DepartmentID;
        private System.Windows.Forms.Label Origin;
        private System.Windows.Forms.Label Update;
        private System.Windows.Forms.Label txtDepartmentID;
        private System.Windows.Forms.Label txtOrigin;
        private System.Windows.Forms.Label txtUpdate;
    }
}