﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Material_Requirement2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label12 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.Material_Name = new System.Windows.Forms.Label();
            this.txtMaterial_Name = new System.Windows.Forms.TextBox();
            this.Qty = new System.Windows.Forms.Label();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.Produce_Id = new System.Windows.Forms.Label();
            this.txtProduce_Id = new System.Windows.Forms.TextBox();
            this.Amount = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.Department_Id = new System.Windows.Forms.Label();
            this.txtDepartment_Id = new System.Windows.Forms.TextBox();
            this.Specical_Instructions = new System.Windows.Forms.Label();
            this.txtSpecical_Instructions = new System.Windows.Forms.TextBox();
            this.Material_Specifications = new System.Windows.Forms.Label();
            this.txtMaterial_Specifications = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Approval_Signatures = new System.Windows.Forms.Label();
            this.txtApproval_Signatures = new System.Windows.Forms.TextBox();
            this.Delivery_Date = new System.Windows.Forms.Label();
            this.txtDelivery_Date = new System.Windows.Forms.TextBox();
            this.Payment_method = new System.Windows.Forms.Label();
            this.txtPriority_level = new System.Windows.Forms.TextBox();
            this.Material_Type = new System.Windows.Forms.Label();
            this.txtMaterial_Type = new System.Windows.Forms.TextBox();
            this.Date_Issued = new System.Windows.Forms.Label();
            this.txtDate_Issued = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1424, 42);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 245;
            this.label12.Text = "Admin";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(1274, 854);
            this.Add.Margin = new System.Windows.Forms.Padding(4);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(204, 64);
            this.Add.TabIndex = 244;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Material_Name
            // 
            this.Material_Name.AutoSize = true;
            this.Material_Name.Location = new System.Drawing.Point(358, 534);
            this.Material_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Name.Name = "Material_Name";
            this.Material_Name.Size = new System.Drawing.Size(117, 18);
            this.Material_Name.TabIndex = 273;
            this.Material_Name.Text = "Material_Name";
            // 
            // txtMaterial_Name
            // 
            this.txtMaterial_Name.Location = new System.Drawing.Point(544, 530);
            this.txtMaterial_Name.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterial_Name.Name = "txtMaterial_Name";
            this.txtMaterial_Name.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Name.TabIndex = 272;
            // 
            // Qty
            // 
            this.Qty.AutoSize = true;
            this.Qty.Location = new System.Drawing.Point(358, 345);
            this.Qty.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Qty.Name = "Qty";
            this.Qty.Size = new System.Drawing.Size(79, 18);
            this.Qty.TabIndex = 271;
            this.Qty.Text = "Qty(in kg)";
            // 
            // txtQty
            // 
            this.txtQty.Location = new System.Drawing.Point(544, 345);
            this.txtQty.Margin = new System.Windows.Forms.Padding(4);
            this.txtQty.Name = "txtQty";
            this.txtQty.Size = new System.Drawing.Size(259, 29);
            this.txtQty.TabIndex = 270;
            // 
            // Produce_Id
            // 
            this.Produce_Id.AutoSize = true;
            this.Produce_Id.Location = new System.Drawing.Point(358, 294);
            this.Produce_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Produce_Id.Name = "Produce_Id";
            this.Produce_Id.Size = new System.Drawing.Size(85, 18);
            this.Produce_Id.TabIndex = 269;
            this.Produce_Id.Text = "Produce_Id";
            // 
            // txtProduce_Id
            // 
            this.txtProduce_Id.Location = new System.Drawing.Point(544, 294);
            this.txtProduce_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtProduce_Id.Name = "txtProduce_Id";
            this.txtProduce_Id.Size = new System.Drawing.Size(259, 29);
            this.txtProduce_Id.TabIndex = 268;
            // 
            // Amount
            // 
            this.Amount.AutoSize = true;
            this.Amount.Location = new System.Drawing.Point(358, 888);
            this.Amount.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(62, 18);
            this.Amount.TabIndex = 267;
            this.Amount.Text = "Amount";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(544, 884);
            this.txtAmount.Margin = new System.Windows.Forms.Padding(4);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(259, 29);
            this.txtAmount.TabIndex = 266;
            // 
            // Department_Id
            // 
            this.Department_Id.AutoSize = true;
            this.Department_Id.Location = new System.Drawing.Point(358, 188);
            this.Department_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Department_Id.Name = "Department_Id";
            this.Department_Id.Size = new System.Drawing.Size(111, 18);
            this.Department_Id.TabIndex = 265;
            this.Department_Id.Text = "Department_Id";
            // 
            // txtDepartment_Id
            // 
            this.txtDepartment_Id.Location = new System.Drawing.Point(544, 183);
            this.txtDepartment_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtDepartment_Id.Name = "txtDepartment_Id";
            this.txtDepartment_Id.Size = new System.Drawing.Size(259, 29);
            this.txtDepartment_Id.TabIndex = 264;
            // 
            // Specical_Instructions
            // 
            this.Specical_Instructions.AutoSize = true;
            this.Specical_Instructions.Location = new System.Drawing.Point(358, 830);
            this.Specical_Instructions.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Specical_Instructions.Name = "Specical_Instructions";
            this.Specical_Instructions.Size = new System.Drawing.Size(156, 18);
            this.Specical_Instructions.TabIndex = 263;
            this.Specical_Instructions.Text = "Specical_Instructions";
            // 
            // txtSpecical_Instructions
            // 
            this.txtSpecical_Instructions.Location = new System.Drawing.Point(544, 825);
            this.txtSpecical_Instructions.Margin = new System.Windows.Forms.Padding(4);
            this.txtSpecical_Instructions.Name = "txtSpecical_Instructions";
            this.txtSpecical_Instructions.Size = new System.Drawing.Size(259, 29);
            this.txtSpecical_Instructions.TabIndex = 262;
            // 
            // Material_Specifications
            // 
            this.Material_Specifications.AutoSize = true;
            this.Material_Specifications.Location = new System.Drawing.Point(358, 592);
            this.Material_Specifications.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Specifications.Name = "Material_Specifications";
            this.Material_Specifications.Size = new System.Drawing.Size(174, 18);
            this.Material_Specifications.TabIndex = 261;
            this.Material_Specifications.Text = "Material_Specifications";
            // 
            // txtMaterial_Specifications
            // 
            this.txtMaterial_Specifications.Location = new System.Drawing.Point(544, 588);
            this.txtMaterial_Specifications.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterial_Specifications.Name = "txtMaterial_Specifications";
            this.txtMaterial_Specifications.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Specifications.TabIndex = 260;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(358, 238);
            this.Product_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(82, 18);
            this.Product_Id.TabIndex = 259;
            this.Product_Id.Text = "Product_Id";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(544, 238);
            this.txtProduct_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(259, 29);
            this.txtProduct_Id.TabIndex = 258;
            // 
            // Approval_Signatures
            // 
            this.Approval_Signatures.AutoSize = true;
            this.Approval_Signatures.Location = new System.Drawing.Point(358, 765);
            this.Approval_Signatures.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Approval_Signatures.Name = "Approval_Signatures";
            this.Approval_Signatures.Size = new System.Drawing.Size(151, 18);
            this.Approval_Signatures.TabIndex = 255;
            this.Approval_Signatures.Text = "Approval_Signatures";
            // 
            // txtApproval_Signatures
            // 
            this.txtApproval_Signatures.Location = new System.Drawing.Point(544, 760);
            this.txtApproval_Signatures.Margin = new System.Windows.Forms.Padding(4);
            this.txtApproval_Signatures.Name = "txtApproval_Signatures";
            this.txtApproval_Signatures.Size = new System.Drawing.Size(259, 29);
            this.txtApproval_Signatures.TabIndex = 254;
            // 
            // Delivery_Date
            // 
            this.Delivery_Date.AutoSize = true;
            this.Delivery_Date.Location = new System.Drawing.Point(358, 711);
            this.Delivery_Date.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Delivery_Date.Name = "Delivery_Date";
            this.Delivery_Date.Size = new System.Drawing.Size(109, 18);
            this.Delivery_Date.TabIndex = 253;
            this.Delivery_Date.Text = "Delivery_Date";
            // 
            // txtDelivery_Date
            // 
            this.txtDelivery_Date.Location = new System.Drawing.Point(544, 706);
            this.txtDelivery_Date.Margin = new System.Windows.Forms.Padding(4);
            this.txtDelivery_Date.Name = "txtDelivery_Date";
            this.txtDelivery_Date.Size = new System.Drawing.Size(259, 29);
            this.txtDelivery_Date.TabIndex = 252;
            // 
            // Payment_method
            // 
            this.Payment_method.AutoSize = true;
            this.Payment_method.Location = new System.Drawing.Point(358, 656);
            this.Payment_method.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Payment_method.Name = "Payment_method";
            this.Payment_method.Size = new System.Drawing.Size(102, 18);
            this.Payment_method.TabIndex = 251;
            this.Payment_method.Text = "Priority_level";
            // 
            // txtPriority_level
            // 
            this.txtPriority_level.Location = new System.Drawing.Point(544, 651);
            this.txtPriority_level.Margin = new System.Windows.Forms.Padding(4);
            this.txtPriority_level.Name = "txtPriority_level";
            this.txtPriority_level.Size = new System.Drawing.Size(259, 29);
            this.txtPriority_level.TabIndex = 250;
            // 
            // Material_Type
            // 
            this.Material_Type.AutoSize = true;
            this.Material_Type.Location = new System.Drawing.Point(358, 470);
            this.Material_Type.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Type.Name = "Material_Type";
            this.Material_Type.Size = new System.Drawing.Size(94, 18);
            this.Material_Type.TabIndex = 249;
            this.Material_Type.Text = "Material_ID";
            // 
            // txtMaterial_Type
            // 
            this.txtMaterial_Type.Location = new System.Drawing.Point(544, 465);
            this.txtMaterial_Type.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterial_Type.Name = "txtMaterial_Type";
            this.txtMaterial_Type.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Type.TabIndex = 248;
            // 
            // Date_Issued
            // 
            this.Date_Issued.AutoSize = true;
            this.Date_Issued.Location = new System.Drawing.Point(358, 411);
            this.Date_Issued.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Date_Issued.Name = "Date_Issued";
            this.Date_Issued.Size = new System.Drawing.Size(93, 18);
            this.Date_Issued.TabIndex = 247;
            this.Date_Issued.Text = "Date_Issued";
            // 
            // txtDate_Issued
            // 
            this.txtDate_Issued.Location = new System.Drawing.Point(544, 406);
            this.txtDate_Issued.Margin = new System.Windows.Forms.Padding(4);
            this.txtDate_Issued.Name = "txtDate_Issued";
            this.txtDate_Issued.Size = new System.Drawing.Size(259, 29);
            this.txtDate_Issued.TabIndex = 246;
            // 
            // Material_Requirement2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1538, 993);
            this.Controls.Add(this.Material_Name);
            this.Controls.Add(this.txtMaterial_Name);
            this.Controls.Add(this.Qty);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.Produce_Id);
            this.Controls.Add(this.txtProduce_Id);
            this.Controls.Add(this.Amount);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.Department_Id);
            this.Controls.Add(this.txtDepartment_Id);
            this.Controls.Add(this.Specical_Instructions);
            this.Controls.Add(this.txtSpecical_Instructions);
            this.Controls.Add(this.Material_Specifications);
            this.Controls.Add(this.txtMaterial_Specifications);
            this.Controls.Add(this.Product_Id);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Approval_Signatures);
            this.Controls.Add(this.txtApproval_Signatures);
            this.Controls.Add(this.Delivery_Date);
            this.Controls.Add(this.txtDelivery_Date);
            this.Controls.Add(this.Payment_method);
            this.Controls.Add(this.txtPriority_level);
            this.Controls.Add(this.Material_Type);
            this.Controls.Add(this.txtMaterial_Type);
            this.Controls.Add(this.Date_Issued);
            this.Controls.Add(this.txtDate_Issued);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Add);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Material_Requirement2";
            this.Text = "Material_Requirement2";
            this.Load += new System.EventHandler(this.Material_Requirement2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label Material_Name;
        private System.Windows.Forms.TextBox txtMaterial_Name;
        private System.Windows.Forms.Label Qty;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label Produce_Id;
        private System.Windows.Forms.TextBox txtProduce_Id;
        private System.Windows.Forms.Label Amount;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label Department_Id;
        private System.Windows.Forms.TextBox txtDepartment_Id;
        private System.Windows.Forms.Label Specical_Instructions;
        private System.Windows.Forms.TextBox txtSpecical_Instructions;
        private System.Windows.Forms.Label Material_Specifications;
        private System.Windows.Forms.TextBox txtMaterial_Specifications;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Approval_Signatures;
        private System.Windows.Forms.TextBox txtApproval_Signatures;
        private System.Windows.Forms.Label Delivery_Date;
        private System.Windows.Forms.TextBox txtDelivery_Date;
        private System.Windows.Forms.Label Payment_method;
        private System.Windows.Forms.TextBox txtPriority_level;
        private System.Windows.Forms.Label Material_Type;
        private System.Windows.Forms.TextBox txtMaterial_Type;
        private System.Windows.Forms.Label Date_Issued;
        private System.Windows.Forms.TextBox txtDate_Issued;
    }
}