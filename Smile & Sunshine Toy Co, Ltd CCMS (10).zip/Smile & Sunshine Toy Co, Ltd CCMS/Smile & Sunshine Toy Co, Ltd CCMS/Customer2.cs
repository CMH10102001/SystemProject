﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.IO;
using System.Net.NetworkInformation;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Customer2 : Form
    {

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        public Customer2()
        {
            InitializeComponent();
        }

        private void Customer2_Load(object sender, EventArgs e)
        {
            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D002")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D002 has access");
                Close();
            }


            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataFromDatabase("INSERT INTO [Customer] " +
                    "([Customer_Name], [Customer_Address], [Email], [Phone_Number]" +
                    "VALUES (" +
                    "'" + txtCustomer_Name.Text.Replace("'", "''") + "', " +
                    "'" + txtCustomer_Address.Text.Replace("'", "''") + "', " +
                    "'" + txtEmail.Text.Replace("'", "''") + "', " +
                    "'" + txtPhone_Number.Text.Replace("'", "''") + "' "  + "');");

                String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
                String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
                String a = GetDataFromDatabase("Select MAX(Customer_Id) AS MaxValue From Customer");
                String Exchange = "Customer_Id: " + a + ", Customer_Name: '" + txtCustomer_Name.Text + ", Customer_Address: " + txtCustomer_Address.Text + ", Email: " + Email.Text + ", Phone_Number: " + txtPhone_Number.Text;
                string sanitizedId = Id.Replace("'", "''");
                string sanitizedDepartment = Department.Replace("'", "''");
                string sanitizedExchange = Exchange.Replace("'", "''");
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "',' ADD ', '" + sanitizedExchange + "');");

                MessageBox.Show("Adding success");

                Close();
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter: " + ea.Message);
            }
        }
    }
}
