﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Companies2 : Form
    {

        public Companies2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Companies2_Load(object sender, EventArgs e)
        {
            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007")
            {

            }
            else
            {
                MessageBox.Show("Only D007 is access");
                Close();
            }


            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void bookIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void authorTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void publisherTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            
        }

        private void authorLabel_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void label4_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void label6_Click(object sender, EventArgs e)
        {
            Product frm = new Product();
            frm.ShowDialog();
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataFromDatabase("INSERT INTO [Supplier] " +
                        "( Supplier_Name, Material_Id, Email, Address, Tax, [Phone_ Number])" +
                        "VALUES (" +
                        "'" + txtSupplier_Name.Text.Replace("'", "''") + "', " +
                        "'" + txtMaterial_Id.Text.Replace("'", "''") + "', " +
                        "'" + txtEmail.Text.Replace("'", "''") + "', " +
                        "'" + txtAddress.Text.Replace("'", "''") + "', " +
                        "'" + txtTax.Text.Replace("'", "''") + "', " +
                        "'" + txtPhone_Number.Text.Replace("'", "''") + "');");

                String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
                String Department = GetDataFromDatabase("Select Department_Id from [Data]");
                String a = GetDataFromDatabase("Select MAX(Supplier_Id) AS MaxValue From Supplier");

                String exchange = "Supplier_Id: " + a + ", Supplier_Name: " + txtSupplier_Name.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Email: " + txtEmail.Text + ", Address: " + txtAddress.Text + ", Tax: " + txtTax.Text + ", Phone_Number: " + txtPhone_Number.Text;

                GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + "Add" + "','" + exchange + "');");

                MessageBox.Show("Update Successful");

                Close();
            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter: " + ea.Message);
            }
        }
    }
}
