﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Leads : Form
    {
        public Leads()
        {
            InitializeComponent();
        }

        private void Leads_Load(object sender, EventArgs e)
        {

        }
    }
}
