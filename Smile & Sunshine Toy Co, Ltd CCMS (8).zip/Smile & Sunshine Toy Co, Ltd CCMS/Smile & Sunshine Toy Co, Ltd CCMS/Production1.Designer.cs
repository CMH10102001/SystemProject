﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class End_Date
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.Modify = new System.Windows.Forms.Button();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.Amount = new System.Windows.Forms.Label();
            this.txtProduction_Id = new System.Windows.Forms.TextBox();
            this.Production_Id = new System.Windows.Forms.Label();
            this.txtWorker = new System.Windows.Forms.TextBox();
            this.Worker = new System.Windows.Forms.Label();
            this.txtDimension = new System.Windows.Forms.TextBox();
            this.Dimension = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            this.txtOrder_Id = new System.Windows.Forms.TextBox();
            this.Order_Id = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.txtStart_Date = new System.Windows.Forms.TextBox();
            this.Start_Date = new System.Windows.Forms.Label();
            this.txtProduction_Compound = new System.Windows.Forms.TextBox();
            this.Production_Compound = new System.Windows.Forms.Label();
            this.txtEnd_Date = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtTeam_Leader = new System.Windows.Forms.TextBox();
            this.Team_Leader = new System.Windows.Forms.Label();
            this.txtDetail = new System.Windows.Forms.TextBox();
            this.Detail = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(222, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 46;
            this.label1.Text = "label1";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(591, 631);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(120, 23);
            this.Modify.TabIndex = 45;
            this.Modify.Text = "Modify";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(139, 235);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(161, 22);
            this.txtAmount.TabIndex = 44;
            // 
            // Amount
            // 
            this.Amount.AutoSize = true;
            this.Amount.Location = new System.Drawing.Point(12, 235);
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(43, 12);
            this.Amount.TabIndex = 43;
            this.Amount.Text = "Amount";
            // 
            // txtProduction_Id
            // 
            this.txtProduction_Id.Location = new System.Drawing.Point(139, 50);
            this.txtProduction_Id.Name = "txtProduction_Id";
            this.txtProduction_Id.Size = new System.Drawing.Size(161, 22);
            this.txtProduction_Id.TabIndex = 42;
            // 
            // Production_Id
            // 
            this.Production_Id.AutoSize = true;
            this.Production_Id.Location = new System.Drawing.Point(12, 50);
            this.Production_Id.Name = "Production_Id";
            this.Production_Id.Size = new System.Drawing.Size(72, 12);
            this.Production_Id.TabIndex = 41;
            this.Production_Id.Text = "Production_Id";
            // 
            // txtWorker
            // 
            this.txtWorker.Location = new System.Drawing.Point(139, 380);
            this.txtWorker.Name = "txtWorker";
            this.txtWorker.Size = new System.Drawing.Size(161, 22);
            this.txtWorker.TabIndex = 40;
            // 
            // Worker
            // 
            this.Worker.AutoSize = true;
            this.Worker.Location = new System.Drawing.Point(12, 380);
            this.Worker.Name = "Worker";
            this.Worker.Size = new System.Drawing.Size(41, 12);
            this.Worker.TabIndex = 39;
            this.Worker.Text = "Worker";
            // 
            // txtDimension
            // 
            this.txtDimension.Location = new System.Drawing.Point(139, 287);
            this.txtDimension.Name = "txtDimension";
            this.txtDimension.Size = new System.Drawing.Size(161, 22);
            this.txtDimension.TabIndex = 38;
            // 
            // Dimension
            // 
            this.Dimension.AutoSize = true;
            this.Dimension.Location = new System.Drawing.Point(12, 287);
            this.Dimension.Name = "Dimension";
            this.Dimension.Size = new System.Drawing.Size(55, 12);
            this.Dimension.TabIndex = 37;
            this.Dimension.Text = "Dimension";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(139, 184);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(161, 22);
            this.txtMaterial_Id.TabIndex = 36;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(8, 184);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(59, 12);
            this.Material_Id.TabIndex = 35;
            this.Material_Id.Text = "Material_Id";
            // 
            // txtOrder_Id
            // 
            this.txtOrder_Id.Location = new System.Drawing.Point(139, 137);
            this.txtOrder_Id.Name = "txtOrder_Id";
            this.txtOrder_Id.Size = new System.Drawing.Size(161, 22);
            this.txtOrder_Id.TabIndex = 34;
            // 
            // Order_Id
            // 
            this.Order_Id.AutoSize = true;
            this.Order_Id.Location = new System.Drawing.Point(12, 137);
            this.Order_Id.Name = "Order_Id";
            this.Order_Id.Size = new System.Drawing.Size(48, 12);
            this.Order_Id.TabIndex = 33;
            this.Order_Id.Text = "Order_Id";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(139, 91);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(161, 22);
            this.txtProduct_Id.TabIndex = 32;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(12, 91);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(57, 12);
            this.Product_Id.TabIndex = 31;
            this.Product_Id.Text = "Product_Id";
            // 
            // txtStart_Date
            // 
            this.txtStart_Date.Location = new System.Drawing.Point(139, 477);
            this.txtStart_Date.Name = "txtStart_Date";
            this.txtStart_Date.Size = new System.Drawing.Size(161, 22);
            this.txtStart_Date.TabIndex = 60;
            // 
            // Start_Date
            // 
            this.Start_Date.AutoSize = true;
            this.Start_Date.Location = new System.Drawing.Point(12, 477);
            this.Start_Date.Name = "Start_Date";
            this.Start_Date.Size = new System.Drawing.Size(53, 12);
            this.Start_Date.TabIndex = 59;
            this.Start_Date.Text = "Start_Date";
            // 
            // txtProduction_Compound
            // 
            this.txtProduction_Compound.Location = new System.Drawing.Point(139, 426);
            this.txtProduction_Compound.Name = "txtProduction_Compound";
            this.txtProduction_Compound.Size = new System.Drawing.Size(161, 22);
            this.txtProduction_Compound.TabIndex = 58;
            // 
            // Production_Compound
            // 
            this.Production_Compound.AutoSize = true;
            this.Production_Compound.Location = new System.Drawing.Point(12, 426);
            this.Production_Compound.Name = "Production_Compound";
            this.Production_Compound.Size = new System.Drawing.Size(115, 12);
            this.Production_Compound.TabIndex = 57;
            this.Production_Compound.Text = "Production_Compound";
            // 
            // txtEnd_Date
            // 
            this.txtEnd_Date.Location = new System.Drawing.Point(139, 529);
            this.txtEnd_Date.Name = "txtEnd_Date";
            this.txtEnd_Date.Size = new System.Drawing.Size(161, 22);
            this.txtEnd_Date.TabIndex = 56;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 529);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(51, 12);
            this.label5.TabIndex = 55;
            this.label5.Text = "End_Date";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // txtTeam_Leader
            // 
            this.txtTeam_Leader.Location = new System.Drawing.Point(139, 335);
            this.txtTeam_Leader.Name = "txtTeam_Leader";
            this.txtTeam_Leader.Size = new System.Drawing.Size(161, 22);
            this.txtTeam_Leader.TabIndex = 48;
            // 
            // Team_Leader
            // 
            this.Team_Leader.AutoSize = true;
            this.Team_Leader.Location = new System.Drawing.Point(12, 335);
            this.Team_Leader.Name = "Team_Leader";
            this.Team_Leader.Size = new System.Drawing.Size(69, 12);
            this.Team_Leader.TabIndex = 47;
            this.Team_Leader.Text = "Team_Leader";
            // 
            // txtDetail
            // 
            this.txtDetail.Location = new System.Drawing.Point(139, 580);
            this.txtDetail.Name = "txtDetail";
            this.txtDetail.Size = new System.Drawing.Size(161, 22);
            this.txtDetail.TabIndex = 62;
            // 
            // Detail
            // 
            this.Detail.AutoSize = true;
            this.Detail.Location = new System.Drawing.Point(12, 580);
            this.Detail.Name = "Detail";
            this.Detail.Size = new System.Drawing.Size(32, 12);
            this.Detail.TabIndex = 61;
            this.Detail.Text = "Detail";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(465, 631);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(120, 23);
            this.Delete.TabIndex = 63;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // End_Date
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(822, 666);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.txtDetail);
            this.Controls.Add(this.Detail);
            this.Controls.Add(this.txtStart_Date);
            this.Controls.Add(this.Start_Date);
            this.Controls.Add(this.txtProduction_Compound);
            this.Controls.Add(this.Production_Compound);
            this.Controls.Add(this.txtEnd_Date);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtTeam_Leader);
            this.Controls.Add(this.Team_Leader);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.Amount);
            this.Controls.Add(this.txtProduction_Id);
            this.Controls.Add(this.Production_Id);
            this.Controls.Add(this.txtWorker);
            this.Controls.Add(this.Worker);
            this.Controls.Add(this.txtDimension);
            this.Controls.Add(this.Dimension);
            this.Controls.Add(this.txtMaterial_Id);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtOrder_Id);
            this.Controls.Add(this.Order_Id);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Product_Id);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "End_Date";
            this.Text = "Production1";
            this.Load += new System.EventHandler(this.Production1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label Amount;
        private System.Windows.Forms.TextBox txtProduction_Id;
        private System.Windows.Forms.Label Production_Id;
        private System.Windows.Forms.TextBox txtWorker;
        private System.Windows.Forms.Label Worker;
        private System.Windows.Forms.TextBox txtDimension;
        private System.Windows.Forms.Label Dimension;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Label Material_Id;
        private System.Windows.Forms.TextBox txtOrder_Id;
        private System.Windows.Forms.Label Order_Id;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.TextBox txtStart_Date;
        private System.Windows.Forms.Label Start_Date;
        private System.Windows.Forms.TextBox txtProduction_Compound;
        private System.Windows.Forms.Label Production_Compound;
        private System.Windows.Forms.TextBox txtEnd_Date;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtTeam_Leader;
        private System.Windows.Forms.Label Team_Leader;
        private System.Windows.Forms.TextBox txtDetail;
        private System.Windows.Forms.Label Detail;
        private System.Windows.Forms.Button Delete;
    }
}