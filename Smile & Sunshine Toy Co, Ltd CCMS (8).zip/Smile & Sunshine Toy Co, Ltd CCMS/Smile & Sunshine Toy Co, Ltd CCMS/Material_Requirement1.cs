﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Material_Requirement1 : Form
    {
        public Material_Requirement1()
        {
            InitializeComponent();
        }

        public string material_Form_ID { get; set; }
        public string department_Id { get; set; }
        public string product_Id { get; set; }


        private string GetDataFromDatabase(string query)
        {

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Material_Requirement1_Load(object sender, EventArgs e)
        {

            label13.Visible = false;
            String a = GetDataFromDatabase("Select Staff_Id from [Data]");
            label12.Text = GetDataFromDatabase("Select StaffName from [Staff] where Staff_Id = '" + a + "';");

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D003")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D003 has access");
                Close();
            }

            if (GetDataFromDatabase("Select Department_Id from [Data] ") != "D007")
            {
                txtMaterial_Form_ID.ReadOnly = true;
                txtDepartment_Id.ReadOnly = true;
                txtProduct_Id.ReadOnly = true;
            }


            txtMaterial_Form_ID.Text = material_Form_ID;
            txtDepartment_Id.Text = department_Id;
            txtProduct_Id.Text = product_Id;

            txtDate_Issued.Text = GetDataFromDatabase("Select Date_Issued from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtMaterial_Type.Text = GetDataFromDatabase("Select Material_Id from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtMaterial_Specifications.Text = GetDataFromDatabase("Select Material_Specifications from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtPriority_level.Text = GetDataFromDatabase("Select Priority_level from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtDelivery_Date.Text = GetDataFromDatabase("Select Delivery_Date from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtApproval_Signatures.Text = GetDataFromDatabase("Select Approval_Signatures from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtSpecical_Instructions.Text = GetDataFromDatabase("Select Specical_Instructions from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtAmount.Text = GetDataFromDatabase("Select Amount from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtQty.Text = GetDataFromDatabase("Select [Qty(in kg)] from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
            txtMaterial_Name.Text = GetDataFromDatabase("Select MateriaName from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");

            label13.Text = "Material_Form_ID: " + txtMaterial_Form_ID.Text + ", Department_Id: " + txtDepartment_Id.Text + ", Product_Id: " + txtProduct_Id.Text + ", Date_Issued: " + txtDate_Issued.Text + ", Material_Id: " + Material_Type.Text + ", Material_Specifications: " + txtMaterial_Specifications.Text + ", Priority_level: " + txtPriority_level.Text + ", Delivery_Date: " + txtDelivery_Date.Text + ", Approval_Signatures: " + txtApproval_Signatures.Text + ", Specical_Instructions: " + txtSpecical_Instructions.Text + ", Amount: " + txtAmount.Text + ", Qty(in kg): " + txtQty.Text;





        }

        private void Modify_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("Update [Material_Requirement_Form] set " +
                               " Department_Id = '" + txtDepartment_Id.Text.Replace("'", "''") +
                               "', Product_Id = '" + txtProduct_Id.Text.Replace("'", "''") +
                               "', Produce_Id = '" + txtProduce_Id.Text.Replace("'", "''") +
                               "', Date_Issued = #" + DateTime.Parse(txtDate_Issued.Text).ToString("yyyy-MM-dd") +
                               "#, Material_Id = '" + txtMaterial_Type.Text.Replace("'", "''") +
                               "', Material_Specifications = '" + txtMaterial_Specifications.Text.Replace("'", "''") +
                               "', Priority_level = '" + txtPriority_level.Text.Replace("'", "''") +
                               "', Delivery_Date = #" + DateTime.Parse(txtDelivery_Date.Text).ToString("yyyy-MM-dd") +
                               "#, Approval_Signatures = '" + txtApproval_Signatures.Text.Replace("'", "''") +
                               "', Specical_Instructions = '" + txtSpecical_Instructions.Text.Replace("'", "''") +
                               "', Amount = " + int.Parse(txtAmount.Text) +
                               ", [Qty(in kg)] = '" + txtQty.Text.Replace("'", "''") +
                               "', MateriaName = '" + txtMaterial_Name.Text.Replace("'", "''") +
                               "' where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");


            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Material_Form_ID: " + txtMaterial_Form_ID.Text + ", Department_Id: " + txtDepartment_Id.Text + ", Product_Id: " + txtProduct_Id.Text + ", Produce_Id: " + txtProduce_Id.Text +  ", Date_Issued: " + txtDate_Issued.Text + ", Material_Id: " + Material_Type.Text + ", Material_Specifications: " + txtMaterial_Specifications.Text + ", Priority_level: " + txtPriority_level.Text + ", Delivery_Date: " + txtDelivery_Date.Text + ", Approval_Signatures: " + txtApproval_Signatures.Text + ", Specical_Instructions: " + txtSpecical_Instructions.Text + ", Amount: " + txtAmount.Text;

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label3.Text + "','" + exchange + "');");

            MessageBox.Show("Update Successful");

            Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Material_Requirement_Form where Material_Form_ID = " + int.Parse(txtMaterial_Form_ID.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }
        }
    }
}
