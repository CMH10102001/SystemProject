﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Finance1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtOrder_Id = new System.Windows.Forms.TextBox();
            this.Order_Id = new System.Windows.Forms.Label();
            this.Customer_Id = new System.Windows.Forms.Label();
            this.txtCustomer_Id = new System.Windows.Forms.TextBox();
            this.Payment_method = new System.Windows.Forms.Label();
            this.txtPayment_method = new System.Windows.Forms.TextBox();
            this.Pay_Time = new System.Windows.Forms.Label();
            this.txtPay_Time = new System.Windows.Forms.TextBox();
            this.Pay_Date = new System.Windows.Forms.Label();
            this.txtPay_Date = new System.Windows.Forms.TextBox();
            this.Total_Pay_Amount = new System.Windows.Forms.Label();
            this.txtTotal_Pay_Amount = new System.Windows.Forms.TextBox();
            this.Pay_Amount = new System.Windows.Forms.Label();
            this.txtPay_Amount = new System.Windows.Forms.TextBox();
            this.Staff_Id = new System.Windows.Forms.Label();
            this.txtStaff_Id = new System.Windows.Forms.TextBox();
            this.State = new System.Windows.Forms.Label();
            this.txtState = new System.Windows.Forms.TextBox();
            this.Pay_Id = new System.Windows.Forms.Label();
            this.txtPay_Id = new System.Windows.Forms.TextBox();
            this.Modify = new System.Windows.Forms.Button();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(22, 299);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 12);
            this.label18.TabIndex = 151;
            this.label18.Text = "Employee";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(22, 600);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 150;
            this.label11.Text = "Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(22, 554);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 12);
            this.label10.TabIndex = 149;
            this.label10.Text = "Activities";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(22, 508);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 12);
            this.label9.TabIndex = 148;
            this.label9.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 463);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 12);
            this.label8.TabIndex = 147;
            this.label8.Text = "Invoices";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 420);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 146;
            this.label7.Text = "Reports";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(20, 372);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 145;
            this.label6.Text = "Product";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(20, 331);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 12);
            this.label5.TabIndex = 144;
            this.label5.Text = "Deals";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 266);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 143;
            this.label4.Text = "Companies";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 230);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 142;
            this.label3.Text = "Leads";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 193);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 12);
            this.label2.TabIndex = 141;
            this.label2.Text = "Tasks";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 157);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 140;
            this.label1.Text = "Leads Dashboard";
            // 
            // txtOrder_Id
            // 
            this.txtOrder_Id.Location = new System.Drawing.Point(376, 152);
            this.txtOrder_Id.Name = "txtOrder_Id";
            this.txtOrder_Id.Size = new System.Drawing.Size(174, 22);
            this.txtOrder_Id.TabIndex = 152;
            // 
            // Order_Id
            // 
            this.Order_Id.AutoSize = true;
            this.Order_Id.Location = new System.Drawing.Point(272, 155);
            this.Order_Id.Name = "Order_Id";
            this.Order_Id.Size = new System.Drawing.Size(48, 12);
            this.Order_Id.TabIndex = 153;
            this.Order_Id.Text = "Order_Id";
            // 
            // Customer_Id
            // 
            this.Customer_Id.AutoSize = true;
            this.Customer_Id.Location = new System.Drawing.Point(272, 191);
            this.Customer_Id.Name = "Customer_Id";
            this.Customer_Id.Size = new System.Drawing.Size(66, 12);
            this.Customer_Id.TabIndex = 155;
            this.Customer_Id.Text = "Customer_Id";
            // 
            // txtCustomer_Id
            // 
            this.txtCustomer_Id.Location = new System.Drawing.Point(376, 188);
            this.txtCustomer_Id.Name = "txtCustomer_Id";
            this.txtCustomer_Id.Size = new System.Drawing.Size(174, 22);
            this.txtCustomer_Id.TabIndex = 154;
            // 
            // Payment_method
            // 
            this.Payment_method.AutoSize = true;
            this.Payment_method.Location = new System.Drawing.Point(272, 270);
            this.Payment_method.Name = "Payment_method";
            this.Payment_method.Size = new System.Drawing.Size(86, 12);
            this.Payment_method.TabIndex = 157;
            this.Payment_method.Text = "Payment_method";
            // 
            // txtPayment_method
            // 
            this.txtPayment_method.Location = new System.Drawing.Point(376, 267);
            this.txtPayment_method.Name = "txtPayment_method";
            this.txtPayment_method.Size = new System.Drawing.Size(174, 22);
            this.txtPayment_method.TabIndex = 156;
            // 
            // Pay_Time
            // 
            this.Pay_Time.AutoSize = true;
            this.Pay_Time.Location = new System.Drawing.Point(272, 307);
            this.Pay_Time.Name = "Pay_Time";
            this.Pay_Time.Size = new System.Drawing.Size(52, 12);
            this.Pay_Time.TabIndex = 159;
            this.Pay_Time.Text = "Pay_Time";
            // 
            // txtPay_Time
            // 
            this.txtPay_Time.Location = new System.Drawing.Point(376, 304);
            this.txtPay_Time.Name = "txtPay_Time";
            this.txtPay_Time.Size = new System.Drawing.Size(174, 22);
            this.txtPay_Time.TabIndex = 158;
            // 
            // Pay_Date
            // 
            this.Pay_Date.AutoSize = true;
            this.Pay_Date.Location = new System.Drawing.Point(272, 343);
            this.Pay_Date.Name = "Pay_Date";
            this.Pay_Date.Size = new System.Drawing.Size(49, 12);
            this.Pay_Date.TabIndex = 161;
            this.Pay_Date.Text = "Pay_Date";
            // 
            // txtPay_Date
            // 
            this.txtPay_Date.Location = new System.Drawing.Point(376, 340);
            this.txtPay_Date.Name = "txtPay_Date";
            this.txtPay_Date.Size = new System.Drawing.Size(174, 22);
            this.txtPay_Date.TabIndex = 160;
            // 
            // Total_Pay_Amount
            // 
            this.Total_Pay_Amount.AutoSize = true;
            this.Total_Pay_Amount.Location = new System.Drawing.Point(272, 422);
            this.Total_Pay_Amount.Name = "Total_Pay_Amount";
            this.Total_Pay_Amount.Size = new System.Drawing.Size(96, 12);
            this.Total_Pay_Amount.TabIndex = 171;
            this.Total_Pay_Amount.Text = "Total_Pay_Amount";
            // 
            // txtTotal_Pay_Amount
            // 
            this.txtTotal_Pay_Amount.Location = new System.Drawing.Point(376, 419);
            this.txtTotal_Pay_Amount.Name = "txtTotal_Pay_Amount";
            this.txtTotal_Pay_Amount.Size = new System.Drawing.Size(174, 22);
            this.txtTotal_Pay_Amount.TabIndex = 170;
            // 
            // Pay_Amount
            // 
            this.Pay_Amount.AutoSize = true;
            this.Pay_Amount.Location = new System.Drawing.Point(272, 386);
            this.Pay_Amount.Name = "Pay_Amount";
            this.Pay_Amount.Size = new System.Drawing.Size(66, 12);
            this.Pay_Amount.TabIndex = 169;
            this.Pay_Amount.Text = "Pay_Amount";
            // 
            // txtPay_Amount
            // 
            this.txtPay_Amount.Location = new System.Drawing.Point(376, 383);
            this.txtPay_Amount.Name = "txtPay_Amount";
            this.txtPay_Amount.Size = new System.Drawing.Size(174, 22);
            this.txtPay_Amount.TabIndex = 168;
            // 
            // Staff_Id
            // 
            this.Staff_Id.AutoSize = true;
            this.Staff_Id.Location = new System.Drawing.Point(272, 228);
            this.Staff_Id.Name = "Staff_Id";
            this.Staff_Id.Size = new System.Drawing.Size(43, 12);
            this.Staff_Id.TabIndex = 167;
            this.Staff_Id.Text = "Staff_Id";
            // 
            // txtStaff_Id
            // 
            this.txtStaff_Id.Location = new System.Drawing.Point(376, 225);
            this.txtStaff_Id.Name = "txtStaff_Id";
            this.txtStaff_Id.Size = new System.Drawing.Size(174, 22);
            this.txtStaff_Id.TabIndex = 166;
            // 
            // State
            // 
            this.State.AutoSize = true;
            this.State.Location = new System.Drawing.Point(272, 461);
            this.State.Name = "State";
            this.State.Size = new System.Drawing.Size(27, 12);
            this.State.TabIndex = 165;
            this.State.Text = "State";
            this.State.Click += new System.EventHandler(this.State_Click);
            // 
            // txtState
            // 
            this.txtState.Location = new System.Drawing.Point(376, 461);
            this.txtState.Name = "txtState";
            this.txtState.Size = new System.Drawing.Size(174, 22);
            this.txtState.TabIndex = 164;
            this.txtState.TextChanged += new System.EventHandler(this.txtState_TextChanged);
            // 
            // Pay_Id
            // 
            this.Pay_Id.AutoSize = true;
            this.Pay_Id.Location = new System.Drawing.Point(272, 111);
            this.Pay_Id.Name = "Pay_Id";
            this.Pay_Id.Size = new System.Drawing.Size(38, 12);
            this.Pay_Id.TabIndex = 163;
            this.Pay_Id.Text = "Pay_Id";
            // 
            // txtPay_Id
            // 
            this.txtPay_Id.Location = new System.Drawing.Point(376, 108);
            this.txtPay_Id.Name = "txtPay_Id";
            this.txtPay_Id.Size = new System.Drawing.Size(174, 22);
            this.txtPay_Id.TabIndex = 162;
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(713, 569);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(136, 43);
            this.Modify.TabIndex = 172;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Add_Click);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(799, 21);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 12);
            this.label12.TabIndex = 173;
            this.label12.Text = "Admin";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(273, 21);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 12);
            this.label13.TabIndex = 174;
            this.label13.Text = "Admin";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(11, 11);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 132);
            this.pictureBox1.TabIndex = 139;
            this.pictureBox1.TabStop = false;
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(540, 569);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(136, 43);
            this.Delete.TabIndex = 175;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Finance1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(912, 652);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.Total_Pay_Amount);
            this.Controls.Add(this.txtTotal_Pay_Amount);
            this.Controls.Add(this.Pay_Amount);
            this.Controls.Add(this.txtPay_Amount);
            this.Controls.Add(this.Staff_Id);
            this.Controls.Add(this.txtStaff_Id);
            this.Controls.Add(this.State);
            this.Controls.Add(this.txtState);
            this.Controls.Add(this.Pay_Id);
            this.Controls.Add(this.txtPay_Id);
            this.Controls.Add(this.Pay_Date);
            this.Controls.Add(this.txtPay_Date);
            this.Controls.Add(this.Pay_Time);
            this.Controls.Add(this.txtPay_Time);
            this.Controls.Add(this.Payment_method);
            this.Controls.Add(this.txtPayment_method);
            this.Controls.Add(this.Customer_Id);
            this.Controls.Add(this.txtCustomer_Id);
            this.Controls.Add(this.Order_Id);
            this.Controls.Add(this.txtOrder_Id);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Finance1";
            this.Text = "Finance1";
            this.Load += new System.EventHandler(this.Finance1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.TextBox txtOrder_Id;
        private System.Windows.Forms.Label Order_Id;
        private System.Windows.Forms.Label Customer_Id;
        private System.Windows.Forms.TextBox txtCustomer_Id;
        private System.Windows.Forms.Label Payment_method;
        private System.Windows.Forms.TextBox txtPayment_method;
        private System.Windows.Forms.Label Pay_Time;
        private System.Windows.Forms.TextBox txtPay_Time;
        private System.Windows.Forms.Label Pay_Date;
        private System.Windows.Forms.TextBox txtPay_Date;
        private System.Windows.Forms.Label Total_Pay_Amount;
        private System.Windows.Forms.TextBox txtTotal_Pay_Amount;
        private System.Windows.Forms.Label Pay_Amount;
        private System.Windows.Forms.TextBox txtPay_Amount;
        private System.Windows.Forms.Label Staff_Id;
        private System.Windows.Forms.TextBox txtStaff_Id;
        private System.Windows.Forms.Label State;
        private System.Windows.Forms.TextBox txtState;
        private System.Windows.Forms.Label Pay_Id;
        private System.Windows.Forms.TextBox txtPay_Id;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button Delete;
    }
}