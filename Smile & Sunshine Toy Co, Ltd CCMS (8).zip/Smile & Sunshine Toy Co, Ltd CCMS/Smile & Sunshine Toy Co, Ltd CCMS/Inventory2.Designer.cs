﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Inventory2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.Content = new System.Windows.Forms.Label();
            this.txtContent = new System.Windows.Forms.TextBox();
            this.EachCost = new System.Windows.Forms.Label();
            this.txtEachCost = new System.Windows.Forms.TextBox();
            this.Material_Name = new System.Windows.Forms.Label();
            this.txtMaterialName = new System.Windows.Forms.TextBox();
            this.Expected_Qty = new System.Windows.Forms.Label();
            this.txtExpected_Qty = new System.Windows.Forms.TextBox();
            this.Current_Qty = new System.Windows.Forms.Label();
            this.txtCurrent_Qty = new System.Windows.Forms.TextBox();
            this.Material_Type = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.Supplier_Id = new System.Windows.Forms.Label();
            this.txtSupplier_Id = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(271, 19);
            this.label13.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(37, 12);
            this.label13.TabIndex = 244;
            this.label13.Text = "Admin";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(796, 19);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 12);
            this.label12.TabIndex = 243;
            this.label12.Text = "Admin";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(697, 582);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(136, 43);
            this.Add.TabIndex = 242;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Content
            // 
            this.Content.AutoSize = true;
            this.Content.Location = new System.Drawing.Point(271, 495);
            this.Content.Name = "Content";
            this.Content.Size = new System.Drawing.Size(42, 12);
            this.Content.TabIndex = 241;
            this.Content.Text = "Content";
            // 
            // txtContent
            // 
            this.txtContent.Location = new System.Drawing.Point(375, 492);
            this.txtContent.Name = "txtContent";
            this.txtContent.Size = new System.Drawing.Size(174, 22);
            this.txtContent.TabIndex = 240;
            // 
            // EachCost
            // 
            this.EachCost.AutoSize = true;
            this.EachCost.Location = new System.Drawing.Point(271, 459);
            this.EachCost.Name = "EachCost";
            this.EachCost.Size = new System.Drawing.Size(49, 12);
            this.EachCost.TabIndex = 239;
            this.EachCost.Text = "EachCost";
            // 
            // txtEachCost
            // 
            this.txtEachCost.Location = new System.Drawing.Point(375, 456);
            this.txtEachCost.Name = "txtEachCost";
            this.txtEachCost.Size = new System.Drawing.Size(174, 22);
            this.txtEachCost.TabIndex = 238;
            // 
            // Material_Name
            // 
            this.Material_Name.AutoSize = true;
            this.Material_Name.Location = new System.Drawing.Point(271, 261);
            this.Material_Name.Name = "Material_Name";
            this.Material_Name.Size = new System.Drawing.Size(76, 12);
            this.Material_Name.TabIndex = 237;
            this.Material_Name.Text = "Material_Name";
            // 
            // txtMaterialName
            // 
            this.txtMaterialName.Location = new System.Drawing.Point(375, 259);
            this.txtMaterialName.Name = "txtMaterialName";
            this.txtMaterialName.Size = new System.Drawing.Size(174, 22);
            this.txtMaterialName.TabIndex = 236;
            // 
            // Expected_Qty
            // 
            this.Expected_Qty.AutoSize = true;
            this.Expected_Qty.Location = new System.Drawing.Point(271, 416);
            this.Expected_Qty.Name = "Expected_Qty";
            this.Expected_Qty.Size = new System.Drawing.Size(71, 12);
            this.Expected_Qty.TabIndex = 233;
            this.Expected_Qty.Text = "Expected_Qty";
            // 
            // txtExpected_Qty
            // 
            this.txtExpected_Qty.Location = new System.Drawing.Point(375, 413);
            this.txtExpected_Qty.Name = "txtExpected_Qty";
            this.txtExpected_Qty.Size = new System.Drawing.Size(174, 22);
            this.txtExpected_Qty.TabIndex = 232;
            // 
            // Current_Qty
            // 
            this.Current_Qty.AutoSize = true;
            this.Current_Qty.Location = new System.Drawing.Point(271, 380);
            this.Current_Qty.Name = "Current_Qty";
            this.Current_Qty.Size = new System.Drawing.Size(64, 12);
            this.Current_Qty.TabIndex = 231;
            this.Current_Qty.Text = "Current_Qty";
            // 
            // txtCurrent_Qty
            // 
            this.txtCurrent_Qty.Location = new System.Drawing.Point(375, 377);
            this.txtCurrent_Qty.Name = "txtCurrent_Qty";
            this.txtCurrent_Qty.Size = new System.Drawing.Size(174, 22);
            this.txtCurrent_Qty.TabIndex = 230;
            // 
            // Material_Type
            // 
            this.Material_Type.AutoSize = true;
            this.Material_Type.Location = new System.Drawing.Point(271, 343);
            this.Material_Type.Name = "Material_Type";
            this.Material_Type.Size = new System.Drawing.Size(73, 12);
            this.Material_Type.TabIndex = 229;
            this.Material_Type.Text = "Material_Type";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(375, 340);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(174, 22);
            this.txtType.TabIndex = 228;
            // 
            // Supplier_Id
            // 
            this.Supplier_Id.AutoSize = true;
            this.Supplier_Id.Location = new System.Drawing.Point(271, 300);
            this.Supplier_Id.Name = "Supplier_Id";
            this.Supplier_Id.Size = new System.Drawing.Size(60, 12);
            this.Supplier_Id.TabIndex = 227;
            this.Supplier_Id.Text = "Supplier_Id";
            // 
            // txtSupplier_Id
            // 
            this.txtSupplier_Id.Location = new System.Drawing.Point(375, 298);
            this.txtSupplier_Id.Name = "txtSupplier_Id";
            this.txtSupplier_Id.Size = new System.Drawing.Size(174, 22);
            this.txtSupplier_Id.TabIndex = 226;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(19, 296);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 12);
            this.label18.TabIndex = 223;
            this.label18.Text = "Employee";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(19, 597);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 222;
            this.label11.Text = "Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(19, 551);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 12);
            this.label10.TabIndex = 221;
            this.label10.Text = "Activities";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 505);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 12);
            this.label9.TabIndex = 220;
            this.label9.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(19, 460);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 12);
            this.label8.TabIndex = 219;
            this.label8.Text = "Invoices";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(19, 417);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 218;
            this.label7.Text = "Reports";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(17, 369);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 217;
            this.label6.Text = "Product";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(17, 328);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 12);
            this.label5.TabIndex = 216;
            this.label5.Text = "Deals";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(19, 263);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 215;
            this.label4.Text = "Companies";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(17, 227);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 214;
            this.label3.Text = "Leads";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 191);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 12);
            this.label2.TabIndex = 213;
            this.label2.Text = "Tasks";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 155);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 212;
            this.label1.Text = "Leads Dashboard";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(8, 8);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 132);
            this.pictureBox1.TabIndex = 211;
            this.pictureBox1.TabStop = false;
            // 
            // Inventory2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(965, 714);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.Content);
            this.Controls.Add(this.txtContent);
            this.Controls.Add(this.EachCost);
            this.Controls.Add(this.txtEachCost);
            this.Controls.Add(this.Material_Name);
            this.Controls.Add(this.txtMaterialName);
            this.Controls.Add(this.Expected_Qty);
            this.Controls.Add(this.txtExpected_Qty);
            this.Controls.Add(this.Current_Qty);
            this.Controls.Add(this.txtCurrent_Qty);
            this.Controls.Add(this.Material_Type);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.Supplier_Id);
            this.Controls.Add(this.txtSupplier_Id);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "Inventory2";
            this.Text = "Inventory2";
            this.Load += new System.EventHandler(this.Inventory2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label Content;
        private System.Windows.Forms.TextBox txtContent;
        private System.Windows.Forms.Label EachCost;
        private System.Windows.Forms.TextBox txtEachCost;
        private System.Windows.Forms.Label Material_Name;
        private System.Windows.Forms.TextBox txtMaterialName;
        private System.Windows.Forms.Label Expected_Qty;
        private System.Windows.Forms.TextBox txtExpected_Qty;
        private System.Windows.Forms.Label Current_Qty;
        private System.Windows.Forms.TextBox txtCurrent_Qty;
        private System.Windows.Forms.Label Material_Type;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label Supplier_Id;
        private System.Windows.Forms.TextBox txtSupplier_Id;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}