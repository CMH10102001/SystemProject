﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Net.NetworkInformation;
using System.Reflection.Emit;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Companies1 : Form
    {

        public string supplier_Name { get; set; }
        public string supplier_Id { get; set; }
        public string email { get; set; }
        public string address { get; set; }

        public string tax { get; set; }
        public string phone_Number { get; set; }
        public string material_Id { get; set; }


        public Companies1()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Companies_Load(object sender, EventArgs e)
        {
            label13.Visible = false;
            txtSupplier_Id.Text = supplier_Id;
            txtSupplier_Name.Text = supplier_Name;
            txtEmail.Text = email;
            txtTax.Text = tax;
            txtPhone_Number.Text = phone_Number;
            txtAddress.Text = address;
            txtMaterial_Id.Text = material_Id;

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D004")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D006 has access");
                Close();
            }

            if (GetDataFromDatabase("Select Department_Id from [Data] ") != "D007")
            {
                txtSupplier_Id.ReadOnly = true;
                Delete.Visible = false;
            }


            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }
            label13.Text = "Supplier_Id: " + txtSupplier_Id.Text + ", Supplier_Name:" + txtSupplier_Name.Text + "Email" + txtEmail.Text + ", Tax: " + txtTax.Text + ", Phone_Number: " + txtPhone_Number.Text + ", Address: " + txtAddress.Text + ", Material_Id: " + txtMaterial_Id;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {
            Order frm = new Order();
            frm.ShowDialog();
        }

        private void dataGridView1_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void btnFirst_Click(object sender, EventArgs e)
        {

        }

        private void bt1_Click(object sender, EventArgs e)
        {

        }

        private void bt2_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            Companies2 frm = new Companies2();
            frm.ShowDialog();
        }

        private void lbl1_Click(object sender, EventArgs e)
        {

        }

        private void lblText_Click(object sender, EventArgs e)
        {

        }

        private void label18_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Modify_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("Update [Supplier] set " +
                              "', Supplier_Name = '" + txtSupplier_Name.Text.Replace("'", "''") +
                              "', Material_Id = '" + txtMaterial_Id.Text.Replace("'", "''") +
                              "', Email = '" + txtEmail.Text.Replace("'", "''") +
                              "', Address = '" + txtAddress.Text.Replace("'", "''") +
                              "', Tax = '" + Tax.Text.Replace("'", "''") +
                              "', Phone_Number = '" + txtPhone_Number.Text.Replace("'", "''") +
                              "' where Supplier_Id = " + int.Parse(txtSupplier_Id.Text) + ";");


            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Supplier_Id: " + txtSupplier_Id.Text + ", Supplier_Name: " + txtSupplier_Name.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Email: " + txtEmail.Text + ", Address: " + txtAddress.Text + ", Tax: " + txtTax.Text + ", Phone_Number: " + txtPhone_Number.Text;

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label3.Text + "','" + exchange + "');");

            MessageBox.Show("Update Successful");

            Close();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Supplier where Supplier_Id = " + int.Parse(txtSupplier_Id.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }

            string sanitizedLabel16 = label13.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
