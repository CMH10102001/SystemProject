﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Production : Form
    {
        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb";

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        public Production()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Production_Load(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Product_Production_Order");
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.ReadOnly = true;

            String a = GetDataFromDatabase("Select Staff_Id from [Data]");
            label12.Text = GetDataFromDatabase("Select StaffName from [Staff] where Staff_Id = '" + a + "';");
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string Order_Id = selectedRow.Cells["Order_Id"].Value?.ToString() ?? string.Empty;
                string Production_Id = selectedRow.Cells["Production_Id"].Value?.ToString() ?? string.Empty;
                string Product_Id = selectedRow.Cells["Product_Id"].Value?.ToString() ?? string.Empty;

                End_Date frm = new End_Date
                {
                    production_Id = Production_Id,
                    order_Id = Order_Id,
                    product_Id = Product_Id
                };

                frm.ShowDialog();
            }

        }


        private void Add_Click(object sender, EventArgs e)
        {
            Production2 frm = new Production2();
            frm.ShowDialog();
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Product_Production_Order");
            search.Text = "Search here!";
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (search.Text.Length >= 1)
                UpdateGrid("Select * from Product_Production_Order where Production_Id = '" + search.Text + "';");
            else
                UpdateGrid("Select * from Product_Production_Order");
        }

        private void label12_Click(object sender, EventArgs e)
        {

        }
    }
}
