﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Inventory1 : Form
    {

        public string supplier_Id { get; set; }
        public string material_Id { get; set; }

        public Inventory1()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Inventory1_Load(object sender, EventArgs e)
        {
            label13.Visible = false;

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D004")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D004 has access");
                Close();
            }

            if (GetDataFromDatabase("Select Department_Id from [Data] ") != "D007")
            {
                txtMaterial_Id.ReadOnly = true;
                txtSupplier_Id.ReadOnly = true;
                Delete.Visible = false;
            }

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
            }
            txtSupplier_Id.Text = supplier_Id;
            txtMaterial_Id.Text = material_Id;

            txtCurrent_Qty.Text = GetDataFromDatabase("SELECT [Current_Qty] FROM [Inventroy] WHERE MaterialID = " + (txtMaterial_Id.Text) + ";");
            txtMaterialName.Text = GetDataFromDatabase("Select MaterialName from Inventroy where MaterialID = " + (txtMaterial_Id.Text) + ";");
            txtExpected_Qty.Text = GetDataFromDatabase("Select Expected_Qty from Inventroy where MaterialID = " + (txtMaterial_Id.Text) + ";");
            txtType.Text = GetDataFromDatabase("Select Type from Inventroy where MaterialID = " + (txtMaterial_Id.Text) + ";");
            txtEachCost.Text = GetDataFromDatabase("Select EachCost from Inventroy where MaterialID = " + (txtMaterial_Id.Text) + ";");
            txtContent.Text = GetDataFromDatabase("Select Content from Inventroy where MaterialID =  " + (txtMaterial_Id.Text) + ";");

            label13.Text = "Supplier_Id: " + txtSupplier_Id.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Material_Name: " + txtMaterialName.Text + ", Material_Type: " + txtType.Text + ", Current_Qty: " + txtCurrent_Qty.Text + ", Expected_Qty:" + txtExpected_Qty.Text + ", Each_Cost: " + txtEachCost.Text + ", Content: " + txtContent.Text;
        }

        private void Modify_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("UPDATE [Inventroy] SET " +
                                "Material_Supplier_Id = '" + txtSupplier_Id.Text.Replace("'", "''") + "', " +
                                "[Current_Qty] = " + int.Parse(txtCurrent_Qty.Text) + ", " +
                                "MaterialName = '" + txtMaterialName.Text.Replace("'", "''") + "', " +
                                "[Expected_Qty] = " + int.Parse(txtExpected_Qty.Text) + ", " + 
                                "[Type] = '" + txtType.Text.Replace("'", "''") + "', " + 
                                "EachCost = " + int.Parse(txtEachCost.Text) + ", " +
                                "Content = '" + txtContent.Text.Replace("'", "''") + "' " +
                                "WHERE [MaterialID]  = " + int.Parse(txtMaterial_Id.Text) + ";");


            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Supplier_Id: " + txtSupplier_Id.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Material_Name: " + txtMaterialName.Text + ", Material_Type: " + txtType.Text + ", Current_Qty: " + txtCurrent_Qty.Text + ", Expected_Qty:" + txtExpected_Qty.Text + ", Each_Cost: " + txtEachCost.Text + ", Content: " + txtContent.Text;


            GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
              "VALUES ('" +
              Id.Replace("'", "''") + "', '" +
              Department.Replace("'", "''") + "', '" +
              label13.Text.Replace("'", "''") + "', '" +
              exchange.Replace("'", "''") + "');");

            MessageBox.Show("Update Successful");
            if (int.Parse(txtExpected_Qty.Text) < int.Parse(txtCurrent_Qty.Text))
            {
                MessageBox.Show("Mertial amount no enough! ");
            }

            Close();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Inventroy where MaterialID = " + int.Parse(txtMaterial_Id.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }


            string sanitizedLabel16 = label13.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
