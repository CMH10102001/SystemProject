﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Product : Form
    {
        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb";

        public Product()
        {
            InitializeComponent();
        }

        private void Product_Load(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Product");
            dataGridView1.CellClick += dataGridView1_CellClick;
            dataGridView1.ReadOnly = true;
        }

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (search.Text.Length >= 1)
                UpdateGrid("Select * from Product where Product_Id = '" + search.Text + "';");
            else
                UpdateGrid("Select * from Product");
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Product");
            search.Text = "Search here!";
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string productId = selectedRow.Cells["Product_Id"].Value?.ToString() ?? string.Empty;
                string version = selectedRow.Cells["Version"].Value?.ToString() ?? string.Empty;
                string materialId = selectedRow.Cells["MaterailID"].Value?.ToString() ?? string.Empty;

                Product1 frm = new Product1
                {
                    ProductId = productId,
                    Version = version,
                    MaterialId = materialId
                };

                frm.ShowDialog();
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            Product2 frm = new Product2();
            frm.ShowDialog();
        }
    }
}