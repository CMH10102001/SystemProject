﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Product2 : Form
    {
        public Product2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Product2_Load(object sender, EventArgs e)
        {
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D001")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D001 has access");
                Close();
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");

            GetDataFromDatabase("INSERT INTO [Product] " +
                   "(Version, MaterailID, Materials, Color, Dimension, Type) " +
                   "VALUES (" +
                   "'" + txtVersion.Text.Replace("'", "''") + "', " +
                   "'" + txtMaterialID.Text.Replace("'", "''") + "', " +
                   "'" + txtMaterials.Text.Replace("'", "''") + "', " +
                   "'" + txtColor.Text.Replace("'", "''") + "', " +
                   "'" + txtDimension.Text.Replace("'", "''") + "', " +
                   "'" + txtType.Text.Replace("'", "''") + "'" +
                   ");");
            String a = GetDataFromDatabase("Select MAX(Product_Id) AS MaxValue From Product");
            String exchange = "Product_Id: " + a + ", Version:" + txtVersion.Text + ", Material ID: " + txtMaterialID.Text + ", Materials: " + txtMaterials.Text + ", Color: " + txtColor.Text + ", Dimension: " + txtDimension.Text + ", Type: " + txtType.Text;



            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "',' Null ','" + exchange + "');");

            MessageBox.Show("Update Successful");

            Close();
        }
    }
}
