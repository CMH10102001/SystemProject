﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Finance2 : Form
    {
        public Finance2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Finance2_Load(object sender, EventArgs e)
        {

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D006")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D006 has access");
                Close();
            }


            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            try
            {
                GetDataFromDatabase("INSERT INTO [Finance] " +
                    "(Pay_Id, Order_Id, Customer_Id, Staff_Id, Payment_method, Pay_Amount, Total_Pay_Amount, Pay_Date, Pay_Time, State)" +
                    "VALUES (" +
                    "'" + txtOrder_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtCustomer_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtStaff_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtPayment_method.Text.Replace("'", "''") + "', " +
                    "'" + txtPay_Amount.Text.Replace("'", "''") + "', " +
                    "'" + txtTotal_Pay_Amount.Text.Replace("'", "''") + "', " +
                    "#" + DateTime.Parse(txtPay_Date.Text).ToString("yyyy-MM-dd") + "#, " +
                    "#" + DateTime.Parse(txtPay_Time.Text).ToString("yyyy-MM-dd") + "#, " +
                    "'" + txtState.Text.Replace("'", "''") + "')");

                String a = GetDataFromDatabase("Select MAX(Pay_Id) AS MaxValue From Finance)");
                String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
                String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
                String Exchange = "Pay_Id: " + a + ", Order_Id: " + txtOrder_Id.Text + ", Customer_Id" + txtCustomer_Id + ", Staff_Id: " + txtStaff_Id + ", Payment_method: " + txtPayment_method.Text + "Pay_Amount: " + txtPay_Amount.Text + ", Total_Pay_Amount: " + txtTotal_Pay_Amount.Text + ", Pay_Date: " + txtPay_Date.Text + ", Pay_Time: " + txtPay_Time.Text + ", State: " + txtState.Text;
                string sanitizedId = Id.Replace("'", "''");
                string sanitizedDepartment = Department.Replace("'", "''");
                string sanitizedExchange = Exchange.Replace("'", "''");
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                                    "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "', NULL, '" + sanitizedExchange + "');");

                MessageBox.Show("Adding success");

                Close();

            }
            catch (Exception ea)
            {
                MessageBox.Show("Error enter");
            }
        }
    }
}
