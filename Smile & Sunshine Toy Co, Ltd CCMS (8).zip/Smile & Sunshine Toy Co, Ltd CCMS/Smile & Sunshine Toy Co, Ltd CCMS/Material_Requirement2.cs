﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Material_Requirement2 : Form
    {

        private string GetDataFromDatabase(string query)
        {

            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        public Material_Requirement2()
        {
            InitializeComponent();
        }

        private void Material_Requirement2_Load(object sender, EventArgs e)
        {
            String a = GetDataFromDatabase("Select Staff_Id from [Data]");
            label12.Text = GetDataFromDatabase("Select StaffName from [Staff] where Staff_Id = '" + a + "';");

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D003")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D003 has access");
                Close();
            }
            txtDepartment_Id.Text = "D003";
            if (GetDataFromDatabase("Select Department_Id from [Data] ") != "D007")
            {
                txtDepartment_Id.Visible = false;
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("INSERT INTO [Material_Requirement_Form] " +
                    "( Department_Id, Product_Id,Produce_Id, Date_Issued, Material_Id, Material_Specifications, Priority_level, Delivery_Date, Approval_Signatures, Specical_Instructions, Amount, [Qty(in kg)], MateriaName) " +
                    "VALUES (" +
                               "'" + txtDepartment_Id.Text.Replace("'", "''") +
                               "','" + txtProduct_Id.Text.Replace("'", "''") +
                               "','" + txtProduce_Id.Text.Replace("'", "''") +
                               "', #" + DateTime.Parse(txtDate_Issued.Text).ToString("yyyy-MM-dd") +
                               "#,'" + txtMaterial_Type.Text.Replace("'", "''") +
                               "','" + txtMaterial_Specifications.Text.Replace("'", "''") +
                               "','" + txtPriority_level.Text.Replace("'", "''") +
                               "',#" + DateTime.Parse(txtDelivery_Date.Text).ToString("yyyy-MM-dd") +
                               "#,'" + txtApproval_Signatures.Text.Replace("'", "''") +
                               "','" + txtSpecical_Instructions.Text.Replace("'", "''") +
                               "'," + int.Parse(txtAmount.Text) +
                               ",'" + txtQty.Text.Replace("'", "''") +
                               "','" + txtMaterial_Name.Text.Replace("'", "''")  + 
                               "');");


            String a = GetDataFromDatabase("Select MAX(Material_Form_ID) AS MaxValue From Material_Requirement_Form");
            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Material_Form_ID: " + a + ", Department_Id: " + "D003" + ", Product_Id: " + txtProduct_Id.Text + ", Date_Issued: " + txtDate_Issued.Text + ", Material_Id: " + Material_Type.Text + ", Material_Specifications: " + txtMaterial_Specifications.Text + ", Priority_level: " + txtPriority_level.Text + ", Delivery_Date: " + txtDelivery_Date.Text + ", Approval_Signatures: " + txtApproval_Signatures.Text + ", Specical_Instructions: " + txtSpecical_Instructions.Text + ", Amount: " + txtAmount.Text + ", Qty(in kg): " + txtQty.Text + ", Material_Name: " + txtMaterial_Name.Text;

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label3.Text + "','" + exchange + "');");

            MessageBox.Show("Add Successful");

            Close();
        }
    }
}
