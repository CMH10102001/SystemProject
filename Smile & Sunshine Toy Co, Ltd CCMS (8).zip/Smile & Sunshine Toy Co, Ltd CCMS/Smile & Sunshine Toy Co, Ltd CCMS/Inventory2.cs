﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Net.NetworkInformation;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Inventory2 : Form
    {
        public Inventory2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Inventory2_Load(object sender, EventArgs e)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D004")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D004 has access");
                Close();
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String a = "";

            GetDataFromDatabase("INSERT INTO [Inventroy] " +
                    "(Material_Supplier_Id, MaterialName, Type, Current_Qty, Expected_Qty, EachCost, Content)" +
                    "VALUES (" +
                    "'" + txtSupplier_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtMaterialName.Text.Replace("'", "''") + "', " +
                    "'" + txtType.Text.Replace("'", "''") + "', " +
                    "" + int.Parse(txtCurrent_Qty.Text) + ", " +
                    "" + int.Parse(txtExpected_Qty.Text) + ", " +
                    "" + int.Parse(txtEachCost.Text) + "," +
                    "'" + txtContent.Text.Replace("'", "''") + "')");

            a = GetDataFromDatabase("Select MAX(MaterialID) AS MaxValue From Inventroy");
            String exchange = "MaterialID" + a  + "Supplier_Id: " + txtSupplier_Id.Text + ", Material_Name: " + txtMaterialName.Text + ", Material_Type: " + txtType.Text + ", Current_Qty: " + txtCurrent_Qty.Text + ", Expected_Qty:" + txtExpected_Qty.Text + ", Each_Cost: " + txtEachCost.Text + ", Content: " + txtContent.Text;

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label3.Text + "','" + exchange + "');");

            MessageBox.Show("Update Successful");
            if (int.Parse(txtExpected_Qty.Text) < int.Parse(txtCurrent_Qty.Text))
            {
                MessageBox.Show("Mertial amount no enough! ");
            }

            Close();
        }
    }
}
