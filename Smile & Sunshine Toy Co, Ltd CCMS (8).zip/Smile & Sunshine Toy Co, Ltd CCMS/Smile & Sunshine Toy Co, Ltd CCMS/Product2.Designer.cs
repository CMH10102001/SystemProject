﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Product2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtColor = new System.Windows.Forms.TextBox();
            this.Color = new System.Windows.Forms.Label();
            this.txtMaterials = new System.Windows.Forms.TextBox();
            this.Materials = new System.Windows.Forms.Label();
            this.txtVersion = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.Type = new System.Windows.Forms.Label();
            this.txtDimension = new System.Windows.Forms.TextBox();
            this.Dimension = new System.Windows.Forms.Label();
            this.txtMaterialID = new System.Windows.Forms.TextBox();
            this.MaterialID = new System.Windows.Forms.Label();
            this.Add = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(164, 147);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(100, 22);
            this.txtColor.TabIndex = 3;
            // 
            // Color
            // 
            this.Color.AutoSize = true;
            this.Color.Location = new System.Drawing.Point(92, 150);
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(32, 12);
            this.Color.TabIndex = 2;
            this.Color.Text = "Color";
            // 
            // txtMaterials
            // 
            this.txtMaterials.Location = new System.Drawing.Point(164, 186);
            this.txtMaterials.Name = "txtMaterials";
            this.txtMaterials.Size = new System.Drawing.Size(100, 22);
            this.txtMaterials.TabIndex = 5;
            // 
            // Materials
            // 
            this.Materials.AutoSize = true;
            this.Materials.Location = new System.Drawing.Point(92, 189);
            this.Materials.Name = "Materials";
            this.Materials.Size = new System.Drawing.Size(47, 12);
            this.Materials.TabIndex = 4;
            this.Materials.Text = "Materials";
            // 
            // txtVersion
            // 
            this.txtVersion.Location = new System.Drawing.Point(164, 102);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.Size = new System.Drawing.Size(100, 22);
            this.txtVersion.TabIndex = 11;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(92, 105);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 10;
            this.label4.Text = "Version";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(164, 312);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(100, 22);
            this.txtType.TabIndex = 9;
            // 
            // Type
            // 
            this.Type.AutoSize = true;
            this.Type.Location = new System.Drawing.Point(92, 315);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(29, 12);
            this.Type.TabIndex = 8;
            this.Type.Text = "Type";
            // 
            // txtDimension
            // 
            this.txtDimension.Location = new System.Drawing.Point(164, 272);
            this.txtDimension.Name = "txtDimension";
            this.txtDimension.Size = new System.Drawing.Size(100, 22);
            this.txtDimension.TabIndex = 7;
            // 
            // Dimension
            // 
            this.Dimension.AutoSize = true;
            this.Dimension.Location = new System.Drawing.Point(92, 275);
            this.Dimension.Name = "Dimension";
            this.Dimension.Size = new System.Drawing.Size(55, 12);
            this.Dimension.TabIndex = 6;
            this.Dimension.Text = "Dimension";
            // 
            // txtMaterialID
            // 
            this.txtMaterialID.Location = new System.Drawing.Point(164, 226);
            this.txtMaterialID.Name = "txtMaterialID";
            this.txtMaterialID.Size = new System.Drawing.Size(100, 22);
            this.txtMaterialID.TabIndex = 13;
            // 
            // MaterialID
            // 
            this.MaterialID.AutoSize = true;
            this.MaterialID.Location = new System.Drawing.Point(92, 229);
            this.MaterialID.Name = "MaterialID";
            this.MaterialID.Size = new System.Drawing.Size(58, 12);
            this.MaterialID.TabIndex = 12;
            this.MaterialID.Text = "Material ID";
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(660, 533);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(120, 23);
            this.Add.TabIndex = 14;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // Product2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(792, 568);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.txtMaterialID);
            this.Controls.Add(this.MaterialID);
            this.Controls.Add(this.txtVersion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.txtDimension);
            this.Controls.Add(this.Dimension);
            this.Controls.Add(this.txtMaterials);
            this.Controls.Add(this.Materials);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.Color);
            this.Name = "Product2";
            this.Text = "Product2";
            this.Load += new System.EventHandler(this.Product2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.Label Color;
        private System.Windows.Forms.TextBox txtMaterials;
        private System.Windows.Forms.Label Materials;
        private System.Windows.Forms.TextBox txtVersion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label Type;
        private System.Windows.Forms.TextBox txtDimension;
        private System.Windows.Forms.Label Dimension;
        private System.Windows.Forms.TextBox txtMaterialID;
        private System.Windows.Forms.Label MaterialID;
        private System.Windows.Forms.Button Add;
    }
}