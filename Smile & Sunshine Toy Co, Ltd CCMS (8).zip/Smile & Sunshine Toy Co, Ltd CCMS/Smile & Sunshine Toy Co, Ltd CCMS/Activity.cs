﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Activity : Form
    {

        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;"
                        + "Data Source=Database1.accdb";

        public Activity()
        {
            InitializeComponent();
        }

        private void Activity_Load(object sender, EventArgs e)
        {
            UpdateGrid("Select * from Activity");
            dataGridView1.ReadOnly = true;
            dataGridView1.CellClick += dataGridView1_CellClick;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string Staff_Id = selectedRow.Cells["Staff_Id"].Value?.ToString() ?? string.Empty;
                string DepartmentID = selectedRow.Cells["DepartmentID"].Value?.ToString() ?? string.Empty;
                string Origin = selectedRow.Cells["Origin"].Value?.ToString() ?? string.Empty;
                string Update = selectedRow.Cells["Update"].Value?.ToString() ?? string.Empty;

                Activity1 finance1Form = new Activity1
                {
                    stuff_Id = Staff_Id,
                    departmentID = DepartmentID,
                    origin = Origin,
                    update = Update
                };

                finance1Form.ShowDialog();
            }
        }



        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (search.Text.Length >= 1)
            {
                UpdateGrid("SELECT * FROM [Activity] WHERE DepartmentID = '" + search.Text + "'");
            }
            else
            {
                UpdateGrid("Select * from [Activity]");
            }
        }

        private void search_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            UpdateGrid("Select * from [Activity]");
        }
    }
}
