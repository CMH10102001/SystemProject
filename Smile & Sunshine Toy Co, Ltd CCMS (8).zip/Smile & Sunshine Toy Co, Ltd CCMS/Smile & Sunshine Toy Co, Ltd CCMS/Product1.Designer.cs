﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Product1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Modify = new System.Windows.Forms.Button();
            this.txtMaterialID = new System.Windows.Forms.TextBox();
            this.MaterialID = new System.Windows.Forms.Label();
            this.txtVersion = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtType = new System.Windows.Forms.TextBox();
            this.Type = new System.Windows.Forms.Label();
            this.txtDimension = new System.Windows.Forms.TextBox();
            this.Dimension = new System.Windows.Forms.Label();
            this.txtMaterials = new System.Windows.Forms.TextBox();
            this.Materials = new System.Windows.Forms.Label();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.Color = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Delete = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(599, 503);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(120, 23);
            this.Modify.TabIndex = 29;
            this.Modify.Text = "Modify";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // txtMaterialID
            // 
            this.txtMaterialID.Location = new System.Drawing.Point(103, 196);
            this.txtMaterialID.Name = "txtMaterialID";
            this.txtMaterialID.Size = new System.Drawing.Size(161, 22);
            this.txtMaterialID.TabIndex = 28;
            // 
            // MaterialID
            // 
            this.MaterialID.AutoSize = true;
            this.MaterialID.Location = new System.Drawing.Point(31, 199);
            this.MaterialID.Name = "MaterialID";
            this.MaterialID.Size = new System.Drawing.Size(58, 12);
            this.MaterialID.TabIndex = 27;
            this.MaterialID.Text = "Material ID";
            // 
            // txtVersion
            // 
            this.txtVersion.Location = new System.Drawing.Point(103, 72);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.Size = new System.Drawing.Size(161, 22);
            this.txtVersion.TabIndex = 26;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(31, 75);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(41, 12);
            this.label4.TabIndex = 25;
            this.label4.Text = "Version";
            // 
            // txtType
            // 
            this.txtType.Location = new System.Drawing.Point(103, 282);
            this.txtType.Name = "txtType";
            this.txtType.Size = new System.Drawing.Size(161, 22);
            this.txtType.TabIndex = 24;
            // 
            // Type
            // 
            this.Type.AutoSize = true;
            this.Type.Location = new System.Drawing.Point(31, 285);
            this.Type.Name = "Type";
            this.Type.Size = new System.Drawing.Size(29, 12);
            this.Type.TabIndex = 23;
            this.Type.Text = "Type";
            // 
            // txtDimension
            // 
            this.txtDimension.Location = new System.Drawing.Point(103, 242);
            this.txtDimension.Name = "txtDimension";
            this.txtDimension.Size = new System.Drawing.Size(161, 22);
            this.txtDimension.TabIndex = 22;
            // 
            // Dimension
            // 
            this.Dimension.AutoSize = true;
            this.Dimension.Location = new System.Drawing.Point(31, 245);
            this.Dimension.Name = "Dimension";
            this.Dimension.Size = new System.Drawing.Size(55, 12);
            this.Dimension.TabIndex = 21;
            this.Dimension.Text = "Dimension";
            // 
            // txtMaterials
            // 
            this.txtMaterials.Location = new System.Drawing.Point(103, 156);
            this.txtMaterials.Name = "txtMaterials";
            this.txtMaterials.Size = new System.Drawing.Size(161, 22);
            this.txtMaterials.TabIndex = 20;
            // 
            // Materials
            // 
            this.Materials.AutoSize = true;
            this.Materials.Location = new System.Drawing.Point(31, 159);
            this.Materials.Name = "Materials";
            this.Materials.Size = new System.Drawing.Size(47, 12);
            this.Materials.TabIndex = 19;
            this.Materials.Text = "Materials";
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(103, 117);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(161, 22);
            this.txtColor.TabIndex = 18;
            // 
            // Color
            // 
            this.Color.AutoSize = true;
            this.Color.Location = new System.Drawing.Point(31, 120);
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(32, 12);
            this.Color.TabIndex = 17;
            this.Color.Text = "Color";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(103, 24);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(161, 22);
            this.txtProduct_Id.TabIndex = 16;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(31, 27);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(57, 12);
            this.Product_Id.TabIndex = 15;
            this.Product_Id.Text = "Product_Id";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(244, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 12);
            this.label1.TabIndex = 30;
            this.label1.Text = "label1";
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(424, 503);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(120, 23);
            this.Delete.TabIndex = 31;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Product1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(801, 547);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.txtMaterialID);
            this.Controls.Add(this.MaterialID);
            this.Controls.Add(this.txtVersion);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtType);
            this.Controls.Add(this.Type);
            this.Controls.Add(this.txtDimension);
            this.Controls.Add(this.Dimension);
            this.Controls.Add(this.txtMaterials);
            this.Controls.Add(this.Materials);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.Color);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Product_Id);
            this.Name = "Product1";
            this.Text = "Product1";
            this.Load += new System.EventHandler(this.Product1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.TextBox txtMaterialID;
        private System.Windows.Forms.Label MaterialID;
        private System.Windows.Forms.TextBox txtVersion;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtType;
        private System.Windows.Forms.Label Type;
        private System.Windows.Forms.TextBox txtDimension;
        private System.Windows.Forms.Label Dimension;
        private System.Windows.Forms.TextBox txtMaterials;
        private System.Windows.Forms.Label Materials;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.Label Color;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Delete;
    }
}