﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Order2 : Form
    {
        public Order2()
        {
            InitializeComponent();
        }

        private void Order2_Load(object sender, EventArgs e)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            if (Company.Checked == false)
            {
                txtVersion.ReadOnly = true;
                txtProduct_Id.ReadOnly = true;
            }


            using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    try
                    {
                        OleDbCommand command = new OleDbCommand(query, connection);
                        connection.Open();
                        object result = command.ExecuteScalar();
                        label12.Text = (result) != null ? result.ToString() : "404Error";
                    }
                    catch (Exception ex)
                    {
                        label12.Text = $"錯誤：{ex.Message}";
                    }

                    if (GetDataFromDatabase("Select Department_Id from [Data]") == "D008" || GetDataFromDatabase("Select Department_Id from [Data]") == "D007")
                    {

                    }
                    else
                    {
                        MessageBox.Show("Only D007, D008 have access");
                        Close();
                    }
                }
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void lblProductName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProduct_Cost_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtColumn_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblProductDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResponseStaff_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtStartDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtFinishDate_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtShippingOption_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void Add_Click(object sender, EventArgs e)
        {
            if (Company.Checked == false)
            {
                GetDataFromDatabase("INSERT INTO [Order] " +
                    "(Product_Id, Version, Comment, [Column], Department_Id, ResponedStaff, Order_Cost, Product_Description, StartDate, FinishDate, ShippingOption, Customer_Id, State) " +
                    "VALUES (" +
                    "'Null', " +
                    "'Null', " +
                    "'" + textBox1.Text.Replace("'", "''") + "', " +
                    (int.TryParse(txtColumn.Text, out int columnValue) ? columnValue : 0) + ", " +
                    "'D008', " +
                    "'" + txtResponseStaff.Text.Replace("'", "''") + "', " +
                    "'" + txtProduct_Cost.Text.Replace("'", "''") + "', " +
                    "'" + lblProductDescription.Text.Replace("'", "''") + "', " +
                    "#" + DateTime.Parse(txtStartDate.Text).ToString("yyyy-MM-dd") + "#, " +
                    "#" + DateTime.Parse(txtFinishDate.Text).ToString("yyyy-MM-dd") + "#, " +
                    "'" + txtShippingOption.Text.Replace("'", "''") + "', " +
                    "'" + textBox3.Text.Replace("'", "''") + "', " +
                    "'pay');");

                String a = GetDataFromDatabase("Select MAX(Order_Id) AS MaxValue From [Order]");

                String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
                String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
                String Exchange = "Product_Id: Null, Order_Id: " + a + ", Version: Null, Comment: " + textBox1.Text + ", Column: " + txtColumn.Text + ", Department_Id: D008, Responded Staff: " + txtResponseStaff.Text + ", Order_Cost: " + txtProduct_Cost.Text + ", Product_Description: " + lblProductDescription.Text + ", StartDate: " + txtStartDate.Text + ", FinishDate: " + txtFinishDate.Text + ", ShippingOption" + txtShippingOption.Text + ", Customer_Id: " + textBox3.Text + ", State: order";
                string sanitizedId = Id.Replace("'", "''");
                string sanitizedDepartment = Department.Replace("'", "''");
                string sanitizedExchange = Exchange.Replace("'", "''");
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                                   "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "', NULL, '" + sanitizedExchange + "');");

                MessageBox.Show("Adding success");

                Close();
            }
            else
            {
                GetDataFromDatabase("INSERT INTO [Order] " +
                    "(Product_Id, Version, Comment, [Column], Department_Id, ResponedStaff, Order_Cost, Product_Description, StartDate, FinishDate, ShippingOption, Customer_Id, State) " +
                    "VALUES (" +
                    "'" + txtProduct_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtVersion.Text.Replace("'", "''") + "', " +
                    "'" + textBox1.Text.Replace("'", "''") + "', " +
                    (int.TryParse(txtColumn.Text, out int columnValue) ? columnValue : 0) + ", " +
                    "'D008', " +
                    "'" + txtResponseStaff.Text.Replace("'", "''") + "', " +
                    "'" + txtProduct_Cost.Text.Replace("'", "''") + "', " +
                    "'" + lblProductDescription.Text.Replace("'", "''") + "', " +
                    "#" + DateTime.Parse(txtStartDate.Text).ToString("yyyy-MM-dd") + "#, " +
                    "#" + DateTime.Parse(txtFinishDate.Text).ToString("yyyy-MM-dd") + "#, " +
                    "'" + txtShippingOption.Text.Replace("'", "''") + "', " +
                    "'" + textBox3.Text.Replace("'", "''") + "', " +
                    "'pay1');");

                String a = GetDataFromDatabase("Select MAX(Order_Id) AS MaxValue From [Order]");

                String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
                String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
                String Exchange = "Product_Id: " + txtProduct_Id.Text + ", Order_Id: " + a + ", Version: " + txtVersion.Text + ", Comment: " + textBox1.Text + ", Column: " + txtColumn.Text + ", Department_Id: D008, Responded Staff: " + txtResponseStaff.Text + ", Order_Cost: " + txtProduct_Cost.Text + ", Product_Description: " + lblProductDescription.Text + ", StartDate: " + txtStartDate.Text + ", FinishDate: " + txtFinishDate.Text + ", ShippingOption" + txtShippingOption.Text + ", Customer_Id: " + textBox3.Text + ", State: order";
                string sanitizedId = Id.Replace("'", "''");
                string sanitizedDepartment = Department.Replace("'", "''");
                string sanitizedExchange = Exchange.Replace("'", "''");
                GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
                                   "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "', NULL, '" + sanitizedExchange + "');");

                MessageBox.Show("Adding success");
            }

        }

        private void Company_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Company_CheckedChanged_1(object sender, EventArgs e)
        {
            if (Company.Checked == false)
            {
                txtVersion.ReadOnly = true;
                txtProduct_Id.ReadOnly = true;
            }
            else
            {
                txtVersion.ReadOnly = false;
                txtProduct_Id.ReadOnly = false;
            }
        }
    }
}

