﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Net.NetworkInformation;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class End_Date : Form
    {

        public string order_Id { get; set; }
        public string production_Id { get; set; }
        public string product_Id { get; set; }

        public End_Date()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }

        private void Production1_Load(object sender, EventArgs e)
        {
            label1.Visible = false;
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D003")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D001 has access");
                Close();
            }

            if(GetDataFromDatabase("Select Department_Id from [Data]") != "D007")
            {
                txtProduction_Id.ReadOnly = true;
                txtOrder_Id.ReadOnly = true;
                txtProduct_Id.ReadOnly = true;
                Delete.Visible = false;
            }

            txtProduction_Id.Text = production_Id;
            txtOrder_Id.Text = order_Id;
            txtProduct_Id.Text = product_Id;

            txtMaterial_Id.Text = GetDataFromDatabase("Select Material_Id from Product_Production_Order where Production_Id = " + int.Parse(txtProduction_Id.Text) + ";");
            txtAmount.Text = GetDataFromDatabase("Select Amount from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtTeam_Leader.Text = GetDataFromDatabase("Select Team_Leader from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtWorker.Text = GetDataFromDatabase("Select Worker from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtProduction_Compound.Text = GetDataFromDatabase("Select Production_Compound from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtStart_Date.Text = GetDataFromDatabase("Select Start_Date from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtEnd_Date.Text = GetDataFromDatabase("Select End_Date from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");
            txtDetail.Text = GetDataFromDatabase("Select Detail from Product_Production_Order where Production_Id =" + int.Parse(txtProduction_Id.Text) + ";");

            label1.Text = "Production_Id: " + txtProduct_Id.Text + ", Order_Id: " + txtOrder_Id.Text + ", Product_Id: " + txtProduct_Id.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Amount: " + txtAmount.Text + ", Team Leader: " + txtTeam_Leader.Text + ", Worker: " + txtWorker.Text + ", Production_Compound: " + txtProduction_Compound.Text + ", Start_Date: " + txtStart_Date.Text + ", End Date: " + txtEnd_Date.Text + ", Detail: " + txtDetail.Text;
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Modify_Click(object sender, EventArgs e)
        {
            String Id = GetDataFromDatabase("Select Staff_Id from Data");
            String Department = GetDataFromDatabase("Select Department_Id from Data");

            GetDataFromDatabase("UPDATE [Product_Production_Order] SET " +
                "Order_Id = '" + txtOrder_Id.Text.Replace("'", "''") + "', " +
                "Product_Id = '" + txtProduct_Id.Text.Replace("'", "''") + "', " +
                "Material_Id = '" + txtMaterial_Id.Text.Replace("'", "''") + "', " +
                "Amount = '" + txtAmount.Text.Replace("'", "''") + "', " +
                "Team_Leader = '" + txtTeam_Leader.Text.Replace("'", "''") + "', " +
                "Worker = '" + txtWorker.Text.Replace("'", "''") + "', " +
                "Production_Compound = '" + txtProduction_Compound.Text.Replace("'", "''") + "', " +
                "Start_Date = '" + txtStart_Date.Text.Replace("'", "''") + "', " +
                "End_Date = '" + txtEnd_Date.Text.Replace("'", "''") + "', " +
                "Detail = '" + txtDetail.Text.Replace("'", "''") + "' " +
                "WHERE Production_Id = " + int.Parse(txtProduction_Id.Text) + ";");

            String Exchange = "Production_Id: " + txtProduct_Id.Text + ", Order_Id: " + txtOrder_Id.Text + ", Product_Id: " + txtProduct_Id.Text + ", Material_Id: " + txtMaterial_Id.Text + ", Amount: " + txtAmount.Text + ", Team Leader: " + txtTeam_Leader.Text + ", Worker: " + txtWorker.Text + ", Production_Compound: " + txtProduction_Compound.Text + ", Start_Date: " + txtStart_Date.Text + ", End Date: " + txtEnd_Date.Text + ", Detail: " + txtDetail.Text;
            string sanitizedLabel1 = label1.Text.Replace("'", "''");
            string sanitizedExchange = Exchange.Replace("'", "''");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel1 + "', '" + sanitizedExchange + "');");
            MessageBox.Show("Setting successful");
            Close();

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
            (
                "Are yuo sure？",
                "sure",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Product_Production_Order where Production_Id = " + int.Parse(txtProduction_Id.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }

            string sanitizedLabel16 = label1.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
