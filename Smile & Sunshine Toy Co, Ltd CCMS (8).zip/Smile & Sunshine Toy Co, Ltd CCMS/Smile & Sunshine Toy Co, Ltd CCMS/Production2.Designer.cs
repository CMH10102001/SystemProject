﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Production2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Add = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.txtDetail = new System.Windows.Forms.TextBox();
            this.Detail = new System.Windows.Forms.Label();
            this.txtStart_Date = new System.Windows.Forms.TextBox();
            this.Start_Date = new System.Windows.Forms.Label();
            this.txtProduction_Compound = new System.Windows.Forms.TextBox();
            this.Production_Compound = new System.Windows.Forms.Label();
            this.txtEnd_Date = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.txtTeam_Leader = new System.Windows.Forms.TextBox();
            this.Team_Leader = new System.Windows.Forms.Label();
            this.txtAmount = new System.Windows.Forms.TextBox();
            this.Amount = new System.Windows.Forms.Label();
            this.txtWorker = new System.Windows.Forms.TextBox();
            this.Worker = new System.Windows.Forms.Label();
            this.txtDimension = new System.Windows.Forms.TextBox();
            this.Dimension = new System.Windows.Forms.Label();
            this.txtOrder_Id = new System.Windows.Forms.TextBox();
            this.Order_Id = new System.Windows.Forms.Label();
            this.txtProduct_Id = new System.Windows.Forms.TextBox();
            this.Product_Id = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // Add
            // 
            this.Add.Location = new System.Drawing.Point(739, 592);
            this.Add.Margin = new System.Windows.Forms.Padding(2);
            this.Add.Name = "Add";
            this.Add.Size = new System.Drawing.Size(175, 39);
            this.Add.TabIndex = 235;
            this.Add.Text = "Add";
            this.Add.UseVisualStyleBackColor = true;
            this.Add.Click += new System.EventHandler(this.Add_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(10, 304);
            this.label18.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 12);
            this.label18.TabIndex = 218;
            this.label18.Text = "Employee";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(10, 605);
            this.label11.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(41, 12);
            this.label11.TabIndex = 217;
            this.label11.Text = "Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(10, 559);
            this.label10.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 12);
            this.label10.TabIndex = 216;
            this.label10.Text = "Activities";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(10, 513);
            this.label9.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 12);
            this.label9.TabIndex = 215;
            this.label9.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(10, 468);
            this.label8.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 12);
            this.label8.TabIndex = 214;
            this.label8.Text = "Invoices";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(10, 425);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 12);
            this.label7.TabIndex = 213;
            this.label7.Text = "Reports";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 377);
            this.label6.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(41, 12);
            this.label6.TabIndex = 212;
            this.label6.Text = "Product";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(9, 336);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(30, 12);
            this.label5.TabIndex = 211;
            this.label5.Text = "Deals";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 271);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 12);
            this.label4.TabIndex = 210;
            this.label4.Text = "Companies";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(9, 235);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(32, 12);
            this.label3.TabIndex = 209;
            this.label3.Text = "Leads";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(10, 199);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 12);
            this.label2.TabIndex = 208;
            this.label2.Text = "Tasks";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 163);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 12);
            this.label1.TabIndex = 207;
            this.label1.Text = "Leads Dashboard";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(877, 16);
            this.label12.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(37, 12);
            this.label12.TabIndex = 205;
            this.label12.Text = "Admin";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(11, 2);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(199, 132);
            this.pictureBox1.TabIndex = 206;
            this.pictureBox1.TabStop = false;
            // 
            // txtDetail
            // 
            this.txtDetail.Location = new System.Drawing.Point(375, 580);
            this.txtDetail.Name = "txtDetail";
            this.txtDetail.Size = new System.Drawing.Size(161, 22);
            this.txtDetail.TabIndex = 259;
            // 
            // Detail
            // 
            this.Detail.AutoSize = true;
            this.Detail.Location = new System.Drawing.Point(248, 580);
            this.Detail.Name = "Detail";
            this.Detail.Size = new System.Drawing.Size(32, 12);
            this.Detail.TabIndex = 258;
            this.Detail.Text = "Detail";
            // 
            // txtStart_Date
            // 
            this.txtStart_Date.Location = new System.Drawing.Point(375, 477);
            this.txtStart_Date.Name = "txtStart_Date";
            this.txtStart_Date.Size = new System.Drawing.Size(161, 22);
            this.txtStart_Date.TabIndex = 257;
            // 
            // Start_Date
            // 
            this.Start_Date.AutoSize = true;
            this.Start_Date.Location = new System.Drawing.Point(248, 477);
            this.Start_Date.Name = "Start_Date";
            this.Start_Date.Size = new System.Drawing.Size(53, 12);
            this.Start_Date.TabIndex = 256;
            this.Start_Date.Text = "Start_Date";
            // 
            // txtProduction_Compound
            // 
            this.txtProduction_Compound.Location = new System.Drawing.Point(375, 426);
            this.txtProduction_Compound.Name = "txtProduction_Compound";
            this.txtProduction_Compound.Size = new System.Drawing.Size(161, 22);
            this.txtProduction_Compound.TabIndex = 255;
            // 
            // Production_Compound
            // 
            this.Production_Compound.AutoSize = true;
            this.Production_Compound.Location = new System.Drawing.Point(248, 426);
            this.Production_Compound.Name = "Production_Compound";
            this.Production_Compound.Size = new System.Drawing.Size(115, 12);
            this.Production_Compound.TabIndex = 254;
            this.Production_Compound.Text = "Production_Compound";
            // 
            // txtEnd_Date
            // 
            this.txtEnd_Date.Location = new System.Drawing.Point(375, 529);
            this.txtEnd_Date.Name = "txtEnd_Date";
            this.txtEnd_Date.Size = new System.Drawing.Size(161, 22);
            this.txtEnd_Date.TabIndex = 253;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(248, 529);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(51, 12);
            this.label13.TabIndex = 252;
            this.label13.Text = "End_Date";
            // 
            // txtTeam_Leader
            // 
            this.txtTeam_Leader.Location = new System.Drawing.Point(375, 335);
            this.txtTeam_Leader.Name = "txtTeam_Leader";
            this.txtTeam_Leader.Size = new System.Drawing.Size(161, 22);
            this.txtTeam_Leader.TabIndex = 251;
            // 
            // Team_Leader
            // 
            this.Team_Leader.AutoSize = true;
            this.Team_Leader.Location = new System.Drawing.Point(248, 335);
            this.Team_Leader.Name = "Team_Leader";
            this.Team_Leader.Size = new System.Drawing.Size(69, 12);
            this.Team_Leader.TabIndex = 250;
            this.Team_Leader.Text = "Team_Leader";
            // 
            // txtAmount
            // 
            this.txtAmount.Location = new System.Drawing.Point(375, 235);
            this.txtAmount.Name = "txtAmount";
            this.txtAmount.Size = new System.Drawing.Size(161, 22);
            this.txtAmount.TabIndex = 249;
            // 
            // Amount
            // 
            this.Amount.AutoSize = true;
            this.Amount.Location = new System.Drawing.Point(248, 235);
            this.Amount.Name = "Amount";
            this.Amount.Size = new System.Drawing.Size(43, 12);
            this.Amount.TabIndex = 248;
            this.Amount.Text = "Amount";
            // 
            // txtWorker
            // 
            this.txtWorker.Location = new System.Drawing.Point(375, 380);
            this.txtWorker.Name = "txtWorker";
            this.txtWorker.Size = new System.Drawing.Size(161, 22);
            this.txtWorker.TabIndex = 245;
            // 
            // Worker
            // 
            this.Worker.AutoSize = true;
            this.Worker.Location = new System.Drawing.Point(248, 380);
            this.Worker.Name = "Worker";
            this.Worker.Size = new System.Drawing.Size(41, 12);
            this.Worker.TabIndex = 244;
            this.Worker.Text = "Worker";
            // 
            // txtDimension
            // 
            this.txtDimension.Location = new System.Drawing.Point(375, 287);
            this.txtDimension.Name = "txtDimension";
            this.txtDimension.Size = new System.Drawing.Size(161, 22);
            this.txtDimension.TabIndex = 243;
            // 
            // Dimension
            // 
            this.Dimension.AutoSize = true;
            this.Dimension.Location = new System.Drawing.Point(248, 287);
            this.Dimension.Name = "Dimension";
            this.Dimension.Size = new System.Drawing.Size(55, 12);
            this.Dimension.TabIndex = 242;
            this.Dimension.Text = "Dimension";
            // 
            // txtOrder_Id
            // 
            this.txtOrder_Id.Location = new System.Drawing.Point(375, 143);
            this.txtOrder_Id.Name = "txtOrder_Id";
            this.txtOrder_Id.Size = new System.Drawing.Size(161, 22);
            this.txtOrder_Id.TabIndex = 239;
            // 
            // Order_Id
            // 
            this.Order_Id.AutoSize = true;
            this.Order_Id.Location = new System.Drawing.Point(248, 143);
            this.Order_Id.Name = "Order_Id";
            this.Order_Id.Size = new System.Drawing.Size(48, 12);
            this.Order_Id.TabIndex = 238;
            this.Order_Id.Text = "Order_Id";
            // 
            // txtProduct_Id
            // 
            this.txtProduct_Id.Location = new System.Drawing.Point(375, 97);
            this.txtProduct_Id.Name = "txtProduct_Id";
            this.txtProduct_Id.Size = new System.Drawing.Size(161, 22);
            this.txtProduct_Id.TabIndex = 237;
            // 
            // Product_Id
            // 
            this.Product_Id.AutoSize = true;
            this.Product_Id.Location = new System.Drawing.Point(248, 97);
            this.Product_Id.Name = "Product_Id";
            this.Product_Id.Size = new System.Drawing.Size(57, 12);
            this.Product_Id.TabIndex = 236;
            this.Product_Id.Text = "Product_Id";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(375, 189);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(161, 22);
            this.txtMaterial_Id.TabIndex = 261;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(248, 189);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(59, 12);
            this.Material_Id.TabIndex = 260;
            this.Material_Id.Text = "Material_Id";
            // 
            // Production2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1029, 668);
            this.Controls.Add(this.txtMaterial_Id);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtDetail);
            this.Controls.Add(this.Detail);
            this.Controls.Add(this.txtStart_Date);
            this.Controls.Add(this.Start_Date);
            this.Controls.Add(this.txtProduction_Compound);
            this.Controls.Add(this.Production_Compound);
            this.Controls.Add(this.txtEnd_Date);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtTeam_Leader);
            this.Controls.Add(this.Team_Leader);
            this.Controls.Add(this.txtAmount);
            this.Controls.Add(this.Amount);
            this.Controls.Add(this.txtWorker);
            this.Controls.Add(this.Worker);
            this.Controls.Add(this.txtDimension);
            this.Controls.Add(this.Dimension);
            this.Controls.Add(this.txtOrder_Id);
            this.Controls.Add(this.Order_Id);
            this.Controls.Add(this.txtProduct_Id);
            this.Controls.Add(this.Product_Id);
            this.Controls.Add(this.Add);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label12);
            this.Name = "Production2";
            this.Text = "Production2";
            this.Load += new System.EventHandler(this.Production2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button Add;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtDetail;
        private System.Windows.Forms.Label Detail;
        private System.Windows.Forms.TextBox txtStart_Date;
        private System.Windows.Forms.Label Start_Date;
        private System.Windows.Forms.TextBox txtProduction_Compound;
        private System.Windows.Forms.Label Production_Compound;
        private System.Windows.Forms.TextBox txtEnd_Date;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtTeam_Leader;
        private System.Windows.Forms.Label Team_Leader;
        private System.Windows.Forms.TextBox txtAmount;
        private System.Windows.Forms.Label Amount;
        private System.Windows.Forms.TextBox txtWorker;
        private System.Windows.Forms.Label Worker;
        private System.Windows.Forms.TextBox txtDimension;
        private System.Windows.Forms.Label Dimension;
        private System.Windows.Forms.TextBox txtOrder_Id;
        private System.Windows.Forms.Label Order_Id;
        private System.Windows.Forms.TextBox txtProduct_Id;
        private System.Windows.Forms.Label Product_Id;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Label Material_Id;
    }
}