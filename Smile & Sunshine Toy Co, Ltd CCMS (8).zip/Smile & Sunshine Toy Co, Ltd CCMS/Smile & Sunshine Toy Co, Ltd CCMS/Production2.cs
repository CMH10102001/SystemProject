﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Production2 : Form
    {
        public Production2()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Production2_Load(object sender, EventArgs e)
        {
            String a = GetDataFromDatabase("Select Staff_Id from [Data]");
            label12.Text = GetDataFromDatabase("Select StaffName from [Staff] where Staff_Id = '" + a + "';");

            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D003")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D001 has access");
                Close();
            }
        }

        private void Add_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("INSERT INTO [Product_Production_Order]" + "(Order_Id, Product_Id, Material_Id, Amount, Team_Leader, Worker, Production_Compound, Start_Date, End_Date, Detail)" +
                    "VALUES (" +
                    "'" + txtOrder_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtProduct_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtMaterial_Id.Text.Replace("'", "''") + "', " +
                    "'" + txtAmount.Text.Replace("'", "''") + "', " +
                    "'" + txtTeam_Leader.Text.Replace("'", "''") + "', " +
                    "'" + txtWorker.Text.Replace("'", "''") + "', " +
                    "'" + txtProduction_Compound.Text.Replace("'", "''") + "', " +
                    "'" + txtStart_Date.Text.Replace("'", "''") + "', " +
                    "'" + txtEnd_Date.Text.Replace("'", "''") + "', " +
                    "'" + txtDetail.Text.Replace("'", "''") + "' " +
                    ");");


            String a = GetDataFromDatabase("Select MAX(Production_Id) AS MaxValue From Product_Production_Order");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data] ");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data] ");
            String Exchange = "Production_Id: " + a + ", Order_Id: " + txtOrder_Id.Text + ", Product_Id: " + txtProduct_Id.Text + ", Material_Id: " + txtMaterial_Id.Text + ",  Amount: " + txtAmount.Text + ", Team Leader: " + txtTeam_Leader.Text + ", Worker: " + txtWorker.Text + ", Production_Compound: " + txtProduction_Compound.Text + ", Start_Date: " + txtStart_Date.Text + ", End Date: " + txtEnd_Date.Text + ", Detail: " + txtDetail.Text;
            string sanitizedId = Id.Replace("'", "''");
            string sanitizedDepartment = Department.Replace("'", "''");
            string sanitizedExchange = Exchange.Replace("'", "''");
            GetDataFromDatabase("INSERT INTO [Activity] ([StaffID], [DepartmentID], [Origin], [Update]) " +
            "VALUES ('" + sanitizedId + "', '" + sanitizedDepartment + "', NULL, '" + sanitizedExchange + "');");

            MessageBox.Show("Adding success");

            Close();
        }
    }
}
