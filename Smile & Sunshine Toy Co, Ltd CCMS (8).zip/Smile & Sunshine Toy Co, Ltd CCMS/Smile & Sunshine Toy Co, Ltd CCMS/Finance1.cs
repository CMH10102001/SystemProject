﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Finance1 : Form
    {
        public string PayId { get; set; }
        public string OrderId { get; set; }
        public string StaffId { get; set; }
        public string CustomerId { get; set; }
        public Finance1()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Finance1_Load(object sender, EventArgs e)
        {
            txtPay_Id.Text = PayId;
            txtOrder_Id.Text = OrderId;
            txtStaff_Id.Text = StaffId;
            txtCustomer_Id.Text = CustomerId;
            txtPayment_method.Text = GetDataFromDatabase("Select Payment_method from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
            txtPay_Time.Text = GetDataFromDatabase("Select Pay_Time from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
            txtPay_Date.Text = GetDataFromDatabase("Select Pay_Date from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
            txtState.Text = GetDataFromDatabase("Select State from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
            txtPay_Amount.Text = GetDataFromDatabase("Select Pay_Amount from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
            txtTotal_Pay_Amount.Text = GetDataFromDatabase("Select Total_Pay_Amount from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");

            label13.Text = "Pay_Id: " + txtPay_Id.Text + ", Order_Id: " + txtOrder_Id.Text + ", Customer_Id: " + txtCustomer_Id.Text + ", Staff_Id: " + txtStaff_Id.Text + ", Payment_method: " + txtPayment_method.Text + ", Pay_Amount: " + txtPay_Amount.Text + ", Total_Pay_Amount: " + txtTotal_Pay_Amount + ", Pay_Date: " + txtPay_Date.Text + ", Pay_Time: " + txtPay_Time + ", State: " + txtState;

            label13.Visible = false;

            if (GetDataFromDatabase("Select Department_Id from [Data] ") == "D007" || GetDataFromDatabase("Select Department_Id from [Data] ") == "D006")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D006 has access");
                Close();
            }

            if (GetDataFromDatabase("Select Department_Id from [Data] ") != "D007")
            {
                txtOrder_Id.ReadOnly = true;
                txtPay_Id.ReadOnly = true;
                txtCustomer_Id.ReadOnly = true;
                txtState.ReadOnly = true;
            }


            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    label12.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    label12.Text = $"錯誤：{ex.Message}";
                }
            }


        }

        private void Add_Click(object sender, EventArgs e)
        {
            GetDataFromDatabase("Update [Finance] set " +
                               "', Order_Id = '" + txtOrder_Id.Text.Replace("'", "''") +
                               "', Customer_Id = '" + txtCustomer_Id.Text.Replace("'", "''") +
                               "', Staff_Id = '" + txtStaff_Id.Text.Replace("'", "''") +
                               "', Payment_method = '" + txtPayment_method.Text.Replace("'", "''") +
                               "', Pay_Amount = '" + Pay_Amount.Text.Replace("'", "''") +
                               "', Total_Pay_Amount = '" + txtTotal_Pay_Amount.Text.Replace("'", "''") +
                               "', Pay_Date = #" + DateTime.Parse(txtPay_Date.Text).ToString("yyyy-MM-dd") +
                               "#, Pay_Time = #" + DateTime.Parse(txtPay_Time.Text).ToString("yyyy-MM-dd") +
                               "#, State = '" + txtState.Text.Replace("'", "''") +
                               "' where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");


            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Pay_Id: " + txtPay_Id.Text + ", Order_Id: " + txtOrder_Id.Text + ", Customer_Id: " + txtCustomer_Id.Text + ", Staff_Id: " + txtStaff_Id.Text + ", Payment_method: " + txtPayment_method.Text + ", Pay_Amount: " + txtPay_Amount.Text + ", Total_Pay_Amount: " + txtTotal_Pay_Amount.Text + ", Pay_Date: " + txtPay_Date.Text + ", Pay_Time: " + txtPay_Time + ", State: " + txtState;

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label3.Text + "','" + exchange + "');");

            MessageBox.Show("Update Successful");

            Close();
        }

        private void label13_Click(object sender, EventArgs e)
        {

        }

        private void txtState_TextChanged(object sender, EventArgs e)
        {

        }

        private void State_Click(object sender, EventArgs e)
        {

        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
           (
               "Are yuo sure？",
               "sure",
               MessageBoxButtons.YesNo,
               MessageBoxIcon.Question
           );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Finance where Pay_Id = " + int.Parse(txtPay_Id.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }

            string sanitizedLabel16 = label13.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();

        }
    }
}
