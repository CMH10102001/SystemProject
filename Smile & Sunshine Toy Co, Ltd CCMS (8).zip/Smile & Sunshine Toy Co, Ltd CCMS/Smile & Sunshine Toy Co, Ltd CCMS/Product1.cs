﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Product1 : Form
    {
        public string ProductId { get; set; }
        public string Version { get; set; }
        public string MaterialId { get; set; }

        public Product1()
        {
            InitializeComponent();
        }

        private string GetDataFromDatabase(string query)
        {
            string connectionString = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";

            using (OleDbConnection conn = new OleDbConnection(connectionString))
            using (OleDbCommand cmd = new OleDbCommand(query, conn))
            {
                conn.Open();
                return cmd.ExecuteScalar()?.ToString() ?? "Error";
            }
        }


        private void Product1_Load(object sender, EventArgs e)
        {
            if (GetDataFromDatabase("Select Department_Id from [Data]") == "D007" || GetDataFromDatabase("Select Department_Id from [Data]") == "D001")
            {

            }
            else
            {
                MessageBox.Show("Only D007 or D001 has access");
                Close();
            }

            txtProduct_Id.Text = ProductId;
            txtVersion.Text = Version;
            txtMaterialID.Text = MaterialId;
            txtColor.Text = GetDataFromDatabase("Select Color from [Product] where Product_Id =" + int.Parse(txtProduct_Id.Text) + ";");
            txtMaterials.Text = GetDataFromDatabase("Select Materials from [Product] where Product_Id =" + int.Parse(txtProduct_Id.Text) + ";");
            txtDimension.Text = GetDataFromDatabase("Select Dimension from [Product] where Product_Id =" + int.Parse(txtProduct_Id.Text) + ";");
            txtType.Text = GetDataFromDatabase("Select Type from [Product] where Product_Id =" + int.Parse(txtProduct_Id.Text) + ";");

            label1.Text = "Product_Id: " + txtProduct_Id.Text + ", Version:" + txtVersion.Text + ", Material ID: " + txtMaterialID.Text + ", Materials: " + txtMaterials.Text + ", Color: " + txtColor.Text + ", Dimension: " + txtDimension.Text + ", Type: " + txtType.Text;

            if (GetDataFromDatabase("Select Department_Id from [Data]") != "D007")
            {
                txtProduct_Id.ReadOnly = true;
                txtVersion.ReadOnly = true;
                txtType.ReadOnly = true;
                Delete.Visible = false;
            }
            label1.Visible = false;
        }

        private void Modify_Click(object sender, EventArgs e)
        {
            String Id = GetDataFromDatabase("Select Staff_Id from [Data]");
            String Department = GetDataFromDatabase("Select Department_Id from [Data]");
            String exchange = "Product_Id: " + txtProduct_Id.Text + ", Version:" + txtVersion.Text + ", Material ID: " + txtMaterialID.Text + ", Materials: " + txtMaterials.Text + ", Color: " + txtColor.Text + ", Dimension: " + txtDimension.Text + ", Type: " + txtType.Text;

            GetDataFromDatabase("Update [Product] set " +
                                " Color = '" + txtColor.Text.Replace("'", "''") +
                                "', Materials = '" + txtMaterials.Text.Replace("'", "''") +
                                "', MaterailID = '" + txtMaterialID.Text.Replace("'", "''") +
                                "', Type = '" + txtType.Text.Replace("'", "''") +
                                "', Dimension = '" + txtDimension.Text.Replace("'", "''") +
                                "', Version = '" + txtVersion.Text.Replace("'", "''") +
                                "' where Product_Id = " + int.Parse(txtProduct_Id.Text) +
                                " and Version = '" + txtVersion.Text.Replace("'", "''") +  "';");

            GetDataFromDatabase("Insert into Activity ([StaffID], [DepartmentID] ,[Origin], [Update]) values ('" + Id + "','" + Department + "','" + label1.Text + "','" + exchange + "');");

            MessageBox.Show("Update Successful");

            Close();
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show
            (
                "Are yuo sure？",
                "sure",
                MessageBoxButtons.YesNo,
                MessageBoxIcon.Question
            );
            if (result == DialogResult.Yes)
            {
                GetDataFromDatabase("Delete from Product where Product_Id = " + int.Parse(txtProduct_Id.Text) + ";");
                Close();
                MessageBox.Show("Delete successful");
            }


            string sanitizedLabel16 = label1.Text.Replace("'", "''");
            String Id = GetDataFromDatabase("Select [Staff_Id] from [Data]");
            String Department = GetDataFromDatabase("Select [Department_Id] from [Data]");
            GetDataFromDatabase("INSERT INTO Activity ([StaffID], [DepartmentID], [Origin], [Update]) " + "VALUES ('" + Id + "', '" + Department + "', '" + sanitizedLabel16 + "', 'Delete ');");
            Close();
        }
    }
}
