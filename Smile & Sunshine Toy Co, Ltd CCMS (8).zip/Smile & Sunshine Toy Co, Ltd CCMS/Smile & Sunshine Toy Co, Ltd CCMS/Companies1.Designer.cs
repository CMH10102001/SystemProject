﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Companies1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label13 = new System.Windows.Forms.Label();
            this.Address = new System.Windows.Forms.Label();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.Supplier_Name = new System.Windows.Forms.Label();
            this.txtSupplier_Name = new System.Windows.Forms.TextBox();
            this.Material_Id = new System.Windows.Forms.Label();
            this.txtMaterial_Id = new System.Windows.Forms.TextBox();
            this.Phone_Number = new System.Windows.Forms.Label();
            this.txtPhone_Number = new System.Windows.Forms.TextBox();
            this.Tax = new System.Windows.Forms.Label();
            this.txtTax = new System.Windows.Forms.TextBox();
            this.Email = new System.Windows.Forms.Label();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.Supplier_Id = new System.Windows.Forms.Label();
            this.txtSupplier_Id = new System.Windows.Forms.TextBox();
            this.Modify = new System.Windows.Forms.Button();
            this.Delete = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 926);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(63, 18);
            this.label11.TabIndex = 147;
            this.label11.Text = "Settings";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 856);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 18);
            this.label10.TabIndex = 146;
            this.label10.Text = "Activities";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 786);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(49, 18);
            this.label9.TabIndex = 145;
            this.label9.Text = "Email";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(18, 718);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 18);
            this.label8.TabIndex = 144;
            this.label8.Text = "Invoices";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(18, 656);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 18);
            this.label7.TabIndex = 143;
            this.label7.Text = "Reports";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(16, 584);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(60, 18);
            this.label6.TabIndex = 142;
            this.label6.Text = "Product";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(16, 527);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(48, 18);
            this.label5.TabIndex = 141;
            this.label5.Text = "Deals";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(12, 404);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 18);
            this.label4.TabIndex = 140;
            this.label4.Text = "Companies";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(14, 345);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 139;
            this.label3.Text = "Leads";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(16, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 138;
            this.label2.Text = "Tasks";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(14, 236);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(127, 18);
            this.label1.TabIndex = 137;
            this.label1.Text = "Leads Dashboard";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1200, 45);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 160;
            this.label12.Text = "Admin";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label18.ForeColor = System.Drawing.SystemColors.InfoText;
            this.label18.Location = new System.Drawing.Point(14, 462);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(76, 18);
            this.label18.TabIndex = 162;
            this.label18.Text = "Employee";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(2, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 236);
            this.pictureBox1.TabIndex = 136;
            this.pictureBox1.TabStop = false;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(372, 45);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(54, 18);
            this.label13.TabIndex = 195;
            this.label13.Text = "Admin";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // Address
            // 
            this.Address.AutoSize = true;
            this.Address.Location = new System.Drawing.Point(381, 488);
            this.Address.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Address.Name = "Address";
            this.Address.Size = new System.Drawing.Size(64, 18);
            this.Address.TabIndex = 190;
            this.Address.Text = "Address";
            // 
            // txtAddress
            // 
            this.txtAddress.Location = new System.Drawing.Point(537, 484);
            this.txtAddress.Margin = new System.Windows.Forms.Padding(4);
            this.txtAddress.Name = "txtAddress";
            this.txtAddress.Size = new System.Drawing.Size(259, 29);
            this.txtAddress.TabIndex = 189;
            // 
            // Supplier_Name
            // 
            this.Supplier_Name.AutoSize = true;
            this.Supplier_Name.Location = new System.Drawing.Point(382, 316);
            this.Supplier_Name.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Supplier_Name.Name = "Supplier_Name";
            this.Supplier_Name.Size = new System.Drawing.Size(114, 18);
            this.Supplier_Name.TabIndex = 186;
            this.Supplier_Name.Text = "Supplier_Name";
            // 
            // txtSupplier_Name
            // 
            this.txtSupplier_Name.Location = new System.Drawing.Point(537, 312);
            this.txtSupplier_Name.Margin = new System.Windows.Forms.Padding(4);
            this.txtSupplier_Name.Name = "txtSupplier_Name";
            this.txtSupplier_Name.Size = new System.Drawing.Size(259, 29);
            this.txtSupplier_Name.TabIndex = 185;
            // 
            // Material_Id
            // 
            this.Material_Id.AutoSize = true;
            this.Material_Id.Location = new System.Drawing.Point(381, 371);
            this.Material_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Material_Id.Name = "Material_Id";
            this.Material_Id.Size = new System.Drawing.Size(90, 18);
            this.Material_Id.TabIndex = 184;
            this.Material_Id.Text = "Material_Id";
            // 
            // txtMaterial_Id
            // 
            this.txtMaterial_Id.Location = new System.Drawing.Point(537, 367);
            this.txtMaterial_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtMaterial_Id.Name = "txtMaterial_Id";
            this.txtMaterial_Id.Size = new System.Drawing.Size(259, 29);
            this.txtMaterial_Id.TabIndex = 183;
            // 
            // Phone_Number
            // 
            this.Phone_Number.AutoSize = true;
            this.Phone_Number.Location = new System.Drawing.Point(381, 606);
            this.Phone_Number.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Phone_Number.Name = "Phone_Number";
            this.Phone_Number.Size = new System.Drawing.Size(112, 18);
            this.Phone_Number.TabIndex = 182;
            this.Phone_Number.Text = "Phone_Number";
            // 
            // txtPhone_Number
            // 
            this.txtPhone_Number.Location = new System.Drawing.Point(537, 602);
            this.txtPhone_Number.Margin = new System.Windows.Forms.Padding(4);
            this.txtPhone_Number.Name = "txtPhone_Number";
            this.txtPhone_Number.Size = new System.Drawing.Size(259, 29);
            this.txtPhone_Number.TabIndex = 181;
            // 
            // Tax
            // 
            this.Tax.AutoSize = true;
            this.Tax.Location = new System.Drawing.Point(381, 551);
            this.Tax.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Tax.Name = "Tax";
            this.Tax.Size = new System.Drawing.Size(34, 18);
            this.Tax.TabIndex = 180;
            this.Tax.Text = "Tax";
            // 
            // txtTax
            // 
            this.txtTax.Location = new System.Drawing.Point(537, 546);
            this.txtTax.Margin = new System.Windows.Forms.Padding(4);
            this.txtTax.Name = "txtTax";
            this.txtTax.Size = new System.Drawing.Size(259, 29);
            this.txtTax.TabIndex = 179;
            // 
            // Email
            // 
            this.Email.AutoSize = true;
            this.Email.Location = new System.Drawing.Point(381, 432);
            this.Email.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Email.Name = "Email";
            this.Email.Size = new System.Drawing.Size(49, 18);
            this.Email.TabIndex = 178;
            this.Email.Text = "Email";
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(537, 428);
            this.txtEmail.Margin = new System.Windows.Forms.Padding(4);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(259, 29);
            this.txtEmail.TabIndex = 177;
            // 
            // Supplier_Id
            // 
            this.Supplier_Id.AutoSize = true;
            this.Supplier_Id.Location = new System.Drawing.Point(382, 260);
            this.Supplier_Id.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.Supplier_Id.Name = "Supplier_Id";
            this.Supplier_Id.Size = new System.Drawing.Size(87, 18);
            this.Supplier_Id.TabIndex = 176;
            this.Supplier_Id.Text = "Supplier_Id";
            // 
            // txtSupplier_Id
            // 
            this.txtSupplier_Id.Location = new System.Drawing.Point(537, 256);
            this.txtSupplier_Id.Margin = new System.Windows.Forms.Padding(4);
            this.txtSupplier_Id.Name = "txtSupplier_Id";
            this.txtSupplier_Id.Size = new System.Drawing.Size(259, 29);
            this.txtSupplier_Id.TabIndex = 175;
            // 
            // Modify
            // 
            this.Modify.Location = new System.Drawing.Point(1050, 903);
            this.Modify.Margin = new System.Windows.Forms.Padding(4);
            this.Modify.Name = "Modify";
            this.Modify.Size = new System.Drawing.Size(204, 64);
            this.Modify.TabIndex = 196;
            this.Modify.Text = "Modift";
            this.Modify.UseVisualStyleBackColor = true;
            this.Modify.Click += new System.EventHandler(this.Modify_Click);
            // 
            // Delete
            // 
            this.Delete.Location = new System.Drawing.Point(810, 903);
            this.Delete.Margin = new System.Windows.Forms.Padding(4);
            this.Delete.Name = "Delete";
            this.Delete.Size = new System.Drawing.Size(204, 64);
            this.Delete.TabIndex = 197;
            this.Delete.Text = "Delete";
            this.Delete.UseVisualStyleBackColor = true;
            this.Delete.Click += new System.EventHandler(this.Delete_Click);
            // 
            // Companies1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1309, 1024);
            this.Controls.Add(this.Delete);
            this.Controls.Add(this.Modify);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.Address);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.Supplier_Name);
            this.Controls.Add(this.txtSupplier_Name);
            this.Controls.Add(this.Material_Id);
            this.Controls.Add(this.txtMaterial_Id);
            this.Controls.Add(this.Phone_Number);
            this.Controls.Add(this.txtPhone_Number);
            this.Controls.Add(this.Tax);
            this.Controls.Add(this.txtTax);
            this.Controls.Add(this.Email);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.Supplier_Id);
            this.Controls.Add(this.txtSupplier_Id);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Companies1";
            this.Text = " ";
            this.Load += new System.EventHandler(this.Companies_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.DataGridViewTextBoxColumn formNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryDataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label Address;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Label Supplier_Name;
        private System.Windows.Forms.TextBox txtSupplier_Name;
        private System.Windows.Forms.Label Material_Id;
        private System.Windows.Forms.TextBox txtMaterial_Id;
        private System.Windows.Forms.Label Phone_Number;
        private System.Windows.Forms.TextBox txtPhone_Number;
        private System.Windows.Forms.Label Tax;
        private System.Windows.Forms.TextBox txtTax;
        private System.Windows.Forms.Label Email;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label Supplier_Id;
        private System.Windows.Forms.TextBox txtSupplier_Id;
        private System.Windows.Forms.Button Modify;
        private System.Windows.Forms.Button Delete;
    }
}