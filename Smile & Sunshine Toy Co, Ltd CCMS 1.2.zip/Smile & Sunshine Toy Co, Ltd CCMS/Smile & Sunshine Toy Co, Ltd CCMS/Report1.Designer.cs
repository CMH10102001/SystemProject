﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Report1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblEmployee = new System.Windows.Forms.Label();
            this.lblSetting = new System.Windows.Forms.Label();
            this.lblActivities = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.lblReport = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.lblCompanies = new System.Windows.Forms.Label();
            this.lblLeads = new System.Windows.Forms.Label();
            this.lblTask = new System.Windows.Forms.Label();
            this.lblLeadsDashboard = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(27, 447);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 182;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // lblSetting
            // 
            this.lblSetting.AutoSize = true;
            this.lblSetting.Location = new System.Drawing.Point(30, 910);
            this.lblSetting.Name = "lblSetting";
            this.lblSetting.Size = new System.Drawing.Size(63, 18);
            this.lblSetting.TabIndex = 181;
            this.lblSetting.Text = "Settings";
            // 
            // lblActivities
            // 
            this.lblActivities.AutoSize = true;
            this.lblActivities.Location = new System.Drawing.Point(30, 842);
            this.lblActivities.Name = "lblActivities";
            this.lblActivities.Size = new System.Drawing.Size(76, 18);
            this.lblActivities.TabIndex = 180;
            this.lblActivities.Text = "Activities";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(30, 772);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 179;
            this.lblEmail.Text = "Email";
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.Location = new System.Drawing.Point(30, 705);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(66, 18);
            this.lblInvoice.TabIndex = 178;
            this.lblInvoice.Text = "Invoices";
            // 
            // lblReport
            // 
            this.lblReport.AutoSize = true;
            this.lblReport.Location = new System.Drawing.Point(30, 640);
            this.lblReport.Name = "lblReport";
            this.lblReport.Size = new System.Drawing.Size(61, 18);
            this.lblReport.TabIndex = 177;
            this.lblReport.Text = "Reports";
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(30, 567);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 176;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(30, 507);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 175;
            this.lblDeals.Text = "Deals";
            // 
            // lblCompanies
            // 
            this.lblCompanies.AutoSize = true;
            this.lblCompanies.Location = new System.Drawing.Point(27, 388);
            this.lblCompanies.Name = "lblCompanies";
            this.lblCompanies.Size = new System.Drawing.Size(84, 18);
            this.lblCompanies.TabIndex = 174;
            this.lblCompanies.Text = "Companies";
            this.lblCompanies.Click += new System.EventHandler(this.lblCompanies_Click);
            // 
            // lblLeads
            // 
            this.lblLeads.AutoSize = true;
            this.lblLeads.Location = new System.Drawing.Point(30, 333);
            this.lblLeads.Name = "lblLeads";
            this.lblLeads.Size = new System.Drawing.Size(49, 18);
            this.lblLeads.TabIndex = 173;
            this.lblLeads.Text = "Leads";
            this.lblLeads.Click += new System.EventHandler(this.lblLeads_Click);
            // 
            // lblTask
            // 
            this.lblTask.AutoSize = true;
            this.lblTask.Location = new System.Drawing.Point(27, 282);
            this.lblTask.Name = "lblTask";
            this.lblTask.Size = new System.Drawing.Size(48, 18);
            this.lblTask.TabIndex = 172;
            this.lblTask.Text = "Tasks";
            this.lblTask.Click += new System.EventHandler(this.lblTask_Click_1);
            // 
            // lblLeadsDashboard
            // 
            this.lblLeadsDashboard.AutoSize = true;
            this.lblLeadsDashboard.Location = new System.Drawing.Point(30, 236);
            this.lblLeadsDashboard.Name = "lblLeadsDashboard";
            this.lblLeadsDashboard.Size = new System.Drawing.Size(127, 18);
            this.lblLeadsDashboard.TabIndex = 171;
            this.lblLeadsDashboard.Text = "Leads Dashboard";
            this.lblLeadsDashboard.Click += new System.EventHandler(this.lblLeadsDashboard_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(-1, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 198);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 170;
            this.pictureBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(465, 190);
            this.label12.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 24);
            this.label12.TabIndex = 183;
            this.label12.Text = "Report List";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // Report1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1575, 975);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(this.lblSetting);
            this.Controls.Add(this.lblActivities);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoice);
            this.Controls.Add(this.lblReport);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.lblCompanies);
            this.Controls.Add(this.lblLeads);
            this.Controls.Add(this.lblTask);
            this.Controls.Add(this.lblLeadsDashboard);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Report1";
            this.Text = "Report1";
            this.Load += new System.EventHandler(this.Report1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.Label lblSetting;
        private System.Windows.Forms.Label lblActivities;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.Label lblReport;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label lblCompanies;
        private System.Windows.Forms.Label lblLeads;
        private System.Windows.Forms.Label lblTask;
        private System.Windows.Forms.Label lblLeadsDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
    }
}