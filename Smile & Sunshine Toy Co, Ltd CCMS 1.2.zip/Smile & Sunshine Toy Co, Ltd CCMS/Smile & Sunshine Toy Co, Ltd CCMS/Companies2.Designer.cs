﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Companies2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblQty;
            System.Windows.Forms.Label lblFormNo;
            System.Windows.Forms.Label lblDateIssued;
            System.Windows.Forms.Label lblMaterialDesc;
            System.Windows.Forms.Label lblMaterialSpec;
            System.Windows.Forms.Label lblDeptID;
            System.Windows.Forms.Label lblPriority;
            System.Windows.Forms.Label lblDeliveryDate;
            System.Windows.Forms.Label lblApprovalSign;
            System.Windows.Forms.Label lblSpecialInto;
            System.Windows.Forms.Label lblSupplierID;
            System.Windows.Forms.Label label22;
            System.Windows.Forms.Label lblSupplyName;
            System.Windows.Forms.Label lblSupplyID;
            System.Windows.Forms.Label label25;
            this.lblEmployee = new System.Windows.Forms.Label();
            this.lblSettings = new System.Windows.Forms.Label();
            this.lblActivities = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.lblCompanies = new System.Windows.Forms.Label();
            this.lblLeads = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblLeadsDashboard = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label14 = new System.Windows.Forms.Label();
            this.tbSearchHere = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.lbEmployee = new System.Windows.Forms.ListBox();
            this.lblName = new System.Windows.Forms.Label();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.supplierNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.formNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateIssuedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialSpecificationsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prioritylevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.approvalSignaturesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specicalInstructionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialRequirementFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.material_Requirement_FormTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.Material_Requirement_FormTableAdapter();
            this.supplierTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.SupplierTableAdapter();
            this.btnadd = new System.Windows.Forms.Button();
            this.tbQty = new System.Windows.Forms.TextBox();
            this.tbFormNo = new System.Windows.Forms.TextBox();
            this.tbDateIssued = new System.Windows.Forms.TextBox();
            this.tbMaterialDesc = new System.Windows.Forms.TextBox();
            this.tbMaterialSpec = new System.Windows.Forms.TextBox();
            this.tbDeptID = new System.Windows.Forms.TextBox();
            this.tbPriority = new System.Windows.Forms.TextBox();
            this.tbDeliveryDate = new System.Windows.Forms.TextBox();
            this.tbApprovalSign = new System.Windows.Forms.TextBox();
            this.tbSpecialInto = new System.Windows.Forms.TextBox();
            this.tbSupplierID = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.tbSupplyName = new System.Windows.Forms.TextBox();
            this.tbSupplyID = new System.Windows.Forms.TextBox();
            this.btnSupplyAdd = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.tbSupplyID2 = new System.Windows.Forms.TextBox();
            lblQty = new System.Windows.Forms.Label();
            lblFormNo = new System.Windows.Forms.Label();
            lblDateIssued = new System.Windows.Forms.Label();
            lblMaterialDesc = new System.Windows.Forms.Label();
            lblMaterialSpec = new System.Windows.Forms.Label();
            lblDeptID = new System.Windows.Forms.Label();
            lblPriority = new System.Windows.Forms.Label();
            lblDeliveryDate = new System.Windows.Forms.Label();
            lblApprovalSign = new System.Windows.Forms.Label();
            lblSpecialInto = new System.Windows.Forms.Label();
            lblSupplierID = new System.Windows.Forms.Label();
            label22 = new System.Windows.Forms.Label();
            lblSupplyName = new System.Windows.Forms.Label();
            lblSupplyID = new System.Windows.Forms.Label();
            label25 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // lblQty
            // 
            lblQty.AutoSize = true;
            lblQty.Location = new System.Drawing.Point(952, 768);
            lblQty.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblQty.Name = "lblQty";
            lblQty.Size = new System.Drawing.Size(33, 18);
            lblQty.TabIndex = 175;
            lblQty.Text = "Qty";
            // 
            // lblFormNo
            // 
            lblFormNo.AutoSize = true;
            lblFormNo.Location = new System.Drawing.Point(952, 564);
            lblFormNo.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblFormNo.Name = "lblFormNo";
            lblFormNo.Size = new System.Drawing.Size(107, 18);
            lblFormNo.TabIndex = 167;
            lblFormNo.Text = "Form_Number";
            // 
            // lblDateIssued
            // 
            lblDateIssued.AutoSize = true;
            lblDateIssued.Location = new System.Drawing.Point(952, 616);
            lblDateIssued.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblDateIssued.Name = "lblDateIssued";
            lblDateIssued.Size = new System.Drawing.Size(93, 18);
            lblDateIssued.TabIndex = 169;
            lblDateIssued.Text = "Date_Issued";
            // 
            // lblMaterialDesc
            // 
            lblMaterialDesc.AutoSize = true;
            lblMaterialDesc.Location = new System.Drawing.Point(952, 663);
            lblMaterialDesc.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblMaterialDesc.Name = "lblMaterialDesc";
            lblMaterialDesc.Size = new System.Drawing.Size(156, 18);
            lblMaterialDesc.TabIndex = 171;
            lblMaterialDesc.Text = "Material_Description";
            lblMaterialDesc.Click += new System.EventHandler(this.authorLabel_Click);
            // 
            // lblMaterialSpec
            // 
            lblMaterialSpec.AutoSize = true;
            lblMaterialSpec.Location = new System.Drawing.Point(952, 712);
            lblMaterialSpec.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblMaterialSpec.Name = "lblMaterialSpec";
            lblMaterialSpec.Size = new System.Drawing.Size(167, 18);
            lblMaterialSpec.TabIndex = 173;
            lblMaterialSpec.Text = "Material_Specification";
            // 
            // lblDeptID
            // 
            lblDeptID.AutoSize = true;
            lblDeptID.Location = new System.Drawing.Point(1434, 724);
            lblDeptID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblDeptID.Name = "lblDeptID";
            lblDeptID.Size = new System.Drawing.Size(111, 18);
            lblDeptID.TabIndex = 186;
            lblDeptID.Text = "Department_Id";
            // 
            // lblPriority
            // 
            lblPriority.AutoSize = true;
            lblPriority.Location = new System.Drawing.Point(952, 818);
            lblPriority.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblPriority.Name = "lblPriority";
            lblPriority.Size = new System.Drawing.Size(102, 18);
            lblPriority.TabIndex = 178;
            lblPriority.Text = "Priority_level";
            // 
            // lblDeliveryDate
            // 
            lblDeliveryDate.AutoSize = true;
            lblDeliveryDate.Location = new System.Drawing.Point(1434, 564);
            lblDeliveryDate.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblDeliveryDate.Name = "lblDeliveryDate";
            lblDeliveryDate.Size = new System.Drawing.Size(109, 18);
            lblDeliveryDate.TabIndex = 180;
            lblDeliveryDate.Text = "Delivery_Date";
            // 
            // lblApprovalSign
            // 
            lblApprovalSign.AutoSize = true;
            lblApprovalSign.Location = new System.Drawing.Point(1434, 620);
            lblApprovalSign.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblApprovalSign.Name = "lblApprovalSign";
            lblApprovalSign.Size = new System.Drawing.Size(144, 18);
            lblApprovalSign.TabIndex = 182;
            lblApprovalSign.Text = "Approval_Signature";
            // 
            // lblSpecialInto
            // 
            lblSpecialInto.AutoSize = true;
            lblSpecialInto.Location = new System.Drawing.Point(1434, 669);
            lblSpecialInto.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblSpecialInto.Name = "lblSpecialInto";
            lblSpecialInto.Size = new System.Drawing.Size(141, 18);
            lblSpecialInto.TabIndex = 184;
            lblSpecialInto.Text = "Special_Instruction";
            // 
            // lblSupplierID
            // 
            lblSupplierID.AutoSize = true;
            lblSupplierID.Location = new System.Drawing.Point(1434, 776);
            lblSupplierID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblSupplierID.Name = "lblSupplierID";
            lblSupplierID.Size = new System.Drawing.Size(87, 18);
            lblSupplierID.TabIndex = 188;
            lblSupplierID.Text = "Supplier_Id";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new System.Drawing.Point(1932, 836);
            label22.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label22.Name = "label22";
            label22.Size = new System.Drawing.Size(107, 18);
            label22.TabIndex = 190;
            label22.Text = "Form_Number";
            // 
            // lblSupplyName
            // 
            lblSupplyName.AutoSize = true;
            lblSupplyName.Location = new System.Drawing.Point(326, 861);
            lblSupplyName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblSupplyName.Name = "lblSupplyName";
            lblSupplyName.Size = new System.Drawing.Size(103, 18);
            lblSupplyName.TabIndex = 193;
            lblSupplyName.Text = "Supply_Name";
            // 
            // lblSupplyID
            // 
            lblSupplyID.AutoSize = true;
            lblSupplyID.Location = new System.Drawing.Point(326, 914);
            lblSupplyID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblSupplyID.Name = "lblSupplyID";
            lblSupplyID.Size = new System.Drawing.Size(76, 18);
            lblSupplyID.TabIndex = 195;
            lblSupplyID.Text = "Supply_Id";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new System.Drawing.Point(975, 916);
            label25.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label25.Name = "label25";
            label25.Size = new System.Drawing.Size(76, 18);
            label25.TabIndex = 197;
            label25.Text = "Supply_Id";
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(33, 458);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 142;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Location = new System.Drawing.Point(33, 924);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(63, 18);
            this.lblSettings.TabIndex = 141;
            this.lblSettings.Text = "Settings";
            this.lblSettings.Click += new System.EventHandler(this.lblSettings_Click);
            // 
            // lblActivities
            // 
            this.lblActivities.AutoSize = true;
            this.lblActivities.Location = new System.Drawing.Point(33, 855);
            this.lblActivities.Name = "lblActivities";
            this.lblActivities.Size = new System.Drawing.Size(76, 18);
            this.lblActivities.TabIndex = 140;
            this.lblActivities.Text = "Activities";
            this.lblActivities.Click += new System.EventHandler(this.lblActivities_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(33, 786);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 139;
            this.lblEmail.Text = "Email";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.Location = new System.Drawing.Point(33, 718);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(66, 18);
            this.lblInvoice.TabIndex = 138;
            this.lblInvoice.Text = "Invoices";
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(33, 654);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(61, 18);
            this.lblReports.TabIndex = 137;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblProduct.Location = new System.Drawing.Point(30, 582);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 136;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(30, 520);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 135;
            this.lblDeals.Text = "Deals";
            this.lblDeals.Click += new System.EventHandler(this.lblDeals_Click);
            // 
            // lblCompanies
            // 
            this.lblCompanies.AutoSize = true;
            this.lblCompanies.Location = new System.Drawing.Point(33, 399);
            this.lblCompanies.Name = "lblCompanies";
            this.lblCompanies.Size = new System.Drawing.Size(84, 18);
            this.lblCompanies.TabIndex = 134;
            this.lblCompanies.Text = "Companies";
            this.lblCompanies.Click += new System.EventHandler(this.lblCompanies_Click);
            // 
            // lblLeads
            // 
            this.lblLeads.AutoSize = true;
            this.lblLeads.Location = new System.Drawing.Point(30, 345);
            this.lblLeads.Name = "lblLeads";
            this.lblLeads.Size = new System.Drawing.Size(49, 18);
            this.lblLeads.TabIndex = 133;
            this.lblLeads.Text = "Leads";
            this.lblLeads.Click += new System.EventHandler(this.lblLeads_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(33, 290);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(48, 18);
            this.label2.TabIndex = 132;
            this.label2.Text = "Tasks";
            // 
            // lblLeadsDashboard
            // 
            this.lblLeadsDashboard.AutoSize = true;
            this.lblLeadsDashboard.Location = new System.Drawing.Point(30, 236);
            this.lblLeadsDashboard.Name = "lblLeadsDashboard";
            this.lblLeadsDashboard.Size = new System.Drawing.Size(127, 18);
            this.lblLeadsDashboard.TabIndex = 131;
            this.lblLeadsDashboard.Text = "Leads Dashboard";
            this.lblLeadsDashboard.Click += new System.EventHandler(this.lblLeadsDashboard_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 216);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 130;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(757, 93);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(108, 18);
            this.label14.TabIndex = 129;
            this.label14.Text = "Employee List";
            // 
            // tbSearchHere
            // 
            this.tbSearchHere.Location = new System.Drawing.Point(760, 128);
            this.tbSearchHere.Name = "tbSearchHere";
            this.tbSearchHere.Size = new System.Drawing.Size(278, 29);
            this.tbSearchHere.TabIndex = 128;
            this.tbSearchHere.Text = "Search here!";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(474, 93);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(76, 18);
            this.label13.TabIndex = 127;
            this.label13.Text = "Employee";
            // 
            // lbEmployee
            // 
            this.lbEmployee.FormattingEnabled = true;
            this.lbEmployee.ItemHeight = 18;
            this.lbEmployee.Location = new System.Drawing.Point(474, 135);
            this.lbEmployee.Name = "lbEmployee";
            this.lbEmployee.Size = new System.Drawing.Size(120, 22);
            this.lbEmployee.TabIndex = 126;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(1653, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(54, 18);
            this.lblName.TabIndex = 125;
            this.lblName.Text = "Admin";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(477, 32);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(278, 29);
            this.tbSearch.TabIndex = 124;
            this.tbSearch.Text = "Search here";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.supplierNameDataGridViewTextBoxColumn,
            this.supplierIdDataGridViewTextBoxColumn1});
            this.dataGridView2.DataSource = this.supplierBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(322, 596);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(543, 225);
            this.dataGridView2.TabIndex = 152;
            // 
            // supplierNameDataGridViewTextBoxColumn
            // 
            this.supplierNameDataGridViewTextBoxColumn.DataPropertyName = "Supplier_Name";
            this.supplierNameDataGridViewTextBoxColumn.HeaderText = "Supplier_Name";
            this.supplierNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.supplierNameDataGridViewTextBoxColumn.Name = "supplierNameDataGridViewTextBoxColumn";
            this.supplierNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // supplierIdDataGridViewTextBoxColumn1
            // 
            this.supplierIdDataGridViewTextBoxColumn1.DataPropertyName = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn1.HeaderText = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.supplierIdDataGridViewTextBoxColumn1.Name = "supplierIdDataGridViewTextBoxColumn1";
            this.supplierIdDataGridViewTextBoxColumn1.Width = 150;
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.formNumberDataGridViewTextBoxColumn,
            this.dateIssuedDataGridViewTextBoxColumn,
            this.materialDescriptionDataGridViewTextBoxColumn,
            this.materialSpecificationsDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.prioritylevelDataGridViewTextBoxColumn,
            this.approvalSignaturesDataGridViewTextBoxColumn,
            this.specicalInstructionsDataGridViewTextBoxColumn,
            this.departmentIdDataGridViewTextBoxColumn,
            this.supplierIdDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.materialRequirementFormBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(322, 176);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1929, 364);
            this.dataGridView1.TabIndex = 151;
            // 
            // formNumberDataGridViewTextBoxColumn
            // 
            this.formNumberDataGridViewTextBoxColumn.DataPropertyName = "Form_Number";
            this.formNumberDataGridViewTextBoxColumn.HeaderText = "Form_Number";
            this.formNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.formNumberDataGridViewTextBoxColumn.Name = "formNumberDataGridViewTextBoxColumn";
            this.formNumberDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateIssuedDataGridViewTextBoxColumn
            // 
            this.dateIssuedDataGridViewTextBoxColumn.DataPropertyName = "Date_Issued";
            this.dateIssuedDataGridViewTextBoxColumn.HeaderText = "Date_Issued";
            this.dateIssuedDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateIssuedDataGridViewTextBoxColumn.Name = "dateIssuedDataGridViewTextBoxColumn";
            this.dateIssuedDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialDescriptionDataGridViewTextBoxColumn
            // 
            this.materialDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Material_Description";
            this.materialDescriptionDataGridViewTextBoxColumn.HeaderText = "Material_Description";
            this.materialDescriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.materialDescriptionDataGridViewTextBoxColumn.Name = "materialDescriptionDataGridViewTextBoxColumn";
            this.materialDescriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialSpecificationsDataGridViewTextBoxColumn
            // 
            this.materialSpecificationsDataGridViewTextBoxColumn.DataPropertyName = "Material_Specifications";
            this.materialSpecificationsDataGridViewTextBoxColumn.HeaderText = "Material_Specifications";
            this.materialSpecificationsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.materialSpecificationsDataGridViewTextBoxColumn.Name = "materialSpecificationsDataGridViewTextBoxColumn";
            this.materialSpecificationsDataGridViewTextBoxColumn.Width = 150;
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.qtyDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            this.qtyDataGridViewTextBoxColumn.Width = 150;
            // 
            // prioritylevelDataGridViewTextBoxColumn
            // 
            this.prioritylevelDataGridViewTextBoxColumn.DataPropertyName = "Priority_level";
            this.prioritylevelDataGridViewTextBoxColumn.HeaderText = "Priority_level";
            this.prioritylevelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prioritylevelDataGridViewTextBoxColumn.Name = "prioritylevelDataGridViewTextBoxColumn";
            this.prioritylevelDataGridViewTextBoxColumn.Width = 150;
            // 
            // approvalSignaturesDataGridViewTextBoxColumn
            // 
            this.approvalSignaturesDataGridViewTextBoxColumn.DataPropertyName = "Approval_Signatures";
            this.approvalSignaturesDataGridViewTextBoxColumn.HeaderText = "Approval_Signatures";
            this.approvalSignaturesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.approvalSignaturesDataGridViewTextBoxColumn.Name = "approvalSignaturesDataGridViewTextBoxColumn";
            this.approvalSignaturesDataGridViewTextBoxColumn.Width = 150;
            // 
            // specicalInstructionsDataGridViewTextBoxColumn
            // 
            this.specicalInstructionsDataGridViewTextBoxColumn.DataPropertyName = "Specical_Instructions";
            this.specicalInstructionsDataGridViewTextBoxColumn.HeaderText = "Specical_Instructions";
            this.specicalInstructionsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.specicalInstructionsDataGridViewTextBoxColumn.Name = "specicalInstructionsDataGridViewTextBoxColumn";
            this.specicalInstructionsDataGridViewTextBoxColumn.Width = 150;
            // 
            // departmentIdDataGridViewTextBoxColumn
            // 
            this.departmentIdDataGridViewTextBoxColumn.DataPropertyName = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.HeaderText = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.departmentIdDataGridViewTextBoxColumn.Name = "departmentIdDataGridViewTextBoxColumn";
            this.departmentIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // supplierIdDataGridViewTextBoxColumn
            // 
            this.supplierIdDataGridViewTextBoxColumn.DataPropertyName = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn.HeaderText = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.supplierIdDataGridViewTextBoxColumn.Name = "supplierIdDataGridViewTextBoxColumn";
            this.supplierIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialRequirementFormBindingSource
            // 
            this.materialRequirementFormBindingSource.DataMember = "Material_Requirement_Form";
            this.materialRequirementFormBindingSource.DataSource = this.database1DataSet1;
            // 
            // material_Requirement_FormTableAdapter
            // 
            this.material_Requirement_FormTableAdapter.ClearBeforeFill = true;
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(1748, 818);
            this.btnadd.Margin = new System.Windows.Forms.Padding(4);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(162, 56);
            this.btnadd.TabIndex = 177;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // tbQty
            // 
            this.tbQty.Location = new System.Drawing.Point(1192, 762);
            this.tbQty.Margin = new System.Windows.Forms.Padding(6);
            this.tbQty.Name = "tbQty";
            this.tbQty.Size = new System.Drawing.Size(220, 29);
            this.tbQty.TabIndex = 176;
            this.tbQty.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tbFormNo
            // 
            this.tbFormNo.Location = new System.Drawing.Point(1192, 560);
            this.tbFormNo.Margin = new System.Windows.Forms.Padding(6);
            this.tbFormNo.Name = "tbFormNo";
            this.tbFormNo.Size = new System.Drawing.Size(220, 29);
            this.tbFormNo.TabIndex = 168;
            this.tbFormNo.TextChanged += new System.EventHandler(this.bookIDTextBox_TextChanged);
            // 
            // tbDateIssued
            // 
            this.tbDateIssued.Location = new System.Drawing.Point(1192, 612);
            this.tbDateIssued.Margin = new System.Windows.Forms.Padding(6);
            this.tbDateIssued.Name = "tbDateIssued";
            this.tbDateIssued.Size = new System.Drawing.Size(220, 29);
            this.tbDateIssued.TabIndex = 170;
            this.tbDateIssued.TextChanged += new System.EventHandler(this.titleTextBox_TextChanged);
            // 
            // tbMaterialDesc
            // 
            this.tbMaterialDesc.Location = new System.Drawing.Point(1192, 657);
            this.tbMaterialDesc.Margin = new System.Windows.Forms.Padding(6);
            this.tbMaterialDesc.Name = "tbMaterialDesc";
            this.tbMaterialDesc.Size = new System.Drawing.Size(220, 29);
            this.tbMaterialDesc.TabIndex = 172;
            this.tbMaterialDesc.TextChanged += new System.EventHandler(this.authorTextBox_TextChanged);
            // 
            // tbMaterialSpec
            // 
            this.tbMaterialSpec.Location = new System.Drawing.Point(1192, 706);
            this.tbMaterialSpec.Margin = new System.Windows.Forms.Padding(6);
            this.tbMaterialSpec.Name = "tbMaterialSpec";
            this.tbMaterialSpec.Size = new System.Drawing.Size(220, 29);
            this.tbMaterialSpec.TabIndex = 174;
            this.tbMaterialSpec.TextChanged += new System.EventHandler(this.publisherTextBox_TextChanged);
            // 
            // tbDeptID
            // 
            this.tbDeptID.Location = new System.Drawing.Point(1674, 718);
            this.tbDeptID.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeptID.Name = "tbDeptID";
            this.tbDeptID.Size = new System.Drawing.Size(220, 29);
            this.tbDeptID.TabIndex = 187;
            this.tbDeptID.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // tbPriority
            // 
            this.tbPriority.Location = new System.Drawing.Point(1192, 813);
            this.tbPriority.Margin = new System.Windows.Forms.Padding(6);
            this.tbPriority.Name = "tbPriority";
            this.tbPriority.Size = new System.Drawing.Size(220, 29);
            this.tbPriority.TabIndex = 179;
            this.tbPriority.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // tbDeliveryDate
            // 
            this.tbDeliveryDate.Location = new System.Drawing.Point(1674, 560);
            this.tbDeliveryDate.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeliveryDate.Name = "tbDeliveryDate";
            this.tbDeliveryDate.Size = new System.Drawing.Size(220, 29);
            this.tbDeliveryDate.TabIndex = 181;
            this.tbDeliveryDate.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // tbApprovalSign
            // 
            this.tbApprovalSign.Location = new System.Drawing.Point(1674, 614);
            this.tbApprovalSign.Margin = new System.Windows.Forms.Padding(6);
            this.tbApprovalSign.Name = "tbApprovalSign";
            this.tbApprovalSign.Size = new System.Drawing.Size(220, 29);
            this.tbApprovalSign.TabIndex = 183;
            this.tbApprovalSign.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // tbSpecialInto
            // 
            this.tbSpecialInto.Location = new System.Drawing.Point(1674, 663);
            this.tbSpecialInto.Margin = new System.Windows.Forms.Padding(6);
            this.tbSpecialInto.Name = "tbSpecialInto";
            this.tbSpecialInto.Size = new System.Drawing.Size(220, 29);
            this.tbSpecialInto.TabIndex = 185;
            this.tbSpecialInto.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // tbSupplierID
            // 
            this.tbSupplierID.Location = new System.Drawing.Point(1674, 771);
            this.tbSupplierID.Margin = new System.Windows.Forms.Padding(6);
            this.tbSupplierID.Name = "tbSupplierID";
            this.tbSupplierID.Size = new System.Drawing.Size(220, 29);
            this.tbSupplierID.TabIndex = 189;
            this.tbSupplierID.TextChanged += new System.EventHandler(this.textBox8_TextChanged);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(2055, 831);
            this.textBox9.Margin = new System.Windows.Forms.Padding(6);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(220, 29);
            this.textBox9.TabIndex = 191;
            this.textBox9.TextChanged += new System.EventHandler(this.textBox9_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(2288, 818);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 56);
            this.button1.TabIndex = 192;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // tbSupplyName
            // 
            this.tbSupplyName.Location = new System.Drawing.Point(566, 856);
            this.tbSupplyName.Margin = new System.Windows.Forms.Padding(6);
            this.tbSupplyName.Name = "tbSupplyName";
            this.tbSupplyName.Size = new System.Drawing.Size(220, 29);
            this.tbSupplyName.TabIndex = 194;
            this.tbSupplyName.TextChanged += new System.EventHandler(this.textBox10_TextChanged);
            // 
            // tbSupplyID
            // 
            this.tbSupplyID.Location = new System.Drawing.Point(566, 909);
            this.tbSupplyID.Margin = new System.Windows.Forms.Padding(6);
            this.tbSupplyID.Name = "tbSupplyID";
            this.tbSupplyID.Size = new System.Drawing.Size(220, 29);
            this.tbSupplyID.TabIndex = 196;
            this.tbSupplyID.TextChanged += new System.EventHandler(this.textBox11_TextChanged);
            // 
            // btnSupplyAdd
            // 
            this.btnSupplyAdd.Location = new System.Drawing.Point(798, 897);
            this.btnSupplyAdd.Margin = new System.Windows.Forms.Padding(4);
            this.btnSupplyAdd.Name = "btnSupplyAdd";
            this.btnSupplyAdd.Size = new System.Drawing.Size(162, 56);
            this.btnSupplyAdd.TabIndex = 200;
            this.btnSupplyAdd.Text = "Add";
            this.btnSupplyAdd.UseVisualStyleBackColor = true;
            this.btnSupplyAdd.Click += new System.EventHandler(this.button3_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(1293, 897);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 56);
            this.btnDelete.TabIndex = 199;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.button2_Click);
            // 
            // tbSupplyID2
            // 
            this.tbSupplyID2.Location = new System.Drawing.Point(1060, 910);
            this.tbSupplyID2.Margin = new System.Windows.Forms.Padding(6);
            this.tbSupplyID2.Name = "tbSupplyID2";
            this.tbSupplyID2.Size = new System.Drawing.Size(220, 29);
            this.tbSupplyID2.TabIndex = 198;
            this.tbSupplyID2.TextChanged += new System.EventHandler(this.textBox12_TextChanged);
            // 
            // Companies2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(this.btnSupplyAdd);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(label25);
            this.Controls.Add(this.tbSupplyID2);
            this.Controls.Add(lblSupplyName);
            this.Controls.Add(this.tbSupplyName);
            this.Controls.Add(lblSupplyID);
            this.Controls.Add(this.tbSupplyID);
            this.Controls.Add(this.button1);
            this.Controls.Add(label22);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(lblSupplierID);
            this.Controls.Add(this.tbSupplierID);
            this.Controls.Add(lblDeptID);
            this.Controls.Add(this.tbDeptID);
            this.Controls.Add(lblPriority);
            this.Controls.Add(this.tbPriority);
            this.Controls.Add(lblDeliveryDate);
            this.Controls.Add(this.tbDeliveryDate);
            this.Controls.Add(lblApprovalSign);
            this.Controls.Add(this.tbApprovalSign);
            this.Controls.Add(lblSpecialInto);
            this.Controls.Add(this.tbSpecialInto);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(lblQty);
            this.Controls.Add(this.tbQty);
            this.Controls.Add(lblFormNo);
            this.Controls.Add(this.tbFormNo);
            this.Controls.Add(lblDateIssued);
            this.Controls.Add(this.tbDateIssued);
            this.Controls.Add(lblMaterialDesc);
            this.Controls.Add(this.tbMaterialDesc);
            this.Controls.Add(lblMaterialSpec);
            this.Controls.Add(this.tbMaterialSpec);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(this.lblSettings);
            this.Controls.Add(this.lblActivities);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoice);
            this.Controls.Add(this.lblReports);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.lblCompanies);
            this.Controls.Add(this.lblLeads);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblLeadsDashboard);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.tbSearchHere);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lbEmployee);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.tbSearch);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Companies2";
            this.Text = "Companies2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Companies2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Label lblActivities;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label lblCompanies;
        private System.Windows.Forms.Label lblLeads;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblLeadsDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbSearchHere;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.ListBox lbEmployee;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.TextBox tbSearch;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource materialRequirementFormBindingSource;
        private Database1DataSet1TableAdapters.Material_Requirement_FormTableAdapter material_Requirement_FormTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn formNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateIssuedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialSpecificationsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prioritylevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryDataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn approvalSignaturesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn specicalInstructionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private Database1DataSet1TableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.TextBox tbQty;
        private System.Windows.Forms.TextBox tbFormNo;
        private System.Windows.Forms.TextBox tbDateIssued;
        private System.Windows.Forms.TextBox tbMaterialDesc;
        private System.Windows.Forms.TextBox tbMaterialSpec;
        private System.Windows.Forms.TextBox tbDeptID;
        private System.Windows.Forms.TextBox tbPriority;
        private System.Windows.Forms.TextBox tbDeliveryDate;
        private System.Windows.Forms.TextBox tbApprovalSign;
        private System.Windows.Forms.TextBox tbSpecialInto;
        private System.Windows.Forms.TextBox tbSupplierID;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox tbSupplyName;
        private System.Windows.Forms.TextBox tbSupplyID;
        private System.Windows.Forms.Button btnSupplyAdd;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.TextBox tbSupplyID2;
    }
}