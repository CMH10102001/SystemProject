﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblSettings = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.lblCompanies = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblTasks = new System.Windows.Forms.Label();
            this.lblLeadsDashboard = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button1 = new System.Windows.Forms.Button();
            this.Tasks = new System.Windows.Forms.GroupBox();
            this.lblNoOfTask = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label13 = new System.Windows.Forms.Label();
            this.monthCalendar1 = new System.Windows.Forms.MonthCalendar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblName = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.phoneNum = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.UserEmail = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblEmployee = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.groupBox1.SuspendLayout();
            this.Tasks.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Location = new System.Drawing.Point(33, 903);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(63, 18);
            this.lblSettings.TabIndex = 142;
            this.lblSettings.Text = "Settings";
            this.lblSettings.Click += new System.EventHandler(this.lblSettings_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(33, 836);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 18);
            this.label10.TabIndex = 141;
            this.label10.Text = "Activities";
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(33, 765);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 140;
            this.lblEmail.Text = "Email";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.Location = new System.Drawing.Point(33, 698);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(66, 18);
            this.lblInvoice.TabIndex = 139;
            this.lblInvoice.Text = "Invoices";
            this.lblInvoice.Click += new System.EventHandler(this.lblInvoice_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(33, 633);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(61, 18);
            this.lblReports.TabIndex = 138;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(30, 561);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 137;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(30, 500);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 136;
            this.lblDeals.Text = "Deals";
            this.lblDeals.Click += new System.EventHandler(this.lblDeals_Click);
            // 
            // lblCompanies
            // 
            this.lblCompanies.AutoSize = true;
            this.lblCompanies.Location = new System.Drawing.Point(33, 388);
            this.lblCompanies.Name = "lblCompanies";
            this.lblCompanies.Size = new System.Drawing.Size(84, 18);
            this.lblCompanies.TabIndex = 135;
            this.lblCompanies.Text = "Companies";
            this.lblCompanies.Click += new System.EventHandler(this.lblCompanies_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(30, 334);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(49, 18);
            this.label3.TabIndex = 134;
            this.label3.Text = "Leads";
            this.label3.Click += new System.EventHandler(this.lblLeads_Click);
            // 
            // lblTasks
            // 
            this.lblTasks.AutoSize = true;
            this.lblTasks.Location = new System.Drawing.Point(33, 280);
            this.lblTasks.Name = "lblTasks";
            this.lblTasks.Size = new System.Drawing.Size(48, 18);
            this.lblTasks.TabIndex = 133;
            this.lblTasks.Text = "Tasks";
            this.lblTasks.Click += new System.EventHandler(this.lblTasks_Click);
            // 
            // lblLeadsDashboard
            // 
            this.lblLeadsDashboard.AutoSize = true;
            this.lblLeadsDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold);
            this.lblLeadsDashboard.Location = new System.Drawing.Point(30, 226);
            this.lblLeadsDashboard.Name = "lblLeadsDashboard";
            this.lblLeadsDashboard.Size = new System.Drawing.Size(157, 20);
            this.lblLeadsDashboard.TabIndex = 132;
            this.lblLeadsDashboard.Text = "Leads Dashboard";
            this.lblLeadsDashboard.Click += new System.EventHandler(this.lblLeadDashboard_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox2.Location = new System.Drawing.Point(12, 12);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(282, 196);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 131;
            this.pictureBox2.TabStop = false;
            this.pictureBox2.Click += new System.EventHandler(this.pictureBox2_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.Location = new System.Drawing.Point(46, 69);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(300, 138);
            this.groupBox1.TabIndex = 143;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Email";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(164, 90);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(112, 32);
            this.button1.TabIndex = 0;
            this.button1.Text = "-->";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // Tasks
            // 
            this.Tasks.Controls.Add(this.lblNoOfTask);
            this.Tasks.Controls.Add(this.button2);
            this.Tasks.Location = new System.Drawing.Point(46, 286);
            this.Tasks.Margin = new System.Windows.Forms.Padding(4);
            this.Tasks.Name = "Tasks";
            this.Tasks.Padding = new System.Windows.Forms.Padding(4);
            this.Tasks.Size = new System.Drawing.Size(300, 138);
            this.Tasks.TabIndex = 144;
            this.Tasks.TabStop = false;
            this.Tasks.Text = "Tasks";
            // 
            // lblNoOfTask
            // 
            this.lblNoOfTask.AutoSize = true;
            this.lblNoOfTask.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblNoOfTask.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblNoOfTask.Location = new System.Drawing.Point(7, 35);
            this.lblNoOfTask.Name = "lblNoOfTask";
            this.lblNoOfTask.Size = new System.Drawing.Size(82, 20);
            this.lblNoOfTask.TabIndex = 2;
            this.lblNoOfTask.Text = "No of task";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(164, 98);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(112, 32);
            this.button2.TabIndex = 1;
            this.button2.Text = "-->";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(348, 92);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 18);
            this.label13.TabIndex = 145;
            this.label13.Text = "Leads Dashboard";
            // 
            // monthCalendar1
            // 
            this.monthCalendar1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.monthCalendar1.Location = new System.Drawing.Point(904, 69);
            this.monthCalendar1.Margin = new System.Windows.Forms.Padding(14, 12, 14, 12);
            this.monthCalendar1.Name = "monthCalendar1";
            this.monthCalendar1.TabIndex = 146;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.groupBox1);
            this.panel1.Controls.Add(this.monthCalendar1);
            this.panel1.Controls.Add(this.Tasks);
            this.panel1.Location = new System.Drawing.Point(352, 339);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1304, 466);
            this.panel1.TabIndex = 148;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(1563, 46);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(54, 18);
            this.lblName.TabIndex = 149;
            this.lblName.Text = "Admin";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label15);
            this.panel2.Controls.Add(this.phoneNum);
            this.panel2.Controls.Add(this.label17);
            this.panel2.Controls.Add(this.label16);
            this.panel2.Controls.Add(this.UserEmail);
            this.panel2.Controls.Add(this.label14);
            this.panel2.Location = new System.Drawing.Point(352, 140);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1304, 158);
            this.panel2.TabIndex = 150;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(43, 20);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(54, 18);
            this.label15.TabIndex = 150;
            this.label15.Text = "Admin";
            // 
            // phoneNum
            // 
            this.phoneNum.AutoSize = true;
            this.phoneNum.Location = new System.Drawing.Point(435, 106);
            this.phoneNum.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.phoneNum.Name = "phoneNum";
            this.phoneNum.Size = new System.Drawing.Size(119, 18);
            this.phoneNum.TabIndex = 4;
            this.phoneNum.Text = "Phone Number :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(915, 20);
            this.label17.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 18);
            this.label17.TabIndex = 3;
            this.label17.Text = "Time : ";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(915, 106);
            this.label16.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(139, 18);
            this.label16.TabIndex = 2;
            this.label16.Text = "Current Weather : ";
            // 
            // UserEmail
            // 
            this.UserEmail.AutoSize = true;
            this.UserEmail.Location = new System.Drawing.Point(435, 20);
            this.UserEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.UserEmail.Name = "UserEmail";
            this.UserEmail.Size = new System.Drawing.Size(64, 18);
            this.UserEmail.TabIndex = 1;
            this.UserEmail.Text = "Email : ";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(42, 106);
            this.label14.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(60, 18);
            this.label14.TabIndex = 0;
            this.label14.Text = "Status :";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(352, 15);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(278, 29);
            this.textBox1.TabIndex = 151;
            this.textBox1.Text = "Search here";
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(32, 444);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 157;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // Home
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1716, 1050);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.lblSettings);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoice);
            this.Controls.Add(this.lblReports);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.lblCompanies);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblTasks);
            this.Controls.Add(this.lblLeadsDashboard);
            this.Controls.Add(this.pictureBox2);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Home";
            this.Text = "Leads Dashboard";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Home_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.Tasks.ResumeLayout(false);
            this.Tasks.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label lblCompanies;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblTasks;
        private System.Windows.Forms.Label lblLeadsDashboard;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox Tasks;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.MonthCalendar monthCalendar1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label phoneNum;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label UserEmail;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.Label lblNoOfTask;
    }
}