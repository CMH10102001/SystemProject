﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Companies1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblSetting = new System.Windows.Forms.Label();
            this.lblActivites = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.lblLeads = new System.Windows.Forms.Label();
            this.lblTasks = new System.Windows.Forms.Label();
            this.lblLeadDashboard = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.TBSearch = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.lblEmployee = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.formNumberDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateIssuedDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialSpecificationsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.prioritylevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.approvalSignaturesDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.specicalInstructionsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.supplierIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.materialRequirementFormBindingSource2 = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lbl1 = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.supplierBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.supplierTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.SupplierTableAdapter();
            this.materialRequirementFormBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.material_Requirement_FormTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.Material_Requirement_FormTableAdapter();
            this.materialRequirementFormBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblSetting
            // 
            this.lblSetting.AutoSize = true;
            this.lblSetting.Location = new System.Drawing.Point(16, 908);
            this.lblSetting.Name = "lblSetting";
            this.lblSetting.Size = new System.Drawing.Size(63, 18);
            this.lblSetting.TabIndex = 147;
            this.lblSetting.Text = "Settings";
            this.lblSetting.Click += new System.EventHandler(this.lblSetting_Click);
            // 
            // lblActivites
            // 
            this.lblActivites.AutoSize = true;
            this.lblActivites.Location = new System.Drawing.Point(16, 838);
            this.lblActivites.Name = "lblActivites";
            this.lblActivites.Size = new System.Drawing.Size(76, 18);
            this.lblActivites.TabIndex = 146;
            this.lblActivites.Text = "Activities";
            this.lblActivites.Click += new System.EventHandler(this.lblActivites_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(16, 768);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 145;
            this.lblEmail.Text = "Email";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.Location = new System.Drawing.Point(16, 700);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(66, 18);
            this.lblInvoice.TabIndex = 144;
            this.lblInvoice.Text = "Invoices";
            this.lblInvoice.Click += new System.EventHandler(this.lblInvoice_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(16, 638);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(61, 18);
            this.lblReports.TabIndex = 143;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(14, 566);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 142;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(12, 513);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 141;
            this.lblDeals.Text = "Deals";
            this.lblDeals.Click += new System.EventHandler(this.lblDeals_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label4.Location = new System.Drawing.Point(12, 404);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(93, 18);
            this.label4.TabIndex = 140;
            this.label4.Text = "Companies";
            // 
            // lblLeads
            // 
            this.lblLeads.AutoSize = true;
            this.lblLeads.Location = new System.Drawing.Point(14, 345);
            this.lblLeads.Name = "lblLeads";
            this.lblLeads.Size = new System.Drawing.Size(49, 18);
            this.lblLeads.TabIndex = 139;
            this.lblLeads.Text = "Leads";
            this.lblLeads.Click += new System.EventHandler(this.lblLeads_Click);
            // 
            // lblTasks
            // 
            this.lblTasks.AutoSize = true;
            this.lblTasks.Location = new System.Drawing.Point(16, 290);
            this.lblTasks.Name = "lblTasks";
            this.lblTasks.Size = new System.Drawing.Size(48, 18);
            this.lblTasks.TabIndex = 138;
            this.lblTasks.Text = "Tasks";
            this.lblTasks.Click += new System.EventHandler(this.lblTasks_Click);
            // 
            // lblLeadDashboard
            // 
            this.lblLeadDashboard.AutoSize = true;
            this.lblLeadDashboard.Location = new System.Drawing.Point(14, 236);
            this.lblLeadDashboard.Name = "lblLeadDashboard";
            this.lblLeadDashboard.Size = new System.Drawing.Size(127, 18);
            this.lblLeadDashboard.TabIndex = 137;
            this.lblLeadDashboard.Text = "Leads Dashboard";
            this.lblLeadDashboard.Click += new System.EventHandler(this.lblLeadDashboard_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(321, 118);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(76, 18);
            this.label14.TabIndex = 133;
            this.label14.Text = "All Leads";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(321, 69);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(84, 18);
            this.label13.TabIndex = 132;
            this.label13.Text = "Companies";
            // 
            // TBSearch
            // 
            this.TBSearch.Location = new System.Drawing.Point(324, 21);
            this.TBSearch.Name = "TBSearch";
            this.TBSearch.Size = new System.Drawing.Size(278, 29);
            this.TBSearch.TabIndex = 131;
            this.TBSearch.Text = "Search here";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(419, 118);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(97, 18);
            this.label16.TabIndex = 157;
            this.label16.Text = "Supplier List";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(2702, 36);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 160;
            this.label12.Text = "Admin";
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(14, 462);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 162;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.formNumberDataGridViewTextBoxColumn,
            this.dateIssuedDataGridViewTextBoxColumn,
            this.materialDescriptionDataGridViewTextBoxColumn,
            this.materialSpecificationsDataGridViewTextBoxColumn,
            this.qtyDataGridViewTextBoxColumn,
            this.prioritylevelDataGridViewTextBoxColumn,
            this.approvalSignaturesDataGridViewTextBoxColumn,
            this.specicalInstructionsDataGridViewTextBoxColumn,
            this.departmentIdDataGridViewTextBoxColumn,
            this.supplierIdDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.materialRequirementFormBindingSource2;
            this.dataGridView1.Location = new System.Drawing.Point(147, 236);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 31;
            this.dataGridView1.Size = new System.Drawing.Size(2610, 460);
            this.dataGridView1.TabIndex = 163;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick_1);
            // 
            // formNumberDataGridViewTextBoxColumn
            // 
            this.formNumberDataGridViewTextBoxColumn.DataPropertyName = "Form_Number";
            this.formNumberDataGridViewTextBoxColumn.HeaderText = "Form_Number";
            this.formNumberDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.formNumberDataGridViewTextBoxColumn.Name = "formNumberDataGridViewTextBoxColumn";
            this.formNumberDataGridViewTextBoxColumn.Width = 150;
            // 
            // dateIssuedDataGridViewTextBoxColumn
            // 
            this.dateIssuedDataGridViewTextBoxColumn.DataPropertyName = "Date_Issued";
            this.dateIssuedDataGridViewTextBoxColumn.HeaderText = "Date_Issued";
            this.dateIssuedDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.dateIssuedDataGridViewTextBoxColumn.Name = "dateIssuedDataGridViewTextBoxColumn";
            this.dateIssuedDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialDescriptionDataGridViewTextBoxColumn
            // 
            this.materialDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Material_Description";
            this.materialDescriptionDataGridViewTextBoxColumn.HeaderText = "Material_Description";
            this.materialDescriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.materialDescriptionDataGridViewTextBoxColumn.Name = "materialDescriptionDataGridViewTextBoxColumn";
            this.materialDescriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialSpecificationsDataGridViewTextBoxColumn
            // 
            this.materialSpecificationsDataGridViewTextBoxColumn.DataPropertyName = "Material_Specifications";
            this.materialSpecificationsDataGridViewTextBoxColumn.HeaderText = "Material_Specifications";
            this.materialSpecificationsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.materialSpecificationsDataGridViewTextBoxColumn.Name = "materialSpecificationsDataGridViewTextBoxColumn";
            this.materialSpecificationsDataGridViewTextBoxColumn.Width = 150;
            // 
            // qtyDataGridViewTextBoxColumn
            // 
            this.qtyDataGridViewTextBoxColumn.DataPropertyName = "Qty";
            this.qtyDataGridViewTextBoxColumn.HeaderText = "Qty";
            this.qtyDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.qtyDataGridViewTextBoxColumn.Name = "qtyDataGridViewTextBoxColumn";
            this.qtyDataGridViewTextBoxColumn.Width = 150;
            // 
            // prioritylevelDataGridViewTextBoxColumn
            // 
            this.prioritylevelDataGridViewTextBoxColumn.DataPropertyName = "Priority_level";
            this.prioritylevelDataGridViewTextBoxColumn.HeaderText = "Priority_level";
            this.prioritylevelDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.prioritylevelDataGridViewTextBoxColumn.Name = "prioritylevelDataGridViewTextBoxColumn";
            this.prioritylevelDataGridViewTextBoxColumn.Width = 150;
            // 
            // approvalSignaturesDataGridViewTextBoxColumn
            // 
            this.approvalSignaturesDataGridViewTextBoxColumn.DataPropertyName = "Approval_Signatures";
            this.approvalSignaturesDataGridViewTextBoxColumn.HeaderText = "Approval_Signatures";
            this.approvalSignaturesDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.approvalSignaturesDataGridViewTextBoxColumn.Name = "approvalSignaturesDataGridViewTextBoxColumn";
            this.approvalSignaturesDataGridViewTextBoxColumn.Width = 150;
            // 
            // specicalInstructionsDataGridViewTextBoxColumn
            // 
            this.specicalInstructionsDataGridViewTextBoxColumn.DataPropertyName = "Specical_Instructions";
            this.specicalInstructionsDataGridViewTextBoxColumn.HeaderText = "Specical_Instructions";
            this.specicalInstructionsDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.specicalInstructionsDataGridViewTextBoxColumn.Name = "specicalInstructionsDataGridViewTextBoxColumn";
            this.specicalInstructionsDataGridViewTextBoxColumn.Width = 150;
            // 
            // departmentIdDataGridViewTextBoxColumn
            // 
            this.departmentIdDataGridViewTextBoxColumn.DataPropertyName = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.HeaderText = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.departmentIdDataGridViewTextBoxColumn.Name = "departmentIdDataGridViewTextBoxColumn";
            this.departmentIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // supplierIdDataGridViewTextBoxColumn
            // 
            this.supplierIdDataGridViewTextBoxColumn.DataPropertyName = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn.HeaderText = "Supplier_Id";
            this.supplierIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.supplierIdDataGridViewTextBoxColumn.Name = "supplierIdDataGridViewTextBoxColumn";
            this.supplierIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // materialRequirementFormBindingSource2
            // 
            this.materialRequirementFormBindingSource2.DataMember = "Material_Requirement_Form";
            this.materialRequirementFormBindingSource2.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(866, 878);
            this.btnLast.Margin = new System.Windows.Forms.Padding(6);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(168, 48);
            this.btnLast.TabIndex = 170;
            this.btnLast.Text = "&Last";
            this.btnLast.UseVisualStyleBackColor = true;
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(686, 878);
            this.btnFirst.Margin = new System.Windows.Forms.Padding(6);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(168, 48);
            this.btnFirst.TabIndex = 169;
            this.btnFirst.Text = "&First";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(1395, 896);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(75, 28);
            this.btnNext.TabIndex = 168;
            this.btnNext.Text = ">>";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(1646, 861);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(252, 64);
            this.btnAdd.TabIndex = 167;
            this.btnAdd.Text = "Modify the Employee";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(378, 906);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(161, 18);
            this.lbl1.TabIndex = 166;
            this.lbl1.Text = "Showing the staff of 1";
            this.lbl1.Click += new System.EventHandler(this.lbl1_Click);
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(1352, 898);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(16, 18);
            this.lblText.TabIndex = 165;
            this.lblText.Text = "1";
            this.lblText.Click += new System.EventHandler(this.lblText_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(1256, 896);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(75, 28);
            this.btnPrevious.TabIndex = 164;
            this.btnPrevious.Text = "<<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // supplierBindingSource
            // 
            this.supplierBindingSource.DataMember = "Supplier";
            this.supplierBindingSource.DataSource = this.database1DataSet1;
            // 
            // supplierTableAdapter
            // 
            this.supplierTableAdapter.ClearBeforeFill = true;
            // 
            // materialRequirementFormBindingSource
            // 
            this.materialRequirementFormBindingSource.DataMember = "Material_Requirement_Form";
            this.materialRequirementFormBindingSource.DataSource = this.database1DataSet1;
            // 
            // material_Requirement_FormTableAdapter
            // 
            this.material_Requirement_FormTableAdapter.ClearBeforeFill = true;
            // 
            // materialRequirementFormBindingSource1
            // 
            this.materialRequirementFormBindingSource1.DataMember = "Material_Requirement_Form";
            this.materialRequirementFormBindingSource1.DataSource = this.database1DataSet1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(2, -3);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 236);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 136;
            this.pictureBox1.TabStop = false;
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.Location = new System.Drawing.Point(1823, 57);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(50, 18);
            this.lblName.TabIndex = 171;
            this.lblName.Text = "label1";
            this.lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // Companies1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 952);
            this.Controls.Add(this.lblName);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.lblSetting);
            this.Controls.Add(this.lblActivites);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoice);
            this.Controls.Add(this.lblReports);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.lblLeads);
            this.Controls.Add(this.lblTasks);
            this.Controls.Add(this.lblLeadDashboard);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.TBSearch);
            this.MaximumSize = new System.Drawing.Size(10000, 100000);
            this.Name = "Companies1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Companies1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Companies_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.supplierBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.materialRequirementFormBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblSetting;
        private System.Windows.Forms.Label lblActivites;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblLeads;
        private System.Windows.Forms.Label lblTasks;
        private System.Windows.Forms.Label lblLeadDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox TBSearch;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label12;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource supplierBindingSource;
        private Database1DataSet1TableAdapters.SupplierTableAdapter supplierTableAdapter;
        private System.Windows.Forms.BindingSource materialRequirementFormBindingSource;
        private Database1DataSet1TableAdapters.Material_Requirement_FormTableAdapter material_Requirement_FormTableAdapter;
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.BindingSource materialRequirementFormBindingSource1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn formNumberDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateIssuedDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialDescriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn materialSpecificationsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn prioritylevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn deliveryDataDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn approvalSignaturesDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn specicalInstructionsDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn supplierIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource materialRequirementFormBindingSource2;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Label lblName;
    }
}