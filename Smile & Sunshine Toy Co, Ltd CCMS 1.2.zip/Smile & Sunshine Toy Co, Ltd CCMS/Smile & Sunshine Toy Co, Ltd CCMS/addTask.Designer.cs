﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class addTask
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblPassword;
            System.Windows.Forms.Label lblName;
            System.Windows.Forms.Label lblJob;
            System.Windows.Forms.Label authorLabel;
            System.Windows.Forms.Label publisherLabel;
            this.TBStatus = new System.Windows.Forms.TextBox();
            this.TBTaskName = new System.Windows.Forms.TextBox();
            this.TBUser = new System.Windows.Forms.TextBox();
            this.TBDueDate = new System.Windows.Forms.TextBox();
            this.TBTaskOwner = new System.Windows.Forms.TextBox();
            this.BtnAdd = new System.Windows.Forms.Button();
            lblPassword = new System.Windows.Forms.Label();
            lblName = new System.Windows.Forms.Label();
            lblJob = new System.Windows.Forms.Label();
            authorLabel = new System.Windows.Forms.Label();
            publisherLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new System.Drawing.Point(50, 276);
            lblPassword.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new System.Drawing.Size(50, 18);
            lblPassword.TabIndex = 133;
            lblPassword.Text = "Status";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new System.Drawing.Point(50, 63);
            lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(87, 18);
            lblName.TabIndex = 125;
            lblName.Text = "Task Name";
            lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // lblJob
            // 
            lblJob.AutoSize = true;
            lblJob.Location = new System.Drawing.Point(50, 116);
            lblJob.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblJob.Name = "lblJob";
            lblJob.Size = new System.Drawing.Size(41, 18);
            lblJob.TabIndex = 127;
            lblJob.Text = "User";
            // 
            // authorLabel
            // 
            authorLabel.AutoSize = true;
            authorLabel.Location = new System.Drawing.Point(50, 171);
            authorLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            authorLabel.Name = "authorLabel";
            authorLabel.Size = new System.Drawing.Size(74, 18);
            authorLabel.TabIndex = 129;
            authorLabel.Text = "Due Date";
            // 
            // publisherLabel
            // 
            publisherLabel.AutoSize = true;
            publisherLabel.Location = new System.Drawing.Point(50, 220);
            publisherLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            publisherLabel.Name = "publisherLabel";
            publisherLabel.Size = new System.Drawing.Size(92, 18);
            publisherLabel.TabIndex = 131;
            publisherLabel.Text = "Task Owner";
            // 
            // TBStatus
            // 
            this.TBStatus.Location = new System.Drawing.Point(290, 270);
            this.TBStatus.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBStatus.Name = "TBStatus";
            this.TBStatus.Size = new System.Drawing.Size(220, 29);
            this.TBStatus.TabIndex = 134;
            this.TBStatus.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // TBTaskName
            // 
            this.TBTaskName.Location = new System.Drawing.Point(290, 58);
            this.TBTaskName.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBTaskName.Name = "TBTaskName";
            this.TBTaskName.Size = new System.Drawing.Size(220, 29);
            this.TBTaskName.TabIndex = 126;
            this.TBTaskName.TextChanged += new System.EventHandler(this.bookIDTextBox_TextChanged);
            // 
            // TBUser
            // 
            this.TBUser.Location = new System.Drawing.Point(290, 111);
            this.TBUser.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBUser.Name = "TBUser";
            this.TBUser.Size = new System.Drawing.Size(220, 29);
            this.TBUser.TabIndex = 128;
            this.TBUser.TextChanged += new System.EventHandler(this.titleTextBox_TextChanged);
            // 
            // TBDueDate
            // 
            this.TBDueDate.Location = new System.Drawing.Point(290, 165);
            this.TBDueDate.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBDueDate.Name = "TBDueDate";
            this.TBDueDate.Size = new System.Drawing.Size(220, 29);
            this.TBDueDate.TabIndex = 130;
            this.TBDueDate.TextChanged += new System.EventHandler(this.authorTextBox_TextChanged);
            // 
            // TBTaskOwner
            // 
            this.TBTaskOwner.Location = new System.Drawing.Point(290, 214);
            this.TBTaskOwner.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBTaskOwner.Name = "TBTaskOwner";
            this.TBTaskOwner.Size = new System.Drawing.Size(220, 29);
            this.TBTaskOwner.TabIndex = 132;
            this.TBTaskOwner.TextChanged += new System.EventHandler(this.publisherTextBox_TextChanged);
            // 
            // BtnAdd
            // 
            this.BtnAdd.Location = new System.Drawing.Point(778, 498);
            this.BtnAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.BtnAdd.Name = "BtnAdd";
            this.BtnAdd.Size = new System.Drawing.Size(150, 39);
            this.BtnAdd.TabIndex = 135;
            this.BtnAdd.Text = "Add";
            this.BtnAdd.UseVisualStyleBackColor = true;
            this.BtnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // addTask
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 675);
            this.Controls.Add(this.BtnAdd);
            this.Controls.Add(lblPassword);
            this.Controls.Add(this.TBStatus);
            this.Controls.Add(lblName);
            this.Controls.Add(this.TBTaskName);
            this.Controls.Add(lblJob);
            this.Controls.Add(this.TBUser);
            this.Controls.Add(authorLabel);
            this.Controls.Add(this.TBDueDate);
            this.Controls.Add(publisherLabel);
            this.Controls.Add(this.TBTaskOwner);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "addTask";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox TBStatus;
        private System.Windows.Forms.TextBox TBTaskName;
        private System.Windows.Forms.TextBox TBUser;
        private System.Windows.Forms.TextBox TBDueDate;
        private System.Windows.Forms.TextBox TBTaskOwner;
        private System.Windows.Forms.Button BtnAdd;
    }
}