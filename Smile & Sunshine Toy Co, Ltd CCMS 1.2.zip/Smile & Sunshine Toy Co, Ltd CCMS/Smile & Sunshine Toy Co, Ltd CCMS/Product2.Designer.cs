﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Product2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label ProductCost;
            System.Windows.Forms.Label lblProductDesc;
            System.Windows.Forms.Label pID;
            System.Windows.Forms.Label pName;
            System.Windows.Forms.Label column;
            System.Windows.Forms.Label DeptID;
            this.label12 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.lblSetting = new System.Windows.Forms.Label();
            this.lblActivities = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoice = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.lblCompanies = new System.Windows.Forms.Label();
            this.lblLeads = new System.Windows.Forms.Label();
            this.lblTasks = new System.Windows.Forms.Label();
            this.lblLeadsDashboard = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.productBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.tbPID = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.productTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.ProductTableAdapter();
            this.tbProductCost = new System.Windows.Forms.TextBox();
            this.tbProductDesc = new System.Windows.Forms.TextBox();
            this.tbProductID = new System.Windows.Forms.TextBox();
            this.tbProductName = new System.Windows.Forms.TextBox();
            this.tbColumn = new System.Windows.Forms.TextBox();
            this.tbDeptID = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblEmployee = new System.Windows.Forms.Label();
            this.productIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.columnDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Department_Id = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productCostDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.productDescriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            label14 = new System.Windows.Forms.Label();
            ProductCost = new System.Windows.Forms.Label();
            lblProductDesc = new System.Windows.Forms.Label();
            pID = new System.Windows.Forms.Label();
            pName = new System.Windows.Forms.Label();
            column = new System.Windows.Forms.Label();
            DeptID = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(1050, 900);
            label14.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(83, 18);
            label14.TabIndex = 112;
            label14.Text = "Product ID";
            label14.Click += new System.EventHandler(this.label14_Click);
            // 
            // ProductCost
            // 
            ProductCost.AutoSize = true;
            ProductCost.Location = new System.Drawing.Point(333, 346);
            ProductCost.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            ProductCost.Name = "ProductCost";
            ProductCost.Size = new System.Drawing.Size(99, 18);
            ProductCost.TabIndex = 121;
            ProductCost.Text = "Product_Cost";
            // 
            // lblProductDesc
            // 
            lblProductDesc.AutoSize = true;
            lblProductDesc.Location = new System.Drawing.Point(333, 400);
            lblProductDesc.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblProductDesc.Name = "lblProductDesc";
            lblProductDesc.Size = new System.Drawing.Size(148, 18);
            lblProductDesc.TabIndex = 123;
            lblProductDesc.Text = "Product_Description";
            // 
            // pID
            // 
            pID.AutoSize = true;
            pID.Location = new System.Drawing.Point(333, 134);
            pID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            pID.Name = "pID";
            pID.Size = new System.Drawing.Size(82, 18);
            pID.TabIndex = 113;
            pID.Text = "Product_Id";
            // 
            // pName
            // 
            pName.AutoSize = true;
            pName.Location = new System.Drawing.Point(333, 186);
            pName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            pName.Name = "pName";
            pName.Size = new System.Drawing.Size(109, 18);
            pName.TabIndex = 115;
            pName.Text = "Product_Name";
            // 
            // column
            // 
            column.AutoSize = true;
            column.Location = new System.Drawing.Point(333, 242);
            column.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            column.Name = "column";
            column.Size = new System.Drawing.Size(66, 18);
            column.TabIndex = 117;
            column.Text = "Column:";
            // 
            // DeptID
            // 
            DeptID.AutoSize = true;
            DeptID.Location = new System.Drawing.Point(333, 291);
            DeptID.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            DeptID.Name = "DeptID";
            DeptID.Size = new System.Drawing.Size(111, 18);
            DeptID.TabIndex = 119;
            DeptID.Text = "Depertment_Id";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1518, 14);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 31;
            this.label12.Text = "Admin";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(316, 16);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(278, 29);
            this.textBox1.TabIndex = 30;
            this.textBox1.Text = "Search here";
            // 
            // lblSetting
            // 
            this.lblSetting.AutoSize = true;
            this.lblSetting.Location = new System.Drawing.Point(28, 900);
            this.lblSetting.Name = "lblSetting";
            this.lblSetting.Size = new System.Drawing.Size(63, 18);
            this.lblSetting.TabIndex = 65;
            this.lblSetting.Text = "Settings";
            this.lblSetting.Click += new System.EventHandler(this.lblSetting_Click);
            // 
            // lblActivities
            // 
            this.lblActivities.AutoSize = true;
            this.lblActivities.Location = new System.Drawing.Point(28, 831);
            this.lblActivities.Name = "lblActivities";
            this.lblActivities.Size = new System.Drawing.Size(76, 18);
            this.lblActivities.TabIndex = 64;
            this.lblActivities.Text = "Activities";
            this.lblActivities.Click += new System.EventHandler(this.lblActivities_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(28, 762);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 63;
            this.lblEmail.Text = "Email";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblInvoice
            // 
            this.lblInvoice.AutoSize = true;
            this.lblInvoice.Location = new System.Drawing.Point(28, 699);
            this.lblInvoice.Name = "lblInvoice";
            this.lblInvoice.Size = new System.Drawing.Size(66, 18);
            this.lblInvoice.TabIndex = 62;
            this.lblInvoice.Text = "Invoices";
            this.lblInvoice.Click += new System.EventHandler(this.lblInvoice_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(28, 630);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(61, 18);
            this.lblReports.TabIndex = 61;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(26, 558);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 60;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(26, 496);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 59;
            this.lblDeals.Text = "Deals";
            this.lblDeals.Click += new System.EventHandler(this.lblDeals_Click);
            // 
            // lblCompanies
            // 
            this.lblCompanies.AutoSize = true;
            this.lblCompanies.Location = new System.Drawing.Point(28, 399);
            this.lblCompanies.Name = "lblCompanies";
            this.lblCompanies.Size = new System.Drawing.Size(84, 18);
            this.lblCompanies.TabIndex = 58;
            this.lblCompanies.Text = "Companies";
            this.lblCompanies.Click += new System.EventHandler(this.lblCompanies_Click);
            // 
            // lblLeads
            // 
            this.lblLeads.AutoSize = true;
            this.lblLeads.Location = new System.Drawing.Point(26, 345);
            this.lblLeads.Name = "lblLeads";
            this.lblLeads.Size = new System.Drawing.Size(49, 18);
            this.lblLeads.TabIndex = 57;
            this.lblLeads.Text = "Leads";
            this.lblLeads.Click += new System.EventHandler(this.lblLeads_Click);
            // 
            // lblTasks
            // 
            this.lblTasks.AutoSize = true;
            this.lblTasks.Location = new System.Drawing.Point(28, 290);
            this.lblTasks.Name = "lblTasks";
            this.lblTasks.Size = new System.Drawing.Size(48, 18);
            this.lblTasks.TabIndex = 56;
            this.lblTasks.Text = "Tasks";
            this.lblTasks.Click += new System.EventHandler(this.lblTasks_Click);
            // 
            // lblLeadsDashboard
            // 
            this.lblLeadsDashboard.AutoSize = true;
            this.lblLeadsDashboard.Location = new System.Drawing.Point(26, 236);
            this.lblLeadsDashboard.Name = "lblLeadsDashboard";
            this.lblLeadsDashboard.Size = new System.Drawing.Size(127, 18);
            this.lblLeadsDashboard.TabIndex = 55;
            this.lblLeadsDashboard.Text = "Leads Dashboard";
            this.lblLeadsDashboard.Click += new System.EventHandler(this.lblLeadsDashboard_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.productIdDataGridViewTextBoxColumn,
            this.productNameDataGridViewTextBoxColumn,
            this.columnDataGridViewTextBoxColumn,
            this.Department_Id,
            this.productCostDataGridViewTextBoxColumn,
            this.productDescriptionDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.productBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(316, 448);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 24;
            this.dataGridView1.Size = new System.Drawing.Size(1439, 300);
            this.dataGridView1.TabIndex = 77;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // productBindingSource
            // 
            this.productBindingSource.DataMember = "Product";
            this.productBindingSource.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tbPID
            // 
            this.tbPID.Location = new System.Drawing.Point(1146, 886);
            this.tbPID.Margin = new System.Windows.Forms.Padding(6);
            this.tbPID.Name = "tbPID";
            this.tbPID.Size = new System.Drawing.Size(220, 29);
            this.tbPID.TabIndex = 111;
            this.tbPID.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(1378, 873);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 56);
            this.btnDelete.TabIndex = 110;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(1558, 873);
            this.btnadd.Margin = new System.Windows.Forms.Padding(4);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(162, 56);
            this.btnadd.TabIndex = 109;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // productTableAdapter
            // 
            this.productTableAdapter.ClearBeforeFill = true;
            // 
            // tbProductCost
            // 
            this.tbProductCost.Location = new System.Drawing.Point(573, 340);
            this.tbProductCost.Margin = new System.Windows.Forms.Padding(6);
            this.tbProductCost.Name = "tbProductCost";
            this.tbProductCost.Size = new System.Drawing.Size(220, 29);
            this.tbProductCost.TabIndex = 122;
            this.tbProductCost.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tbProductDesc
            // 
            this.tbProductDesc.Location = new System.Drawing.Point(573, 394);
            this.tbProductDesc.Margin = new System.Windows.Forms.Padding(6);
            this.tbProductDesc.Name = "tbProductDesc";
            this.tbProductDesc.Size = new System.Drawing.Size(220, 29);
            this.tbProductDesc.TabIndex = 124;
            this.tbProductDesc.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // tbProductID
            // 
            this.tbProductID.Location = new System.Drawing.Point(573, 129);
            this.tbProductID.Margin = new System.Windows.Forms.Padding(6);
            this.tbProductID.Name = "tbProductID";
            this.tbProductID.Size = new System.Drawing.Size(220, 29);
            this.tbProductID.TabIndex = 114;
            this.tbProductID.TextChanged += new System.EventHandler(this.bookIDTextBox_TextChanged);
            // 
            // tbProductName
            // 
            this.tbProductName.Location = new System.Drawing.Point(573, 182);
            this.tbProductName.Margin = new System.Windows.Forms.Padding(6);
            this.tbProductName.Name = "tbProductName";
            this.tbProductName.Size = new System.Drawing.Size(220, 29);
            this.tbProductName.TabIndex = 116;
            this.tbProductName.TextChanged += new System.EventHandler(this.titleTextBox_TextChanged);
            // 
            // tbColumn
            // 
            this.tbColumn.Location = new System.Drawing.Point(573, 236);
            this.tbColumn.Margin = new System.Windows.Forms.Padding(6);
            this.tbColumn.Name = "tbColumn";
            this.tbColumn.Size = new System.Drawing.Size(220, 29);
            this.tbColumn.TabIndex = 118;
            this.tbColumn.TextChanged += new System.EventHandler(this.authorTextBox_TextChanged);
            // 
            // tbDeptID
            // 
            this.tbDeptID.Location = new System.Drawing.Point(573, 285);
            this.tbDeptID.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeptID.Name = "tbDeptID";
            this.tbDeptID.Size = new System.Drawing.Size(220, 29);
            this.tbDeptID.TabIndex = 120;
            this.tbDeptID.TextChanged += new System.EventHandler(this.publisherTextBox_TextChanged);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(-1, 6);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 198);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 54;
            this.pictureBox1.TabStop = false;
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(28, 448);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 125;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // productIdDataGridViewTextBoxColumn
            // 
            this.productIdDataGridViewTextBoxColumn.DataPropertyName = "Product_Id";
            this.productIdDataGridViewTextBoxColumn.HeaderText = "Product_Id";
            this.productIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productIdDataGridViewTextBoxColumn.Name = "productIdDataGridViewTextBoxColumn";
            this.productIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // productNameDataGridViewTextBoxColumn
            // 
            this.productNameDataGridViewTextBoxColumn.DataPropertyName = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.HeaderText = "Product_Name";
            this.productNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productNameDataGridViewTextBoxColumn.Name = "productNameDataGridViewTextBoxColumn";
            this.productNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // columnDataGridViewTextBoxColumn
            // 
            this.columnDataGridViewTextBoxColumn.DataPropertyName = "Column";
            this.columnDataGridViewTextBoxColumn.HeaderText = "Column";
            this.columnDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.columnDataGridViewTextBoxColumn.Name = "columnDataGridViewTextBoxColumn";
            this.columnDataGridViewTextBoxColumn.Width = 150;
            // 
            // Department_Id
            // 
            this.Department_Id.DataPropertyName = "Department_Id";
            this.Department_Id.HeaderText = "Department_Id";
            this.Department_Id.MinimumWidth = 8;
            this.Department_Id.Name = "Department_Id";
            this.Department_Id.Width = 150;
            // 
            // productCostDataGridViewTextBoxColumn
            // 
            this.productCostDataGridViewTextBoxColumn.DataPropertyName = "Product_Cost";
            this.productCostDataGridViewTextBoxColumn.HeaderText = "Product_Cost";
            this.productCostDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productCostDataGridViewTextBoxColumn.Name = "productCostDataGridViewTextBoxColumn";
            this.productCostDataGridViewTextBoxColumn.Width = 150;
            // 
            // productDescriptionDataGridViewTextBoxColumn
            // 
            this.productDescriptionDataGridViewTextBoxColumn.DataPropertyName = "Product_Description";
            this.productDescriptionDataGridViewTextBoxColumn.HeaderText = "Product_Description";
            this.productDescriptionDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.productDescriptionDataGridViewTextBoxColumn.Name = "productDescriptionDataGridViewTextBoxColumn";
            this.productDescriptionDataGridViewTextBoxColumn.Width = 150;
            // 
            // Product2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1768, 938);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(ProductCost);
            this.Controls.Add(this.tbProductCost);
            this.Controls.Add(lblProductDesc);
            this.Controls.Add(this.tbProductDesc);
            this.Controls.Add(pID);
            this.Controls.Add(this.tbProductID);
            this.Controls.Add(pName);
            this.Controls.Add(this.tbProductName);
            this.Controls.Add(column);
            this.Controls.Add(this.tbColumn);
            this.Controls.Add(DeptID);
            this.Controls.Add(this.tbDeptID);
            this.Controls.Add(label14);
            this.Controls.Add(this.tbPID);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.lblSetting);
            this.Controls.Add(this.lblActivities);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoice);
            this.Controls.Add(this.lblReports);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.lblCompanies);
            this.Controls.Add(this.lblLeads);
            this.Controls.Add(this.lblTasks);
            this.Controls.Add(this.lblLeadsDashboard);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.textBox1);
            this.Name = "Product2";
            this.Text = "Product modify";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form3_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.productBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label lblSetting;
        private System.Windows.Forms.Label lblActivities;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoice;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label lblCompanies;
        private System.Windows.Forms.Label lblLeads;
        private System.Windows.Forms.Label lblTasks;
        private System.Windows.Forms.Label lblLeadsDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox tbPID;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnadd;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource productBindingSource;
        private Database1DataSet1TableAdapters.ProductTableAdapter productTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmnetIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.TextBox tbProductCost;
        private System.Windows.Forms.TextBox tbProductDesc;
        private System.Windows.Forms.TextBox tbProductID;
        private System.Windows.Forms.TextBox tbProductName;
        private System.Windows.Forms.TextBox tbColumn;
        private System.Windows.Forms.TextBox tbDeptID;
        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.DataGridViewTextBoxColumn productIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn columnDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Department_Id;
        private System.Windows.Forms.DataGridViewTextBoxColumn productCostDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn productDescriptionDataGridViewTextBoxColumn;
    }
}