﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class addLead
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.Label lblPassword;
            System.Windows.Forms.Label lblName;
            System.Windows.Forms.Label lblJob;
            System.Windows.Forms.Label authorLabel;
            System.Windows.Forms.Label publisherLabel;
            System.Windows.Forms.Label label1;
            System.Windows.Forms.Label label2;
            this.btnAdd = new System.Windows.Forms.Button();
            this.TBEmail = new System.Windows.Forms.TextBox();
            this.TBFullName = new System.Windows.Forms.TextBox();
            this.TBTitle = new System.Windows.Forms.TextBox();
            this.TBCompany = new System.Windows.Forms.TextBox();
            this.TBPhone = new System.Windows.Forms.TextBox();
            this.TBLeadStatus = new System.Windows.Forms.TextBox();
            this.TBLeadOwner = new System.Windows.Forms.TextBox();
            lblPassword = new System.Windows.Forms.Label();
            lblName = new System.Windows.Forms.Label();
            lblJob = new System.Windows.Forms.Label();
            authorLabel = new System.Windows.Forms.Label();
            publisherLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new System.Drawing.Point(160, 316);
            lblPassword.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new System.Drawing.Size(49, 18);
            lblPassword.TabIndex = 144;
            lblPassword.Text = "Email";
            lblPassword.Click += new System.EventHandler(this.lblPassword_Click);
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new System.Drawing.Point(160, 104);
            lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(81, 18);
            lblName.TabIndex = 136;
            lblName.Text = "Full Name";
            lblName.Click += new System.EventHandler(this.lblName_Click);
            // 
            // lblJob
            // 
            lblJob.AutoSize = true;
            lblJob.Location = new System.Drawing.Point(160, 156);
            lblJob.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblJob.Name = "lblJob";
            lblJob.Size = new System.Drawing.Size(41, 18);
            lblJob.TabIndex = 138;
            lblJob.Text = "Title";
            lblJob.Click += new System.EventHandler(this.lblJob_Click);
            // 
            // authorLabel
            // 
            authorLabel.AutoSize = true;
            authorLabel.Location = new System.Drawing.Point(160, 212);
            authorLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            authorLabel.Name = "authorLabel";
            authorLabel.Size = new System.Drawing.Size(72, 18);
            authorLabel.TabIndex = 140;
            authorLabel.Text = "Company";
            authorLabel.Click += new System.EventHandler(this.authorLabel_Click);
            // 
            // publisherLabel
            // 
            publisherLabel.AutoSize = true;
            publisherLabel.Location = new System.Drawing.Point(160, 261);
            publisherLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            publisherLabel.Name = "publisherLabel";
            publisherLabel.Size = new System.Drawing.Size(49, 18);
            publisherLabel.TabIndex = 142;
            publisherLabel.Text = "Phone";
            publisherLabel.Click += new System.EventHandler(this.publisherLabel_Click);
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(160, 372);
            label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(89, 18);
            label1.TabIndex = 147;
            label1.Text = "Lead Status";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new System.Drawing.Point(154, 429);
            label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label2.Name = "label2";
            label2.Size = new System.Drawing.Size(93, 18);
            label2.TabIndex = 148;
            label2.Text = "Lead Owner";
            // 
            // btnAdd
            // 
            this.btnAdd.Location = new System.Drawing.Point(890, 538);
            this.btnAdd.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(150, 39);
            this.btnAdd.TabIndex = 146;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // TBEmail
            // 
            this.TBEmail.Location = new System.Drawing.Point(400, 310);
            this.TBEmail.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBEmail.Name = "TBEmail";
            this.TBEmail.Size = new System.Drawing.Size(220, 29);
            this.TBEmail.TabIndex = 145;
            this.TBEmail.Text = "Email";
            this.TBEmail.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // TBFullName
            // 
            this.TBFullName.Location = new System.Drawing.Point(400, 99);
            this.TBFullName.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBFullName.Name = "TBFullName";
            this.TBFullName.Size = new System.Drawing.Size(220, 29);
            this.TBFullName.TabIndex = 137;
            this.TBFullName.Text = "Full Name";
            this.TBFullName.TextChanged += new System.EventHandler(this.bookIDTextBox_TextChanged);
            // 
            // TBTitle
            // 
            this.TBTitle.Location = new System.Drawing.Point(400, 152);
            this.TBTitle.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBTitle.Name = "TBTitle";
            this.TBTitle.Size = new System.Drawing.Size(220, 29);
            this.TBTitle.TabIndex = 139;
            this.TBTitle.Text = "Title";
            this.TBTitle.TextChanged += new System.EventHandler(this.titleTextBox_TextChanged);
            // 
            // TBCompany
            // 
            this.TBCompany.Location = new System.Drawing.Point(400, 206);
            this.TBCompany.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBCompany.Name = "TBCompany";
            this.TBCompany.Size = new System.Drawing.Size(220, 29);
            this.TBCompany.TabIndex = 141;
            this.TBCompany.Text = "Company";
            this.TBCompany.TextChanged += new System.EventHandler(this.authorTextBox_TextChanged);
            // 
            // TBPhone
            // 
            this.TBPhone.Location = new System.Drawing.Point(400, 255);
            this.TBPhone.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBPhone.Name = "TBPhone";
            this.TBPhone.Size = new System.Drawing.Size(220, 29);
            this.TBPhone.TabIndex = 143;
            this.TBPhone.Text = "Phone";
            this.TBPhone.TextChanged += new System.EventHandler(this.publisherTextBox_TextChanged);
            // 
            // TBLeadStatus
            // 
            this.TBLeadStatus.Location = new System.Drawing.Point(400, 357);
            this.TBLeadStatus.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBLeadStatus.Name = "TBLeadStatus";
            this.TBLeadStatus.Size = new System.Drawing.Size(220, 29);
            this.TBLeadStatus.TabIndex = 149;
            this.TBLeadStatus.Text = "Lead Status";
            this.TBLeadStatus.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // TBLeadOwner
            // 
            this.TBLeadOwner.Location = new System.Drawing.Point(400, 414);
            this.TBLeadOwner.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.TBLeadOwner.Name = "TBLeadOwner";
            this.TBLeadOwner.Size = new System.Drawing.Size(220, 29);
            this.TBLeadOwner.TabIndex = 150;
            this.TBLeadOwner.Text = "Lead Owner";
            this.TBLeadOwner.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // addLead
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 675);
            this.Controls.Add(this.TBLeadOwner);
            this.Controls.Add(this.TBLeadStatus);
            this.Controls.Add(label2);
            this.Controls.Add(label1);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(lblPassword);
            this.Controls.Add(this.TBEmail);
            this.Controls.Add(lblName);
            this.Controls.Add(this.TBFullName);
            this.Controls.Add(lblJob);
            this.Controls.Add(this.TBTitle);
            this.Controls.Add(authorLabel);
            this.Controls.Add(this.TBCompany);
            this.Controls.Add(publisherLabel);
            this.Controls.Add(this.TBPhone);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "addLead";
            this.Text = "addLead";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.TextBox TBEmail;
        private System.Windows.Forms.TextBox TBFullName;
        private System.Windows.Forms.TextBox TBTitle;
        private System.Windows.Forms.TextBox TBCompany;
        private System.Windows.Forms.TextBox TBPhone;
        private System.Windows.Forms.TextBox TBLeadStatus;
        private System.Windows.Forms.TextBox TBLeadOwner;
    }
}