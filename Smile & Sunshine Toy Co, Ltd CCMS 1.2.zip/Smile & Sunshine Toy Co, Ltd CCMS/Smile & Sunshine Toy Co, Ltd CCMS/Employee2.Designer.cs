﻿namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    partial class Employee2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label lblPassword;
            System.Windows.Forms.Label lblName;
            System.Windows.Forms.Label lblJob;
            System.Windows.Forms.Label authorLabel;
            System.Windows.Forms.Label publisherLabel;
            System.Windows.Forms.Label label14;
            System.Windows.Forms.Label label13;
            System.Windows.Forms.Label label15;
            System.Windows.Forms.Label label16;
            System.Windows.Forms.Label label17;
            System.Windows.Forms.Label label19;
            this.lblEmployee = new System.Windows.Forms.Label();
            this.tbWork = new System.Windows.Forms.TextBox();
            this.tbStaff_ID = new System.Windows.Forms.TextBox();
            this.tbPwd = new System.Windows.Forms.TextBox();
            this.tbDeptID = new System.Windows.Forms.TextBox();
            this.tbPosition = new System.Windows.Forms.TextBox();
            this.tbStaffID = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.staffBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.database1DataSet1 = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1();
            this.lblSettings = new System.Windows.Forms.Label();
            this.lblActivities = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblInvoices = new System.Windows.Forms.Label();
            this.lblReports = new System.Windows.Forms.Label();
            this.lblProduct = new System.Windows.Forms.Label();
            this.lblDeals = new System.Windows.Forms.Label();
            this.lblCompanies = new System.Windows.Forms.Label();
            this.lblLeads = new System.Windows.Forms.Label();
            this.lblTasks = new System.Windows.Forms.Label();
            this.lblLeadDashboard = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label12 = new System.Windows.Forms.Label();
            this.tbSearch = new System.Windows.Forms.TextBox();
            this.staffTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.StaffTableAdapter();
            this.departmentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.departmentTableAdapter = new Smile___Sunshine_Toy_Co__Ltd_CCMS.Database1DataSet1TableAdapters.DepartmentTableAdapter();
            this.departmentNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentIdDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.tbDeptName = new System.Windows.Forms.TextBox();
            this.tbDeptID2 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.btnadd = new System.Windows.Forms.Button();
            this.btnAdd2 = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.staffIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.passwordDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.departmentIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.positionIdDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.workDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.salaryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.staffBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.tbSal = new System.Windows.Forms.TextBox();
            lblPassword = new System.Windows.Forms.Label();
            lblName = new System.Windows.Forms.Label();
            lblJob = new System.Windows.Forms.Label();
            authorLabel = new System.Windows.Forms.Label();
            publisherLabel = new System.Windows.Forms.Label();
            label14 = new System.Windows.Forms.Label();
            label13 = new System.Windows.Forms.Label();
            label15 = new System.Windows.Forms.Label();
            label16 = new System.Windows.Forms.Label();
            label17 = new System.Windows.Forms.Label();
            label19 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblPassword
            // 
            lblPassword.AutoSize = true;
            lblPassword.Location = new System.Drawing.Point(356, 368);
            lblPassword.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblPassword.Name = "lblPassword";
            lblPassword.Size = new System.Drawing.Size(46, 18);
            lblPassword.TabIndex = 152;
            lblPassword.Text = "Work";
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new System.Drawing.Point(356, 155);
            lblName.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblName.Name = "lblName";
            lblName.Size = new System.Drawing.Size(64, 18);
            lblName.TabIndex = 144;
            lblName.Text = "Staff_Id";
            // 
            // lblJob
            // 
            lblJob.AutoSize = true;
            lblJob.Location = new System.Drawing.Point(356, 208);
            lblJob.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            lblJob.Name = "lblJob";
            lblJob.Size = new System.Drawing.Size(73, 18);
            lblJob.TabIndex = 146;
            lblJob.Text = "Password";
            // 
            // authorLabel
            // 
            authorLabel.AutoSize = true;
            authorLabel.Location = new System.Drawing.Point(356, 263);
            authorLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            authorLabel.Name = "authorLabel";
            authorLabel.Size = new System.Drawing.Size(111, 18);
            authorLabel.TabIndex = 148;
            authorLabel.Text = "Department_Id";
            // 
            // publisherLabel
            // 
            publisherLabel.AutoSize = true;
            publisherLabel.Location = new System.Drawing.Point(356, 312);
            publisherLabel.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            publisherLabel.Name = "publisherLabel";
            publisherLabel.Size = new System.Drawing.Size(85, 18);
            publisherLabel.TabIndex = 150;
            publisherLabel.Text = "Position_Id";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new System.Drawing.Point(903, 910);
            label14.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label14.Name = "label14";
            label14.Size = new System.Drawing.Size(65, 18);
            label14.TabIndex = 143;
            label14.Text = "Staff ID";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new System.Drawing.Point(992, 362);
            label13.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label13.Name = "label13";
            label13.Size = new System.Drawing.Size(138, 18);
            label13.TabIndex = 160;
            label13.Text = "Department_Name";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new System.Drawing.Point(992, 306);
            label15.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label15.Name = "label15";
            label15.Size = new System.Drawing.Size(111, 18);
            label15.TabIndex = 158;
            label15.Text = "Depertment_Id";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new System.Drawing.Point(1424, 507);
            label16.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label16.Name = "label16";
            label16.Size = new System.Drawing.Size(111, 18);
            label16.TabIndex = 164;
            label16.Text = "Department_Id";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new System.Drawing.Point(354, 110);
            label17.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label17.Name = "label17";
            label17.Size = new System.Drawing.Size(108, 18);
            label17.TabIndex = 165;
            label17.Text = "Employee List";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new System.Drawing.Point(356, 426);
            label19.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            label19.Name = "label19";
            label19.Size = new System.Drawing.Size(52, 18);
            label19.TabIndex = 169;
            label19.Text = "Salary";
            // 
            // lblEmployee
            // 
            this.lblEmployee.AutoSize = true;
            this.lblEmployee.Font = new System.Drawing.Font("新細明體", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.lblEmployee.ForeColor = System.Drawing.SystemColors.InfoText;
            this.lblEmployee.Location = new System.Drawing.Point(27, 447);
            this.lblEmployee.Name = "lblEmployee";
            this.lblEmployee.Size = new System.Drawing.Size(76, 18);
            this.lblEmployee.TabIndex = 156;
            this.lblEmployee.Text = "Employee";
            this.lblEmployee.Click += new System.EventHandler(this.lblEmployee_Click);
            // 
            // tbWork
            // 
            this.tbWork.Location = new System.Drawing.Point(596, 362);
            this.tbWork.Margin = new System.Windows.Forms.Padding(6);
            this.tbWork.Name = "tbWork";
            this.tbWork.Size = new System.Drawing.Size(220, 29);
            this.tbWork.TabIndex = 153;
            this.tbWork.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // tbStaff_ID
            // 
            this.tbStaff_ID.Location = new System.Drawing.Point(596, 150);
            this.tbStaff_ID.Margin = new System.Windows.Forms.Padding(6);
            this.tbStaff_ID.Name = "tbStaff_ID";
            this.tbStaff_ID.Size = new System.Drawing.Size(220, 29);
            this.tbStaff_ID.TabIndex = 145;
            this.tbStaff_ID.TextChanged += new System.EventHandler(this.bookIDTextBox_TextChanged);
            // 
            // tbPwd
            // 
            this.tbPwd.Location = new System.Drawing.Point(596, 203);
            this.tbPwd.Margin = new System.Windows.Forms.Padding(6);
            this.tbPwd.Name = "tbPwd";
            this.tbPwd.Size = new System.Drawing.Size(220, 29);
            this.tbPwd.TabIndex = 147;
            this.tbPwd.TextChanged += new System.EventHandler(this.titleTextBox_TextChanged);
            // 
            // tbDeptID
            // 
            this.tbDeptID.Location = new System.Drawing.Point(596, 257);
            this.tbDeptID.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeptID.Name = "tbDeptID";
            this.tbDeptID.Size = new System.Drawing.Size(220, 29);
            this.tbDeptID.TabIndex = 149;
            this.tbDeptID.TextChanged += new System.EventHandler(this.authorTextBox_TextChanged);
            // 
            // tbPosition
            // 
            this.tbPosition.Location = new System.Drawing.Point(596, 306);
            this.tbPosition.Margin = new System.Windows.Forms.Padding(6);
            this.tbPosition.Name = "tbPosition";
            this.tbPosition.Size = new System.Drawing.Size(220, 29);
            this.tbPosition.TabIndex = 151;
            this.tbPosition.TextChanged += new System.EventHandler(this.publisherTextBox_TextChanged);
            // 
            // tbStaffID
            // 
            this.tbStaffID.Location = new System.Drawing.Point(999, 896);
            this.tbStaffID.Margin = new System.Windows.Forms.Padding(6);
            this.tbStaffID.Name = "tbStaffID";
            this.tbStaffID.Size = new System.Drawing.Size(220, 29);
            this.tbStaffID.TabIndex = 142;
            this.tbStaffID.TextChanged += new System.EventHandler(this.textBox7_TextChanged);
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(1232, 882);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(136, 56);
            this.btnDelete.TabIndex = 141;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // staffBindingSource
            // 
            this.staffBindingSource.DataMember = "Staff";
            this.staffBindingSource.DataSource = this.database1DataSet1;
            // 
            // database1DataSet1
            // 
            this.database1DataSet1.DataSetName = "Database1DataSet1";
            this.database1DataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.Location = new System.Drawing.Point(30, 910);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Size = new System.Drawing.Size(63, 18);
            this.lblSettings.TabIndex = 139;
            this.lblSettings.Text = "Settings";
            this.lblSettings.Click += new System.EventHandler(this.lblSettings_Click);
            // 
            // lblActivities
            // 
            this.lblActivities.AutoSize = true;
            this.lblActivities.Location = new System.Drawing.Point(30, 842);
            this.lblActivities.Name = "lblActivities";
            this.lblActivities.Size = new System.Drawing.Size(76, 18);
            this.lblActivities.TabIndex = 138;
            this.lblActivities.Text = "Activities";
            this.lblActivities.Click += new System.EventHandler(this.lblActivities_Click);
            // 
            // lblEmail
            // 
            this.lblEmail.AutoSize = true;
            this.lblEmail.Location = new System.Drawing.Point(30, 772);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(49, 18);
            this.lblEmail.TabIndex = 137;
            this.lblEmail.Text = "Email";
            this.lblEmail.Click += new System.EventHandler(this.lblEmail_Click);
            // 
            // lblInvoices
            // 
            this.lblInvoices.AutoSize = true;
            this.lblInvoices.Location = new System.Drawing.Point(30, 705);
            this.lblInvoices.Name = "lblInvoices";
            this.lblInvoices.Size = new System.Drawing.Size(66, 18);
            this.lblInvoices.TabIndex = 136;
            this.lblInvoices.Text = "Invoices";
            this.lblInvoices.Click += new System.EventHandler(this.lblInvoices_Click);
            // 
            // lblReports
            // 
            this.lblReports.AutoSize = true;
            this.lblReports.Location = new System.Drawing.Point(30, 640);
            this.lblReports.Name = "lblReports";
            this.lblReports.Size = new System.Drawing.Size(61, 18);
            this.lblReports.TabIndex = 135;
            this.lblReports.Text = "Reports";
            this.lblReports.Click += new System.EventHandler(this.lblReports_Click);
            // 
            // lblProduct
            // 
            this.lblProduct.AutoSize = true;
            this.lblProduct.Location = new System.Drawing.Point(30, 567);
            this.lblProduct.Name = "lblProduct";
            this.lblProduct.Size = new System.Drawing.Size(60, 18);
            this.lblProduct.TabIndex = 134;
            this.lblProduct.Text = "Product";
            this.lblProduct.Click += new System.EventHandler(this.lblProduct_Click);
            // 
            // lblDeals
            // 
            this.lblDeals.AutoSize = true;
            this.lblDeals.Location = new System.Drawing.Point(30, 507);
            this.lblDeals.Name = "lblDeals";
            this.lblDeals.Size = new System.Drawing.Size(48, 18);
            this.lblDeals.TabIndex = 133;
            this.lblDeals.Text = "Deals";
            this.lblDeals.Click += new System.EventHandler(this.lblDeals_Click);
            // 
            // lblCompanies
            // 
            this.lblCompanies.AutoSize = true;
            this.lblCompanies.Location = new System.Drawing.Point(27, 388);
            this.lblCompanies.Name = "lblCompanies";
            this.lblCompanies.Size = new System.Drawing.Size(84, 18);
            this.lblCompanies.TabIndex = 132;
            this.lblCompanies.Text = "Companies";
            this.lblCompanies.Click += new System.EventHandler(this.lblCompanies_Click);
            // 
            // lblLeads
            // 
            this.lblLeads.AutoSize = true;
            this.lblLeads.Location = new System.Drawing.Point(30, 333);
            this.lblLeads.Name = "lblLeads";
            this.lblLeads.Size = new System.Drawing.Size(49, 18);
            this.lblLeads.TabIndex = 131;
            this.lblLeads.Text = "Leads";
            this.lblLeads.Click += new System.EventHandler(this.lblTasks_Click);
            // 
            // lblTasks
            // 
            this.lblTasks.AutoSize = true;
            this.lblTasks.Location = new System.Drawing.Point(27, 282);
            this.lblTasks.Name = "lblTasks";
            this.lblTasks.Size = new System.Drawing.Size(48, 18);
            this.lblTasks.TabIndex = 130;
            this.lblTasks.Text = "Tasks";
            this.lblTasks.Click += new System.EventHandler(this.lblTasks_Click);
            // 
            // lblLeadDashboard
            // 
            this.lblLeadDashboard.AutoSize = true;
            this.lblLeadDashboard.Location = new System.Drawing.Point(30, 236);
            this.lblLeadDashboard.Name = "lblLeadDashboard";
            this.lblLeadDashboard.Size = new System.Drawing.Size(127, 18);
            this.lblLeadDashboard.TabIndex = 129;
            this.lblLeadDashboard.Text = "Leads Dashboard";
            this.lblLeadDashboard.Click += new System.EventHandler(this.lblLeadDashboard_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Smile___Sunshine_Toy_Co__Ltd_CCMS.Properties.Resources.png1;
            this.pictureBox1.Location = new System.Drawing.Point(-3, -2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(298, 198);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 128;
            this.pictureBox1.TabStop = false;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(1869, 16);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(54, 18);
            this.label12.TabIndex = 127;
            this.label12.Text = "Admin";
            this.label12.Click += new System.EventHandler(this.label12_Click);
            // 
            // tbSearch
            // 
            this.tbSearch.Location = new System.Drawing.Point(357, 46);
            this.tbSearch.Name = "tbSearch";
            this.tbSearch.Size = new System.Drawing.Size(278, 29);
            this.tbSearch.TabIndex = 126;
            this.tbSearch.Text = "Search here";
            // 
            // staffTableAdapter
            // 
            this.staffTableAdapter.ClearBeforeFill = true;
            // 
            // departmentBindingSource
            // 
            this.departmentBindingSource.DataMember = "Department";
            this.departmentBindingSource.DataSource = this.database1DataSet1;
            // 
            // departmentTableAdapter
            // 
            this.departmentTableAdapter.ClearBeforeFill = true;
            // 
            // departmentNameDataGridViewTextBoxColumn
            // 
            this.departmentNameDataGridViewTextBoxColumn.DataPropertyName = "Department_Name";
            this.departmentNameDataGridViewTextBoxColumn.HeaderText = "Department_Name";
            this.departmentNameDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.departmentNameDataGridViewTextBoxColumn.Name = "departmentNameDataGridViewTextBoxColumn";
            this.departmentNameDataGridViewTextBoxColumn.Width = 150;
            // 
            // departmentIdDataGridViewTextBoxColumn1
            // 
            this.departmentIdDataGridViewTextBoxColumn1.DataPropertyName = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn1.HeaderText = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn1.MinimumWidth = 8;
            this.departmentIdDataGridViewTextBoxColumn1.Name = "departmentIdDataGridViewTextBoxColumn1";
            this.departmentIdDataGridViewTextBoxColumn1.Width = 150;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.departmentIdDataGridViewTextBoxColumn1,
            this.departmentNameDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.departmentBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(994, 51);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 62;
            this.dataGridView2.RowTemplate.Height = 24;
            this.dataGridView2.Size = new System.Drawing.Size(832, 225);
            this.dataGridView2.TabIndex = 157;
            this.dataGridView2.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellContentClick);
            // 
            // tbDeptName
            // 
            this.tbDeptName.Location = new System.Drawing.Point(1232, 356);
            this.tbDeptName.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeptName.Name = "tbDeptName";
            this.tbDeptName.Size = new System.Drawing.Size(220, 29);
            this.tbDeptName.TabIndex = 161;
            this.tbDeptName.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // tbDeptID2
            // 
            this.tbDeptID2.Location = new System.Drawing.Point(1232, 300);
            this.tbDeptID2.Margin = new System.Windows.Forms.Padding(6);
            this.tbDeptID2.Name = "tbDeptID2";
            this.tbDeptID2.Size = new System.Drawing.Size(220, 29);
            this.tbDeptID2.TabIndex = 159;
            this.tbDeptID2.TextChanged += new System.EventHandler(this.textBox4_TextChanged);
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(1548, 492);
            this.textBox5.Margin = new System.Windows.Forms.Padding(6);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(220, 29);
            this.textBox5.TabIndex = 163;
            this.textBox5.TextChanged += new System.EventHandler(this.textBox5_TextChanged);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1798, 478);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(136, 56);
            this.button1.TabIndex = 162;
            this.button1.Text = "Delete";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnadd
            // 
            this.btnadd.Location = new System.Drawing.Point(654, 469);
            this.btnadd.Margin = new System.Windows.Forms.Padding(4);
            this.btnadd.Name = "btnadd";
            this.btnadd.Size = new System.Drawing.Size(162, 56);
            this.btnadd.TabIndex = 166;
            this.btnadd.Text = "Add";
            this.btnadd.UseVisualStyleBackColor = true;
            this.btnadd.Click += new System.EventHandler(this.btnadd_Click);
            // 
            // btnAdd2
            // 
            this.btnAdd2.Location = new System.Drawing.Point(1292, 410);
            this.btnAdd2.Margin = new System.Windows.Forms.Padding(4);
            this.btnAdd2.Name = "btnAdd2";
            this.btnAdd2.Size = new System.Drawing.Size(162, 56);
            this.btnAdd2.TabIndex = 167;
            this.btnAdd2.Text = "Add";
            this.btnAdd2.UseVisualStyleBackColor = true;
            this.btnAdd2.Click += new System.EventHandler(this.btnAdd2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.staffIdDataGridViewTextBoxColumn,
            this.passwordDataGridViewTextBoxColumn,
            this.departmentIdDataGridViewTextBoxColumn,
            this.positionIdDataGridViewTextBoxColumn,
            this.workDataGridViewTextBoxColumn,
            this.salaryDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.staffBindingSource1;
            this.dataGridView1.Location = new System.Drawing.Point(357, 542);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 62;
            this.dataGridView1.RowTemplate.Height = 31;
            this.dataGridView1.Size = new System.Drawing.Size(1220, 318);
            this.dataGridView1.TabIndex = 168;
            // 
            // staffIdDataGridViewTextBoxColumn
            // 
            this.staffIdDataGridViewTextBoxColumn.DataPropertyName = "Staff_Id";
            this.staffIdDataGridViewTextBoxColumn.HeaderText = "Staff_Id";
            this.staffIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.staffIdDataGridViewTextBoxColumn.Name = "staffIdDataGridViewTextBoxColumn";
            this.staffIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // passwordDataGridViewTextBoxColumn
            // 
            this.passwordDataGridViewTextBoxColumn.DataPropertyName = "Password";
            this.passwordDataGridViewTextBoxColumn.HeaderText = "Password";
            this.passwordDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.passwordDataGridViewTextBoxColumn.Name = "passwordDataGridViewTextBoxColumn";
            this.passwordDataGridViewTextBoxColumn.Width = 150;
            // 
            // departmentIdDataGridViewTextBoxColumn
            // 
            this.departmentIdDataGridViewTextBoxColumn.DataPropertyName = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.HeaderText = "Department_Id";
            this.departmentIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.departmentIdDataGridViewTextBoxColumn.Name = "departmentIdDataGridViewTextBoxColumn";
            this.departmentIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // positionIdDataGridViewTextBoxColumn
            // 
            this.positionIdDataGridViewTextBoxColumn.DataPropertyName = "Position_Id";
            this.positionIdDataGridViewTextBoxColumn.HeaderText = "Position_Id";
            this.positionIdDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.positionIdDataGridViewTextBoxColumn.Name = "positionIdDataGridViewTextBoxColumn";
            this.positionIdDataGridViewTextBoxColumn.Width = 150;
            // 
            // workDataGridViewTextBoxColumn
            // 
            this.workDataGridViewTextBoxColumn.DataPropertyName = "Work";
            this.workDataGridViewTextBoxColumn.HeaderText = "Work";
            this.workDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.workDataGridViewTextBoxColumn.Name = "workDataGridViewTextBoxColumn";
            this.workDataGridViewTextBoxColumn.Width = 150;
            // 
            // salaryDataGridViewTextBoxColumn
            // 
            this.salaryDataGridViewTextBoxColumn.DataPropertyName = "Salary";
            this.salaryDataGridViewTextBoxColumn.HeaderText = "Salary";
            this.salaryDataGridViewTextBoxColumn.MinimumWidth = 8;
            this.salaryDataGridViewTextBoxColumn.Name = "salaryDataGridViewTextBoxColumn";
            this.salaryDataGridViewTextBoxColumn.Width = 150;
            // 
            // staffBindingSource1
            // 
            this.staffBindingSource1.DataMember = "Staff";
            this.staffBindingSource1.DataSource = this.database1DataSet1;
            // 
            // tbSal
            // 
            this.tbSal.Location = new System.Drawing.Point(596, 420);
            this.tbSal.Margin = new System.Windows.Forms.Padding(6);
            this.tbSal.Name = "tbSal";
            this.tbSal.Size = new System.Drawing.Size(220, 29);
            this.tbSal.TabIndex = 170;
            this.tbSal.TextChanged += new System.EventHandler(this.textBox6_TextChanged);
            // 
            // Employee2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 18F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1050);
            this.Controls.Add(label19);
            this.Controls.Add(this.tbSal);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnAdd2);
            this.Controls.Add(this.btnadd);
            this.Controls.Add(label17);
            this.Controls.Add(label16);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.button1);
            this.Controls.Add(label13);
            this.Controls.Add(this.tbDeptName);
            this.Controls.Add(label15);
            this.Controls.Add(this.tbDeptID2);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.lblEmployee);
            this.Controls.Add(lblPassword);
            this.Controls.Add(this.tbWork);
            this.Controls.Add(lblName);
            this.Controls.Add(this.tbStaff_ID);
            this.Controls.Add(lblJob);
            this.Controls.Add(this.tbPwd);
            this.Controls.Add(authorLabel);
            this.Controls.Add(this.tbDeptID);
            this.Controls.Add(publisherLabel);
            this.Controls.Add(this.tbPosition);
            this.Controls.Add(label14);
            this.Controls.Add(this.tbStaffID);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.lblSettings);
            this.Controls.Add(this.lblActivities);
            this.Controls.Add(this.lblEmail);
            this.Controls.Add(this.lblInvoices);
            this.Controls.Add(this.lblReports);
            this.Controls.Add(this.lblProduct);
            this.Controls.Add(this.lblDeals);
            this.Controls.Add(this.lblCompanies);
            this.Controls.Add(this.lblLeads);
            this.Controls.Add(this.lblTasks);
            this.Controls.Add(this.lblLeadDashboard);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.tbSearch);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Employee2";
            this.Text = "Employee2";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Employee2_Load);
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.database1DataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.departmentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.staffBindingSource1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblEmployee;
        private System.Windows.Forms.TextBox tbWork;
        private System.Windows.Forms.TextBox tbStaff_ID;
        private System.Windows.Forms.TextBox tbPwd;
        private System.Windows.Forms.TextBox tbDeptID;
        private System.Windows.Forms.TextBox tbPosition;
        private System.Windows.Forms.TextBox tbStaffID;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Label lblActivities;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblInvoices;
        private System.Windows.Forms.Label lblReports;
        private System.Windows.Forms.Label lblProduct;
        private System.Windows.Forms.Label lblDeals;
        private System.Windows.Forms.Label lblCompanies;
        private System.Windows.Forms.Label lblLeads;
        private System.Windows.Forms.Label lblTasks;
        private System.Windows.Forms.Label lblLeadDashboard;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox tbSearch;
        private Database1DataSet1 database1DataSet1;
        private System.Windows.Forms.BindingSource staffBindingSource;
        private Database1DataSet1TableAdapters.StaffTableAdapter staffTableAdapter;
        private System.Windows.Forms.BindingSource departmentBindingSource;
        private Database1DataSet1TableAdapters.DepartmentTableAdapter departmentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentIdDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.TextBox tbDeptName;
        private System.Windows.Forms.TextBox tbDeptID2;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnadd;
        private System.Windows.Forms.Button btnAdd2;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn staffIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn passwordDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn departmentIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn positionIdDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn workDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn salaryDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource staffBindingSource1;
        private System.Windows.Forms.TextBox tbSal;
    }
}