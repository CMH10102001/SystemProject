﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.OleDb;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Employee2 : Form
    {

        private DataTable dt = new DataTable();
        private DataTable dt1 = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;"
                        + "Data Source=Database1.accdb";


        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private void UpdateGrid1(string sqlStr)
        {
            OleDbDataAdapter dataAdapter1 = new OleDbDataAdapter(sqlStr, connStr);
            dt1.Clear();
            dataAdapter1.Fill(dt1);
            dataAdapter1.Dispose();
            dataGridView2.DataSource = dt1;
        }

        public Employee2()
        {
            InitializeComponent();
        }

        private void Employee2_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'database1DataSet1.Department' 資料表。您可以視需要進行移動或移除。
            this.departmentTableAdapter.Fill(this.database1DataSet1.Department);
            // TODO: 這行程式碼會將資料載入 'database1DataSet1.Staff' 資料表。您可以視需要進行移動或移除。
            this.staffTableAdapter.Fill(this.database1DataSet1.Staff);

        }

        private void bookIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void authorTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void publisherTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbStaff_ID.Text != "" && tbPwd.Text != "" && tbDeptID.Text != "" && tbPosition.Text != "" && tbSearch.Text != "" && tbWork.Text != "" && tbSal.Text != "")
                {
                    UpdateGrid("Insert into Staff values (\"" + tbStaff_ID.Text + "\",\"" + tbPwd.Text + "\",\"" + tbDeptID.Text + "\",\"" + tbPosition.Text + "\",\"" + tbWork.Text + "\"," + int.Parse(tbSal.Text) + ");");
                    UpdateGrid("Select * from Staff");
                }
                else
                    MessageBox.Show("Please enter all of message");
            }
            catch (Exception E)
            {
                MessageBox.Show("Error enter! ");
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbStaffID.Text == "")
                {
                    MessageBox.Show("Cannot be empty! ");
                }
                else 
                {
                    UpdateGrid("Delete from Staff where Staff_Id = \"" + tbStaffID.Text + "\";");
                    UpdateGrid("Select * from Staff");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Invalid value !");
            }
        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAdd2_Click(object sender, EventArgs e)
        {
            try
            {
                if  (tbDeptID2.Text != "" && tbDeptName.Text != "")
                {
                    UpdateGrid1("Insert into Department values (\"" + tbDeptID2.Text + "\",\"" + tbDeptName.Text + "\");");
                    UpdateGrid1("Select * from Department");
                }
                else
                    MessageBox.Show("Please enter all of message");
            }
            catch (Exception E)
            {
                MessageBox.Show("Error enter! ");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox5.Text == "")
                {
                    MessageBox.Show("Cannot be empty! ");
                }
                else
                {
                    UpdateGrid1("Delete from Department where Department_Id = \"" + textBox5.Text + "\";");
                    UpdateGrid1("Select * from Department");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Invalid value !");
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void lblEmployee_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void lblCompanies_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void lblProduct_Click(object sender, EventArgs e)
        {
           Product1 frm = new Product1();
            frm.ShowDialog();
        }

        private void lblLeadDashboard_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void lblTasks_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            frm.ShowDialog();
        }

        private void lblLeads_Click(object sender, EventArgs e)
        {
            Leads frm = new Leads();
            frm.ShowDialog();
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void label12_Click(object sender, EventArgs e)
        {

        }

        private void lblDeals_Click(object sender, EventArgs e)
        {

        }

        private void lblReports_Click(object sender, EventArgs e)
        {

        }

        private void lblInvoices_Click(object sender, EventArgs e)
        {

        }

        private void lblActivities_Click(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void lblSettings_Click(object sender, EventArgs e)
        {

        }
    }
}
