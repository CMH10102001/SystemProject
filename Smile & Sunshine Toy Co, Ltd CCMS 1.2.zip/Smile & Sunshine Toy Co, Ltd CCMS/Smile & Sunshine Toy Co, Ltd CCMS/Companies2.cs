﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Companies2 : Form
    {

        private void UpdateGrid(string sqlStr)
        {
            OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter.Fill(dt);
            dataAdapter.Dispose();
            dataGridView1.DataSource = dt;
        }

        private void UpdateGrid1(string sqlStr)
        {
            OleDbDataAdapter dataAdapter1 = new OleDbDataAdapter(sqlStr, connStr);
            dt.Clear();
            dataAdapter1.Fill(dt);
            dataAdapter1.Dispose();
            dataGridView2.DataSource = dt;
        }

        private DataTable dt = new DataTable();
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;"
                        + "Data Source=Database1.accdb";

        public Companies2()
        {
            InitializeComponent();
        }

        private void Companies2_Load(object sender, EventArgs e)
        {
            // TODO: 這行程式碼會將資料載入 'database1DataSet1.Supplier' 資料表。您可以視需要進行移動或移除。
            this.supplierTableAdapter.Fill(this.database1DataSet1.Supplier);
            // TODO: 這行程式碼會將資料載入 'database1DataSet1.Material_Requirement_Form' 資料表。您可以視需要進行移動或移除。
            this.material_Requirement_FormTableAdapter.Fill(this.database1DataSet1.Material_Requirement_Form);

            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    lblName.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    lblName.Text = $"錯誤：{ex.Message}";
                }
            }

            string connectionString1 = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query1 = "SELECT Department FROM Data";

            using (OleDbConnection connection1 = new OleDbConnection(connectionString1))
            {
                connection1.Open();
                OleDbCommand command = new OleDbCommand(query1, connection1);
                object result = command.ExecuteScalar();
                string a = result != null ? result.ToString() : string.Empty;
                if (a == "D001" && a != "D002" && a != "D003" && a != "D004" && a != "D006")
                {
                    MessageBox.Show("Not Access");
                    Close();
                }
            }


        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbSupplyID.Text != "" && tbSupplyName.Text != "")
                {
                    UpdateGrid1("Insert into Supplier values (\"" + tbSupplyName.Text + "\",\"" + tbSupplyID.Text + "\");");
                    UpdateGrid1("Select * from Supplier");
                }
                else
                    MessageBox.Show("Please enter all of message");
            }
            catch (Exception E)
            {
                MessageBox.Show("Error enter! ");
            }
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbSupplyID2.Text == "")
                {
                    MessageBox.Show("Cannot be empty! ");
                }
                else
                {
                    UpdateGrid1("Delete from Supplier where Supplier_Id = \"" + tbSupplyID2.Text + "\";");
                    UpdateGrid1("Select * from Supplier");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Invalid value !");
            }
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if (textBox9.Text == "")
                {
                    MessageBox.Show("Cannot be empty! ");
                }
                else
                {
                    UpdateGrid("Delete from Material_Requirement_Form where Form_Number = \"" + textBox9.Text + "\";");
                    UpdateGrid("Select * from  Material_Requirement_Form");
                }
            }
            catch (Exception E)
            {
                MessageBox.Show("Invalid value !");
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void bookIDTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void titleTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void authorTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void publisherTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnadd_Click(object sender, EventArgs e)
        {
            try
            {
                if (tbFormNo.Text != "" && tbDateIssued.Text != "" && tbMaterialDesc.Text != "" && tbMaterialSpec.Text != "" && tbQty.Text != "" && tbPriority.Text != "" && tbApprovalSign.Text != "" && tbSpecialInto.Text != "" && tbDeptID.Text != "" && tbSupplierID.Text != "" && tbDeliveryDate.Text != "")
                {
                    UpdateGrid("Insert into Material_Requirement_Form values (\"" + tbFormNo.Text + "\",\"" + tbDateIssued.Text + "\",\"" + tbMaterialDesc.Text + "\",\"" + tbMaterialSpec.Text + "\"," + int.Parse(tbQty.Text) + "," + int.Parse(tbPriority.Text) + ",\"" + tbDeliveryDate.Text + "\"," + int.Parse(tbApprovalSign.Text) + ",\"" + tbSpecialInto.Text + "\",\"" + tbDeptID.Text + "\",\"" + tbSupplierID.Text + "\");");
                    UpdateGrid("Select * from  Material_Requirement_Form");
                }
                else
                    MessageBox.Show("Please enter all of message");
            }
            catch (Exception E)
            {
                MessageBox.Show("Error enter! ");
            }
        }

        private void authorLabel_Click(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmployee_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();
        }

        private void lblCompanies_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();
        }

        private void lblProduct_Click(object sender, EventArgs e)
        {
            Product1 frm = new Product1();
            frm.ShowDialog();
        }

        private void lblActivities_Click(object sender, EventArgs e)
        {

        }

        private void lblName_Click(object sender, EventArgs e)
        {
            Logout frm = new Logout();
            frm.ShowDialog();
        }

        private void lblLeadsDashboard_Click(object sender, EventArgs e)
        {
           this.Close();
        }

        private void lblLeads_Click(object sender, EventArgs e)
        {
            Leads frm = new Leads();
            frm.ShowDialog();
        }

        private void lblDeals_Click(object sender, EventArgs e)
        {

        }

        private void lblReports_Click(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void lblSettings_Click(object sender, EventArgs e)
        {

        }
    }
}
