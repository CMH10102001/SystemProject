﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1;

namespace Smile___Sunshine_Toy_Co__Ltd_CCMS
{
    public partial class Home : Form
    {
        private string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;" + "Data Source=Database1.accdb";
        LoginPage loginPage;
        public Home(LoginPage loginPage)
        {
            InitializeComponent();
            this.loginPage = loginPage;
            string sqlStr = "";
            try
            {
                DataTable dt = new DataTable();
                sqlStr = "SELECT COUNT (TaskID) FROM Task";
                OleDbDataAdapter dataAdapter = new OleDbDataAdapter(sqlStr, connStr);
                dataAdapter.Fill(dt);
                dataAdapter.Dispose();
                lblNoOfTask.Text = "Number of Task :"+ dt.Rows[0][0].ToString();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\nSQL: " + sqlStr);
            }
        }

        private void lblTasks_Click(object sender, EventArgs e)
        {
            Task frm = new Task();
            frm.ShowDialog();

        }

        private void lblLeads_Click(object sender, EventArgs e)
        {
            Leads frm = new Leads();
            frm.ShowDialog();

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void lblCompanies_Click(object sender, EventArgs e)
        {
            Companies1 frm = new Companies1();
            frm.ShowDialog();

        }

        private void lblProduct_Click(object sender, EventArgs e)
        {
            Product1 frm = new Product1();
            frm.ShowDialog();

        }

        private void lblInvoice_Click(object sender, EventArgs e)
        {

        }

        private void Home_Load(object sender, EventArgs e)
        {
            string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=Database1.accdb;";
            string query = @"SELECT Staff.StaffName FROM Data INNER JOIN Staff ON CStr(Data.Staff_Id) = CStr(Staff.Staff_Id)";

            lblName.Text = loginPage.txtUsername.Text;
            using (OleDbConnection connection = new OleDbConnection(connectionString))
            {
                try
                {
                    OleDbCommand command = new OleDbCommand(query, connection);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    lblName.Text = (result) != null ? result.ToString() : "404Error";
                }
                catch (Exception ex)
                {
                    lblName.Text = $"錯誤：{ex.Message}";
                }
            }
        }
        private void lblEmployee_Click(object sender, EventArgs e)
        {
            Employee1 frm = new Employee1();
            frm.ShowDialog();

        }

        private void lblName_Click(object sender, EventArgs e)
        {
            Logout frm = new Logout();
            frm.ShowDialog();
        }

        private void lblReports_Click(object sender, EventArgs e)
        {
            Report1 frm = new Report1();
            frm.ShowDialog();
        }

        private void lblLeadDashboard_Click(object sender, EventArgs e)
        {

        }

        private void lblDeals_Click(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void lblSettings_Click(object sender, EventArgs e)
        {

        }
    }
}
